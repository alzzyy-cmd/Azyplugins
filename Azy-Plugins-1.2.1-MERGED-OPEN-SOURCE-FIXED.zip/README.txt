AzySell + AzyWorth 1.2.x — 1.3 yenilikleri birleşik kaynak sürüm

Bu paket 1.2.0 tabanına AzySell 1.3.0 kaynak kodundaki geliştirmeleri taşır.
AzyWorth 1.2.0 kaynak ve fiyat listesi korunmuştur.

AzySell tarafına taşınan geliştirmeler:
- /sell ve /sat: filter/filtre, auto/otomatik, search/ara komutları
- Türkçe + İngilizce mesajlar ve arama
- TAB tamamlamaları
- Satış GUI arama düğmesi
- Auto durum düğmesi
- GUI drag/close güvenliği
- multiplier desteği
- sandık/trapped chest/barrel içeriğini satma; blok kırmayı engelleme
- Netherite Ametist Satış Baltası
- süre/lore/büyü/level sistemi
- balta swing animasyonunu engelleme
- yükseltici GUI ve maksimum seviye kontrolü
- izin kontrolleri

NOT:
Bu paket kaynak birleştirmesidir. Derlenmiş JAR'lar değiştirilmeden 1.2.0 JAR dosyaları paket içinde bırakılmıştır.
Yeni JAR üretmek için GitHub Actions/Maven kullanılmalıdır.

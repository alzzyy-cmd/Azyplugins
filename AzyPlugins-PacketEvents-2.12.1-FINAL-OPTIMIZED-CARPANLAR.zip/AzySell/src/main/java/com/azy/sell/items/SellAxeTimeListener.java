package com.azy.sell.items;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

/** Sadece oyuncunun aktif envanterinde bulunan süreli baltaların süresini tüketir. */
public final class SellAxeTimeListener extends BukkitRunnable {
    private final AzySell plugin;
    private final SellAxeItem axe;
    private long lastRun = System.currentTimeMillis();

    public SellAxeTimeListener(AzySell plugin, SellAxeItem axe) {
        this.plugin = plugin;
        this.axe = axe;
    }

    public void start() {
        runTaskTimer(plugin, 20L, 20L);
    }

    @Override
    public void run() {
        long now = System.currentTimeMillis();
        long elapsed = Math.max(0L, now - lastRun);
        lastRun = now;
        if (elapsed <= 0) return;

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            // Oyuncu envanteri + hotbar. Container, yere düşmüş item ve GUI içindeki
            // baltalar burada bulunmadığı için onların süresi ilerlemez.
            for (int slot = 0; slot < 36; slot++) {
                ItemStack item = player.getInventory().getItem(slot);
                if (!axe.isSellAxe(item) || !axe.hasExpiry(item)) continue;
                if (axe.tickTime(item, elapsed)) {
                    player.getInventory().setItem(slot, null);
                    player.sendMessage(plugin.msg("&cSatış baltanın süresi doldu."));
                }
            }

            ItemStack offhand = player.getInventory().getItemInOffHand();
            if (axe.isSellAxe(offhand) && axe.hasExpiry(offhand) && axe.tickTime(offhand, elapsed)) {
                player.getInventory().setItemInOffHand(null);
                player.sendMessage(plugin.msg("&cSatış baltanın süresi doldu."));
            }
        }
    }
}

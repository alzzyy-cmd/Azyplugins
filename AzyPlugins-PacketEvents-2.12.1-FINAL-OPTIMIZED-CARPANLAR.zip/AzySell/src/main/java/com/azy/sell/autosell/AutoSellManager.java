package com.azy.sell.autosell;

import com.azy.sell.AzySell;
import com.azy.sell.SellService.SellResult;
import org.bukkit.Material;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Hafif, olay tabanlı otomatik satış + oyuncu filtre verisi. */
public class AutoSellManager implements Listener {
    private final AzySell plugin;
    private final Map<UUID, PlayerData> data = new ConcurrentHashMap<>();
    private final Map<UUID, Double> pendingActionBar = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> flushTasks = new ConcurrentHashMap<>();
    /** Aynı inventory slotunun event zincirinde tekrar işlenmesini engeller. */
    private final Set<String> processingSlots = ConcurrentHashMap.newKeySet();
    private BukkitTask persistenceTask;
    private File file;
    private YamlConfiguration yaml;

    public AutoSellManager(AzySell plugin) { this.plugin = plugin; }

    public void load() {
        file = new File(plugin.getDataFolder(), "autosell.yml");
        yaml = YamlConfiguration.loadConfiguration(file);
        for (String key : yaml.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                boolean enabled = yaml.getBoolean(key + ".enabled", false);
                long resetAt = yaml.getLong(key + ".daily-reset-at", System.currentTimeMillis());
                long dailySold = yaml.getLong(key + ".daily-sold", 0L);
                if (System.currentTimeMillis() - resetAt >= 86_400_000L) {
                    resetAt = System.currentTimeMillis();
                    dailySold = 0L;
                }
                Set<Material> filters = EnumSet.noneOf(Material.class);
                for (String mat : yaml.getStringList(key + ".filters")) {
                    Material m = Material.matchMaterial(mat);
                    if (m != null) filters.add(m);
                }
                data.put(uuid, new PlayerData(enabled, filters, dailySold, resetAt));
            } catch (IllegalArgumentException ignored) { }
        }
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    public void save() {
        if (yaml == null) return;
        for (Map.Entry<UUID, PlayerData> e : data.entrySet()) {
            String path = e.getKey().toString();
            yaml.set(path + ".enabled", e.getValue().enabled);
            yaml.set(path + ".daily-sold", e.getValue().dailySold);
            yaml.set(path + ".daily-reset-at", e.getValue().dailyResetAt);
            List<String> mats = e.getValue().filters.stream().map(Enum::name).sorted().toList();
            yaml.set(path + ".filters", mats);
        }
        try { file.getParentFile().mkdirs(); yaml.save(file); }
        catch (IOException ex) { plugin.getLogger().warning("autosell.yml kaydedilemedi: " + ex.getMessage()); }
    }

    public boolean isEnabled(Player player) { return get(player).enabled; }
    public boolean toggle(Player player) { PlayerData d=get(player); d.enabled = !d.enabled; scheduleSave(); return d.enabled; }
    public boolean setEnabled(Player player, boolean enabled) { PlayerData d=get(player); d.enabled = enabled; scheduleSave(); return d.enabled; }
    public Set<Material> getFilters(Player p) {
        PlayerData d = get(p);
        // Filtrelerin gerçek kayıtlarını döndür. Eski sürüm burada sadece
        // permission limitine göre ilk N materyali döndürüyordu; oyuncunun
        // filtresi daha önce N'den fazlaysa veya permission sonradan değiştiyse
        // autosell bazı seçilmiş eşyaları sessizce yok sayabiliyordu.
        return d.filters.isEmpty()
                ? EnumSet.noneOf(Material.class)
                : EnumSet.copyOf(d.filters);
    }
    public int getSlotLimit(Player p) {
        if (p.hasPermission("sell.filter.slots.53")) return 53;
        if (p.hasPermission("sell.filter.slots.27")) return 27;
        return 9;
    }
    public void setFilter(Player p, Material m, boolean selected) {
        PlayerData d=get(p);
        if (selected) {
            if (d.filters.contains(m)) return;
            if (d.filters.size() >= getSlotLimit(p)) return;
            d.filters.add(m);
        } else d.filters.remove(m);
        scheduleSave();
    }
    public boolean isFiltered(Player p, Material m) { return get(p).filters.contains(m); }

    private PlayerData get(Player p) {
        PlayerData d = data.computeIfAbsent(p.getUniqueId(), k -> new PlayerData(false, EnumSet.noneOf(Material.class), 0L, System.currentTimeMillis()));
        resetIfNeeded(d);
        return d;
    }

    private void resetIfNeeded(PlayerData d) {
        long now = System.currentTimeMillis();
        if (now - d.dailyResetAt >= 86_400_000L) {
            d.dailySold = 0L;
            d.dailyResetAt = now;
            d.limitNotified = false;
            scheduleSave();
        }
    }
    private void scheduleSave() {
        if (yaml == null || persistenceTask != null) return;
        persistenceTask = plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            persistenceTask = null;
            save();
        }, 20L);
    }

    /** Oyuncunun kendi ana envanterindeki filtreli eşyaları kontrol eder; container/hopper taramaz. */
    public void processInventory(Player player) {
        if (!isEnabled(player)) return;
        for (int slot = 0; slot < 36; slot++) {
            if (!isEnabled(player)) break;
            processSlot(player, slot);
        }
    }

    /** Yalnızca verilen materyali taşıyan filtreli slotları kontrol eder. */
    public void processMaterial(Player player, Material material) {
        if (!isEnabled(player) || material == null) return;
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack != null && stack.getType() == material && isFiltered(player, material)) {
                processSlot(player, slot);
            }
        }
    }

    public void processSlot(Player player, int slot) {
        if (!isEnabled(player) || slot < 0 || slot >= player.getInventory().getSize()) return;
        String guardKey = player.getUniqueId() + ":" + slot;
        if (!processingSlots.add(guardKey)) return;
        try {
        PlayerData d = get(player);
        long limit = getDailyLimit(player);
        if (limit == 0L || d.dailySold >= limit) {
            notifyLimit(player, limit);
            return;
        }
        ItemStack stack=player.getInventory().getItem(slot);
        if (stack==null || stack.getType().isAir() || !isFiltered(player, stack.getType())) return;
        if (!plugin.getPriceCalculator().hasPrice(stack)) return;

        int remaining = limit < 0L ? stack.getAmount() : (int)Math.min((long)stack.getAmount(), limit - d.dailySold);
        if (remaining <= 0) {
            notifyLimit(player, limit);
            return;
        }

        ItemStack saleStack = stack.clone();
        boolean shulker = saleStack.getType().name().endsWith("SHULKER_BOX");
        if (remaining < stack.getAmount() && shulker) return;
        boolean partial = remaining < stack.getAmount();
        if (partial) saleStack.setAmount(remaining);
        SellResult result=plugin.getSellService().sellStack(player, saleStack, false);
        if (!result.isEmpty()) {
            d.dailySold += result.totalItems();
            if (partial) {
                ItemStack left = stack.clone();
                left.setAmount(stack.getAmount() - result.totalItems());
                player.getInventory().setItem(slot, left);
            } else if (result.replacement() != null) player.getInventory().setItem(slot, result.replacement());
            else player.getInventory().setItem(slot, null);
            scheduleSave();
            queueActionBar(player, result.totalEarned());
            if (limit > 0 && d.dailySold >= limit) notifyLimit(player, limit);
        }
        } finally {
            processingSlots.remove(guardKey);
        }
    }

    public long getDailyLimit(Player player) {
        if (player.hasPermission("sell.auto.limit.unlimited")) return -1L;
        long limit = plugin.getConfig().getLong("auto-sell.daily-limit", 1000L);
        String[] nodes = {"1000","5000","10000","25000","50000","100000","250000","500000","1000000"};
        for (String node : nodes) {
            if (player.hasPermission("sell.auto.limit." + node)) limit = Math.max(limit, Long.parseLong(node));
        }
        return Math.max(0L, limit);
    }

    public long getDailySold(Player player) { return get(player).dailySold; }

    private void notifyLimit(Player player, long limit) {
        if (limit < 0L) return;
        PlayerData d = get(player);
        if (d.limitNotified) return;
        d.limitNotified = true;
        player.sendMessage(plugin.msg("&cGünlük otomatik satış limitine ulaştın: &f" + limit + " &ceşya."));
    }

    private void queueActionBar(Player player, double amount) {
        pendingActionBar.merge(player.getUniqueId(), amount, Double::sum);
        flushTasks.computeIfAbsent(player.getUniqueId(), id -> plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            Double total=pendingActionBar.remove(id); flushTasks.remove(id);
            if (total != null && player.isOnline()) player.spigot().sendMessage(ChatMessageType.ACTION_BAR,
                    TextComponent.fromLegacyText(plugin.msg("&eOtomatik satış: &a+$" + format(total))));
        }, 10L));
    }
    private String format(double n) { return n == Math.floor(n) ? String.valueOf((long)n) : String.format("%.2f", n); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { pendingActionBar.remove(e.getPlayer().getUniqueId()); BukkitTask t=flushTasks.remove(e.getPlayer().getUniqueId()); if(t!=null)t.cancel(); }

    public void openFilter(Player player) { new SellFilterGui(plugin, this, 0, null).open(player); }
    public void search(Player player, String query) { new SellFilterGui(plugin, this, 0, query).open(player); }
    private static final class PlayerData {
        boolean enabled;
        final Set<Material> filters;
        long dailySold;
        long dailyResetAt;
        boolean limitNotified;
        PlayerData(boolean enabled, Set<Material> filters, long dailySold, long dailyResetAt){
            this.enabled=enabled; this.filters=filters; this.dailySold=dailySold; this.dailyResetAt=dailyResetAt;
        }
    }
}

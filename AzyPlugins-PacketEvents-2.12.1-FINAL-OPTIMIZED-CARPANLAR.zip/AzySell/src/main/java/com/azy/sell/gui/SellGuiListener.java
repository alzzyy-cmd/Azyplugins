package com.azy.sell.gui;

import com.azy.sell.AzySell;
import com.azy.sell.category.CategoryDefinition;
import com.azy.sell.category.CategoryProgressGui;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class SellGuiListener implements Listener {

    private final AzySell plugin;

    public SellGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    /**
     * Kategori butonlarına (satılabilir alanın dışındaki slotlara) tıklamayı yakalar:
     * eşya bırakılmasını/alınmasını engeller ve tıklanan kategoriye göre
     * Progress GUI'sini açar.
     */
    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof SellGuiHolder sellHolder)) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;

        int rawSlot = event.getRawSlot();
        // Üst envanterin dışına (oyuncunun kendi envanterine) tıklamalar serbest.
        if (rawSlot >= event.getInventory().getSize()) return;

        if (rawSlot >= sellHolder.getSellableAreaSize()) {
            event.setCancelled(true);
            CategoryDefinition category = SellGui.getCategoryForSlot(plugin, rawSlot - sellHolder.getSellableAreaSize());
            if (category != null) {
                new CategoryProgressGui(plugin, category).open(player);
            }
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof SellGuiHolder sellHolder)) return;
        if (!(event.getPlayer() instanceof Player player)) return;

        // Sadece satılabilir alanı (kategori butonlarından ÖNCEKİ slotlar) ayrı bir
        // geçici envantere kopyalayıp satıyoruz - kategori ikonları ASLA satılmaz,
        // ASLA fiyatlandırılmaz, çünkü sellInventory() bu geçici envanterin dışına hiç çıkmaz.
        int sellableSize = sellHolder.getSellableAreaSize();
        Inventory temp = Bukkit.createInventory(null, roundUpToMultipleOf9(sellableSize));
        for (int i = 0; i < sellableSize; i++) {
            ItemStack stack = event.getInventory().getItem(i);
            if (stack != null) {
                temp.setItem(i, stack);
                event.getInventory().setItem(i, null);
            }
        }

        plugin.getSellService().sellInventory(player, temp);

        // Satılamayan (fiyatsız) eşyalar varsa oyuncuya geri ver.
        for (ItemStack stack : temp.getContents()) {
            if (stack != null && !stack.getType().isAir()) {
                java.util.Map<Integer, ItemStack> leftovers = player.getInventory().addItem(stack);
                for (ItemStack leftover : leftovers.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), leftover);
                }
            }
        }
    }

    private int roundUpToMultipleOf9(int size) {
        int rounded = ((size + 8) / 9) * 9;
        return Math.max(9, rounded);
    }
}

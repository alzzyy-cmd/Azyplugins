package com.azy.sell.autosell;

import com.azy.sell.AzySell;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

public class SellFilterGui implements InventoryHolder {
    private static final int SIZE=54, SLOT_CATEGORY=45, SLOT_STATUS=46, SLOT_SEARCH=47, SLOT_PREV=48, SLOT_NEXT=53, SLOT_CLEAR=50;
    private final AzySell plugin; private final AutoSellManager manager; private final int page; private final String query; private Inventory inventory;
    public SellFilterGui(AzySell plugin, AutoSellManager manager, int page, String query){this.plugin=plugin;this.manager=manager;this.page=page;this.query=query;}
    public void open(Player p){
        int safePage=Math.max(0,page);
        inventory=Bukkit.createInventory(this,SIZE,plugin.msg("&8Satış Filtresi &7(Sayfa "+(safePage+1)+")"));
        ItemStack filler=button(Material.GRAY_STAINED_GLASS_PANE,"&7Boş Filtre Yuvası");
        ItemStack locked=button(Material.RED_STAINED_GLASS_PANE,"&cKilitli Filtre Yuvası","&7Daha fazla yuva için yetki gerekir.");
        int limit = manager.getSlotLimit(p);
        for(int i=0;i<45;i++) inventory.setItem(i, i < limit ? filler.clone() : locked.clone());
        List<Material> selected=new ArrayList<>(manager.getFilters(p));
        selected.sort(Comparator.comparing(Enum::name));
        int maxPage=Math.max(0,(selected.size()-1)/45); safePage=Math.min(safePage,maxPage); int start=safePage*45, end=Math.min(start+45,selected.size());
        for(int i=start;i<end;i++) inventory.setItem(i-start,item(selected.get(i),true));
        long dailyLimit = manager.getDailyLimit(p);
        String limitText = dailyLimit < 0 ? "Sınırsız" : manager.getDailySold(p) + "/" + dailyLimit;
        inventory.setItem(SLOT_CATEGORY,button(Material.HOPPER,"&eKategori / Eşya Seçimi","&7Eşya seçim menüsünü aç"));
        inventory.setItem(SLOT_STATUS,button(manager.isEnabled(p)?Material.LIME_DYE:Material.RED_DYE,manager.isEnabled(p)?"&aOtomatik Satış: Açık":"&cOtomatik Satış: Kapalı","&7Değiştirmek için tıkla","&7Günlük limit: &f"+limitText));
        inventory.setItem(SLOT_SEARCH,button(Material.COMPASS,"&bArama","&7Türkçe veya İngilizce eşya adı yaz"));
        inventory.setItem(SLOT_PREV,button(Material.ARROW,"&aÖnceki Sayfa"));
        inventory.setItem(49,button(Material.PAPER,"&eSeçili: &f"+selected.size()+" &7/ &f"+manager.getSlotLimit(p)));
        inventory.setItem(50,button(Material.BARRIER,"&cFiltreyi Temizle","&7Tüm seçili eşyaları kaldır"));
        inventory.setItem(51,button(Material.BOOK,"&7Sağ tık: Kaldır","&7Seçili eşyayı filtreden çıkar"));
        inventory.setItem(52,button(Material.ARROW,"&eSeçim Menüsü","&7Eşya eklemek için tıkla"));
        inventory.setItem(SLOT_NEXT,button(Material.ARROW,"&aSonraki Sayfa"));
        p.openInventory(inventory);
    }
    private ItemStack item(Material m,boolean selected){ return new ItemStack(m); }
    private ItemStack button(Material m,String name,String... lore){ItemStack s=new ItemStack(m);ItemMeta meta=s.getItemMeta();if(meta!=null){meta.setDisplayName(plugin.msg(name));if(lore.length>0)meta.setLore(Arrays.stream(lore).map(plugin::msg).toList());s.setItemMeta(meta);}return s;}
    private String pretty(String n){StringBuilder b=new StringBuilder();for(String x:n.toLowerCase(Locale.ROOT).split("_")){if(!b.isEmpty())b.append(' ');b.append(Character.toUpperCase(x.charAt(0))).append(x.substring(1));}return b.toString();}
    public static int category(){return SLOT_CATEGORY;} public static int status(){return SLOT_STATUS;} public static int search(){return SLOT_SEARCH;} public static int prev(){return SLOT_PREV;} public static int next(){return SLOT_NEXT;} public static int clear(){return SLOT_CLEAR;}
    public int getPage(){return page;} public String getQuery(){return query;} @Override public Inventory getInventory(){return inventory;}
}

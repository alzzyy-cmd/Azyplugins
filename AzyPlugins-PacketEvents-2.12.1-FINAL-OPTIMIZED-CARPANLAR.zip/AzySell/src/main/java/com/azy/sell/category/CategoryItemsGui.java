package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Kategori İlerlemesi ekranındaki sol üst kategori ikonuna tıklanınca açılır:
 * o kategorinin kapsadığı TÜM eşyaları, her birinin oyuncuya özel çarpanlı
 * satış fiyatıyla (taban * VIP * kategori çarpanı) listeler.
 *
 * Kontroller (alt satır):
 *  - 45: Geri (kategori ilerleme ekranına döner)
 *  - 48: Önceki sayfa
 *  - 49: Sıralama değiştir (UCUZDAN / PAHALIDAN)
 *  - 53: Sonraki sayfa
 */
public class CategoryItemsGui implements InventoryHolder {

    private static final int SIZE = 54;
    public static final int SLOT_BACK = 45;
    public static final int SLOT_PREV = 48;
    public static final int SLOT_SORT = 49;
    public static final int SLOT_NEXT = 53;
    private static final int CONTENT = 45; // ilk 45 slot eşya için

    private final AzySell plugin;
    private final CategoryDefinition category;
    private final int page;
    private final boolean cheapestFirst;
    private Inventory inventory;

    public CategoryItemsGui(AzySell plugin, CategoryDefinition category, int page, boolean cheapestFirst) {
        this.plugin = plugin;
        this.category = category;
        this.page = Math.max(0, page);
        this.cheapestFirst = cheapestFirst;
    }

    public void open(Player player) {
        String title = plugin.msg(category.getDisplayName() + " &7Eşyalar");
        inventory = Bukkit.createInventory(this, SIZE, title);

        // Eşyaları oyuncunun o anki nihai birim satış fiyatına göre sırala.
        List<Material> mats = new ArrayList<>(category.getMaterials());
        mats.removeIf(m -> m == null || m.isAir() || !plugin.getPriceCalculator().hasPrice(m));
        Comparator<Material> byPrice = Comparator.comparingDouble(m -> plugin.getPriceCalculator().getUnitSellPrice(player, m));
        mats.sort(cheapestFirst ? byPrice : byPrice.reversed());

        int maxPage = Math.max(0, (mats.size() - 1) / CONTENT);
        int safePage = Math.min(page, maxPage);
        int start = safePage * CONTENT;
        int end = Math.min(start + CONTENT, mats.size());

        for (int i = 0; i < 45; i++) inventory.setItem(i, null);

        int slot = 0;
        for (int i = start; i < end; i++, slot++) {
            inventory.setItem(slot, buildItem(player, mats.get(i)));
        }

        inventory.setItem(SLOT_BACK, button(Material.RED_STAINED_GLASS_PANE, "&cGeri Dön",
                List.of(plugin.msg("&7İlerleme ekranına dön"))));
        inventory.setItem(SLOT_PREV, button(Material.ARROW, "&eÖnceki Sayfa",
                List.of(plugin.msg("&7Sayfa: &f" + (safePage + 1) + "/" + (maxPage + 1)))));
        inventory.setItem(SLOT_SORT, button(Material.HOPPER,
                cheapestFirst ? "&aSıralama: Ucuzdan Pahalıya" : "&6Sıralama: Pahalıdan Ucuza",
                List.of(plugin.msg("&7Tıkla: sıralamayı değiştir"))));
        inventory.setItem(SLOT_NEXT, button(Material.ARROW, "&eSonraki Sayfa",
                List.of(plugin.msg("&7Sayfa: &f" + (safePage + 1) + "/" + (maxPage + 1)))));

        player.openInventory(inventory);
    }

    private ItemStack buildItem(Player player, Material material) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            double unit = plugin.getPriceCalculator().getUnitSellPrice(player, material);
            double base = plugin.getPriceCalculator().getBaseValue(material);
            double vipExtra = plugin.getMultiplierManager().getExtraMultiplier(player);
            double catMult = plugin.getCategoryProgressManager().getMultiplier(player.getUniqueId(), material);
            List<String> lore = new ArrayList<>();
            lore.add(plugin.msg("&7Taban: &f$" + plugin.getEconomyManager().format(base)));
            lore.add(plugin.msg("&7VIP çarpanı: &b" + trim(1 + vipExtra) + "x"));
            lore.add(plugin.msg("&7Kategori çarpanı: &d" + trim(catMult) + "x"));
            lore.add(plugin.msg("&aSatış fiyatı: &f$" + plugin.getEconomyManager().format(unit)));
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String trim(double v) {
        return v == Math.floor(v) ? String.format("%.1f", v) : String.valueOf(v);
    }

    private ItemStack button(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(name));
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public CategoryDefinition getCategory() { return category; }
    public int getPage() { return page; }
    public boolean isCheapestFirst() { return cheapestFirst; }

    @Override
    public Inventory getInventory() { return inventory; }
}

package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * CategoryProgressGui salt-okunur bir bilgi ekranıdır: hiçbir eşya
 * alınamaz/bırakılamaz/sürüklenemez. Tek istisna: sol alt köşedeki kırmızı
 * "Geri Dön" butonu, oyuncuyu MultiplierSummaryGui (kategori özet) ekranına
 * geri döndürür.
 */
public class CategoryProgressGuiListener implements Listener {

    private final AzySell plugin;

    public CategoryProgressGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof CategoryProgressGui) {
            event.setCancelled(true);

            if (!(event.getWhoClicked() instanceof Player player)) return;
            int slot = event.getRawSlot();
            if (slot == CategoryProgressGui.BACK_BUTTON_SLOT) {
                player.closeInventory();
                new MultiplierSummaryGui(plugin).open(player);
            } else if (slot == CategoryProgressGui.ICON_SLOT && holder instanceof CategoryProgressGui gui) {
                // Kategori ikonuna tıklayınca: bu kategoriyi etkileyen eşyaları,
                // oyuncunun çarpanlı satış fiyatlarıyla birlikte listele.
                new CategoryItemsGui(plugin, gui.getCategory(), 0, true).open(player);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof CategoryProgressGui) {
            event.setCancelled(true);
        }
    }
}

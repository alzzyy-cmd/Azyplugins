package com.azy.sell.history;

/** Satış geçmişi istatistiklerinin zaman aralığı. */
public enum HistoryPeriod {
    DAILY("&eGünlük Kazanç", 24L * 60L * 60L * 1000L),
    WEEKLY("&eHaftalık Kazanç", 7L * 24L * 60L * 60L * 1000L),
    ALL_TIME("&eTüm Zamanlar", -1L);

    private final String displayName;
    private final long durationMillis;

    HistoryPeriod(String displayName, long durationMillis) {
        this.displayName = displayName;
        this.durationMillis = durationMillis;
    }

    public String getDisplayName() { return displayName; }
    public long getDurationMillis() { return durationMillis; }
    public HistoryPeriod next() {
        HistoryPeriod[] values = values();
        return values[(ordinal() + 1) % values.length];
    }
}

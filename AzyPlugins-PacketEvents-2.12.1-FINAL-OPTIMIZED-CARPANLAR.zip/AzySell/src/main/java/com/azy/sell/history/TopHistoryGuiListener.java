package com.azy.sell.history;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

public class TopHistoryGuiListener implements Listener {

    private final AzySell plugin;

    public TopHistoryGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof TopHistoryGui gui)) return;

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) {
            return;
        }

        Player player = (Player) event.getWhoClicked();
        int slot = event.getSlot();

        if (slot == TopHistoryGui.getSlotPrev()) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.8f, 1.15f);
            new TopHistoryGui(plugin, gui.getPage() - 1, gui.getSortMode(), gui.getPeriod()).open(player);
        } else if (slot == TopHistoryGui.getSlotNext()) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.8f, 1.15f);
            new TopHistoryGui(plugin, gui.getPage() + 1, gui.getSortMode(), gui.getPeriod()).open(player);
        } else if (slot == TopHistoryGui.getSlotSort()) {
            new TopHistoryGui(plugin, 0, gui.getSortMode().next(), gui.getPeriod()).open(player);
        } else if (slot == TopHistoryGui.getSlotPeriod()) {
            new TopHistoryGui(plugin, 0, gui.getSortMode(), gui.getPeriod().next()).open(player);
        }
    }
}

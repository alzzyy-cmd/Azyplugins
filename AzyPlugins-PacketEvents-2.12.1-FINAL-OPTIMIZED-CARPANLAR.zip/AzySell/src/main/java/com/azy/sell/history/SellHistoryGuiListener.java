package com.azy.sell.history;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

public class SellHistoryGuiListener implements Listener {

    private final AzySell plugin;

    public SellHistoryGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof SellHistoryGui gui)) return;

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) {
            return;
        }

        Player player = (Player) event.getWhoClicked();
        int slot = event.getSlot();

        if (slot == SellHistoryGui.getSlotPrev()) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.8f, 1.15f);
            new SellHistoryGui(plugin, gui.getTargetPlayer(), gui.getPage() - 1, gui.getSortMode(), gui.getPeriod()).open(player);
        } else if (slot == SellHistoryGui.getSlotNext()) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.8f, 1.15f);
            new SellHistoryGui(plugin, gui.getTargetPlayer(), gui.getPage() + 1, gui.getSortMode(), gui.getPeriod()).open(player);
        } else if (slot == SellHistoryGui.getSlotSort()) {
            new SellHistoryGui(plugin, gui.getTargetPlayer(), 0, gui.getSortMode().next(), gui.getPeriod()).open(player);
        } else if (slot == SellHistoryGui.getSlotPeriod()) {
            new SellHistoryGui(plugin, gui.getTargetPlayer(), 0, gui.getSortMode(), gui.getPeriod().next()).open(player);
        }
    }
}

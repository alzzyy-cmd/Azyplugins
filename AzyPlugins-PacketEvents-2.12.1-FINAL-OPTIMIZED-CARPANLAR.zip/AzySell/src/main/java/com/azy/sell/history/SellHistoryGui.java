package com.azy.sell.history;

import com.azy.sell.AzySell;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

/**
 * /satisgecmisi (alias: /sellhistory) komutuyla açılan ekran.
 * Oyuncunun eşya bazlı toplam sattığı miktar ve toplam kazancını gösterir.
 * TopHistoryGui ile aynı sayfalama düzenini kullanır (45'lik sayfa +
 * önceki/sonraki/toplam butonları), böylece çok sayıda eşya satmış oyuncularda
 * ilk 54 eşyanın ardından liste sessizce kesilmez.
 */
public class SellHistoryGui implements InventoryHolder {

    private static final int PAGE_SIZE = 44;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_SORT = 48;
    private static final int SLOT_SUMMARY = 49;
    private static final int SLOT_NEXT = 53;
    private static final int SLOT_PERIOD = 50;

    private final AzySell plugin;
    private final UUID targetPlayer;
    private final int page;
    private final SortMode sortMode;
    private final HistoryPeriod period;
    private Inventory inventory;

    public SellHistoryGui(AzySell plugin, UUID targetPlayer) {
        this(plugin, targetPlayer, 0, SortMode.HIGHEST_PRICE, HistoryPeriod.ALL_TIME);
    }

    public SellHistoryGui(AzySell plugin, UUID targetPlayer, int page) {
        this(plugin, targetPlayer, page, SortMode.HIGHEST_PRICE, HistoryPeriod.ALL_TIME);
    }

    public SellHistoryGui(AzySell plugin, UUID targetPlayer, int page, SortMode sortMode) {
        this(plugin, targetPlayer, page, sortMode, HistoryPeriod.ALL_TIME);
    }

    public SellHistoryGui(AzySell plugin, UUID targetPlayer, int page, SortMode sortMode, HistoryPeriod period) {
        this.plugin = plugin;
        this.targetPlayer = targetPlayer;
        this.page = page;
        this.sortMode = sortMode;
        this.period = period;
    }

    public void open(Player viewer) {
        int totalDistinct = plugin.getHistoryManager().getPlayerDistinctItemCount(targetPlayer, period);
        int maxPages = Math.max(1, (int) Math.ceil(totalDistinct / (double) PAGE_SIZE));
        int clampedPage = Math.max(0, Math.min(page, maxPages - 1));

        List<SellHistoryManager.HistoryEntry> entries =
                plugin.getHistoryManager().getSummary(targetPlayer, PAGE_SIZE, clampedPage * PAGE_SIZE, sortMode, period);

        String title = plugin.msg("&8Satış Geçmişi &7(Sayfa " + (clampedPage + 1) + "/" + maxPages + ")");
        inventory = Bukkit.createInventory(this, 54, title);

        for (int i = 0; i < entries.size() && i < PAGE_SIZE; i++) {
            inventory.setItem(i, buildEntryItem(entries.get(i)));
        }

        if (clampedPage > 0) {
            inventory.setItem(SLOT_PREV, navButton("&aÖnceki Sayfa"));
        }
        if (clampedPage < maxPages - 1) {
            inventory.setItem(SLOT_NEXT, navButton("&aSonraki Sayfa"));
        }
        inventory.setItem(SLOT_SORT, sortButton());

        ItemStack summary = new ItemStack(Material.PAPER);
        ItemMeta meta = summary.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&e&lKazanç Özeti"));
            SellHistoryManager.PersonalTotals totals = plugin.getHistoryManager().getPersonalTotals(targetPlayer, period);
            meta.setLore(List.of(
                    plugin.msg("&7Aralık: " + period.getDisplayName()),
                    plugin.msg("&7Farklı eşya çeşidi: &f" + totalDistinct),
                    plugin.msg("&7Satılan miktar: &f" + totals.totalAmount()),
                    plugin.msg("&7Kazanç: &a$" + format(totals.totalPrice()))
            ));
            summary.setItemMeta(meta);
        }
        inventory.setItem(SLOT_SUMMARY, summary);
        inventory.setItem(SLOT_PERIOD, periodButton());

        viewer.openInventory(inventory);
    }

    private ItemStack buildEntryItem(SellHistoryManager.HistoryEntry entry) {
        ItemStack stack = new ItemStack(entry.material());
        // Stack adedi 0 olursa Bukkit item'ı görünmez yapar; en az 1 olmalı.
        stack.setAmount(1);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            // BUG FIX: Component.translatable + setLore karışımı bazı Paper sürümlerinde
            // item'ı tamamen görünmez yapıyordu. setDisplayName ile daha güvenilir.
            String prettyName = prettifyMaterialName(entry.material().name());
            meta.setDisplayName(plugin.msg("&f" + prettyName));
            meta.setLore(List.of(
                    plugin.msg("&7Toplam miktar: &f" + entry.totalAmount()),
                    plugin.msg("&7Toplam kazanç: &a$" + format(entry.totalPrice()))
            ));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String prettifyMaterialName(String materialName) {
        String[] parts = materialName.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append(' ');
            String p = parts[i];
            if (!p.isEmpty()) sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        }
        return sb.toString();
    }

    private ItemStack navButton(String name) {
        ItemStack stack = new ItemStack(Material.ARROW);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack sortButton() {
        ItemStack stack = new ItemStack(Material.HOPPER);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&eSıralama: " + sortMode.getDisplayName()));
            meta.setLore(List.of(plugin.msg("&7Değiştirmek için tıkla")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack periodButton() {
        ItemStack stack = new ItemStack(Material.CLOCK);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(period.getDisplayName()));
            meta.setLore(List.of(plugin.msg("&7Tıklayarak günlük / haftalık / tüm zamanlar arasında geçiş yap.")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String format(double price) {
        if (price == Math.floor(price)) return String.valueOf((long) price);
        return String.format("%.2f", price);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public UUID getTargetPlayer() {
        return targetPlayer;
    }

    public int getPage() {
        return page;
    }

    public SortMode getSortMode() {
        return sortMode;
    }

    public HistoryPeriod getPeriod() { return period; }

    public static int getSlotPrev() { return SLOT_PREV; }
    public static int getSlotNext() { return SLOT_NEXT; }
    public static int getSlotSort() { return SLOT_SORT; }
    public static int getSlotPeriod() { return SLOT_PERIOD; }
}

package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.scheduler.BukkitTask;
import java.util.logging.Level;

/**
 * Kategori bazlı satış çarpanı sisteminin kalbi.
 *
 * ÖNEMLİ (satış sırası kuralı): Bir oyuncu eşya sattığında, o satışın fiyatı
 * ÖNCE hesaplanır (mevcut çarpanla), SONRA bu ilerleme kaydına eklenir.
 * Yani az önce ulaşılan yeni bir tier, O ANKİ satışı ETKİLEMEZ - bir sonraki
 * satıştan itibaren geçerli olur. Bu sıralama SellService tarafından
 * garanti edilir (fiyat hesabı bitip para yatırıldıktan SONRA
 * recordProgress çağrılır).
 *
 * Kategori ilerlemesi, materyalin TABAN worth'ü (kategori çarpanı uygulanmadan
 * önceki, ama global multiplier ve VIP çarpanı dahil değil - yani "kaç para
 * kazandın" değil "ne kadarlık eşya sattın") üzerinden sayılır. Böylece
 * çarpan kendi kendini beslemez.
 */
public class CategoryProgressManager {

    private final AzySell plugin;
    private final Map<String, CategoryDefinition> categories = new LinkedHashMap<>();
    /** Hızlı erişim için: bir materyalin hangi kategoriye ait olduğu (en fazla bir kategori). */
    private final Map<Material, String> materialToCategory = new java.util.HashMap<>();
    private Connection connection;
    private final Map<UUID, Map<String, Double>> progressCache = new HashMap<>();
    private final Set<String> dirtyKeys = new HashSet<>();
    private BukkitTask flushTask;

    public CategoryProgressManager(AzySell plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // Config yükleme
    // ---------------------------------------------------------------

    public void loadCategories() {
        categories.clear();
        materialToCategory.clear();

        File file = new File(plugin.getDataFolder(), "sell-categories.yml");
        if (!file.exists()) {
            plugin.saveResource("sell-categories.yml", false);
        }

        FileConfiguration config;
        try (InputStream defaultStream = plugin.getResource("sell-categories.yml")) {
            config = YamlConfiguration.loadConfiguration(file);
            if (defaultStream != null) {
                YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                        new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
                config.setDefaults(defaults);
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "sell-categories.yml okunamadı, kategori çarpanı devre dışı.", ex);
            return;
        }

        ConfigurationSection categoriesSection = config.getConfigurationSection("categories");
        if (categoriesSection == null) {
            plugin.getLogger().warning("sell-categories.yml içinde 'categories' bölümü bulunamadı.");
            return;
        }

        for (String categoryId : categoriesSection.getKeys(false)) {
            ConfigurationSection section = categoriesSection.getConfigurationSection(categoryId);
            if (section == null) continue;

            String configuredDisplayName = section.getString("display-name", categoryId);
            String displayName = plugin.msg(migrateLegacyDisplayName(categoryId, configuredDisplayName));
            String description = plugin.msg(section.getString("description", ""));
            Material icon = parseMaterial(section.getString("icon", "STONE"), categoryId);

            java.util.Set<Material> materials = new java.util.LinkedHashSet<>();
            for (String materialName : section.getStringList("materials")) {
                Material material = parseMaterial(materialName, categoryId);
                if (material != null) {
                    materials.add(material);
                    // Bir materyal zaten başka bir kategoriye atanmışsa (config hatası),
                    // ilk tanımlandığı kategoriye ait kalır - çakışma sessizce yok sayılır
                    // ama loglanır, böylece hangi eşyayı sattığında hangi kategorinin
                    // ilerleyeceği HER ZAMAN net ve tutarlıdır.
                    String existing = materialToCategory.get(material);
                    if (existing != null && !existing.equals(categoryId)) {
                        plugin.getLogger().warning("'" + material + "' hem '" + existing + "' hem '" + categoryId
                                + "' kategorisinde tanımlı. İlk tanım ('" + existing + "') geçerli olacak.");
                    } else {
                        materialToCategory.put(material, categoryId);
                    }
                }
            }

            List<CategoryTier> tiers = new ArrayList<>();
            List<Map<?, ?>> tierMaps = section.getMapList("tiers");
            for (Map<?, ?> tierMap : tierMaps) {
                Object amountObj = tierMap.get("amount");
                Object multiplierObj = tierMap.get("multiplier");
                if (amountObj == null || multiplierObj == null) continue;
                double amount = ((Number) amountObj).doubleValue();
                double multiplier = ((Number) multiplierObj).doubleValue();
                tiers.add(new CategoryTier(amount, multiplier));
            }
            tiers.sort((a, b) -> Double.compare(a.requiredAmount(), b.requiredAmount()));

            categories.put(categoryId, new CategoryDefinition(categoryId, displayName, icon, description, materials, tiers));
        }

        plugin.getLogger().info(categories.size() + " satış kategorisi yüklendi.");
    }

    /** Eski sürümlerde kategori adı olarak kullanılan ham item isimlerini yeni adlara dönüştürür. */
    private String migrateLegacyDisplayName(String categoryId, String configured) {
        if (configured == null) return categoryId;
        String normalized = java.text.Normalizer.normalize(configured.replaceAll("(?i)[&§][0-9A-FK-ORX]", "").trim().toLowerCase(java.util.Locale.ROOT), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "").replaceAll("[^a-z0-9]", "");
        String id = categoryId.toLowerCase(java.util.Locale.ROOT);
        if (normalized.equals("bugday") || id.equals("farm")) return normalized.equals("bugday") ? "&aTarım" : configured;
        if (normalized.equals("elmas") || normalized.equals("cevherler") || normalized.equals("maden") || id.equals("mining") || id.equals("ores")) return normalized.equals("elmas") || normalized.equals("cevherler") || normalized.equals("maden") ? "&bMücevherler" : configured;
        if (normalized.equals("kemik") || normalized.equals("mobdroplari") || id.equals("mobdrops")) return normalized.equals("kemik") || normalized.equals("mobdroplari") ? "&fMob Düşüşleri" : configured;
        if (normalized.equals("yaprak") || id.equals("blocks")) return normalized.equals("yaprak") ? "&2Bloklar" : configured;
        if (normalized.equals("netheritemigfer") || id.equals("combat")) return normalized.equals("netheritemigfer") ? "&cSavaş" : configured;
        if (normalized.equals("balik") || normalized.equals("balikcilik") || id.equals("fishing")) return normalized.equals("balik") || normalized.equals("balikcilik") ? "&3Balıkçılık" : configured;
        if (normalized.equals("buyukitabi") || normalized.equals("buyu") || id.equals("enchanting")) return normalized.equals("buyukitabi") || normalized.equals("buyu") ? "&dBüyü" : configured;
        if (normalized.equals("iksir") || normalized.equals("iksirler") || id.equals("potions")) return normalized.equals("iksir") || normalized.equals("iksirler") ? "&5İksirler" : configured;
        if (normalized.equals("tugla") || normalized.equals("diger") || id.equals("misc")) return normalized.equals("tugla") || normalized.equals("diger") ? "&7Doğal Eşyalar" : configured;
        return configured;
    }

    private Material parseMaterial(String name, String context) {
        if (name == null) return null;
        Material material = Material.matchMaterial(name);
        if (material == null) {
            plugin.getLogger().warning("Bilinmeyen materyal '" + name + "' (kategori: " + context + ")");
        }
        return material;
    }

    // ---------------------------------------------------------------
    // Veritabanı (oyuncu bazlı birikimli ilerleme)
    // ---------------------------------------------------------------

    public void setup() {
        try {
            File dbFile = new File(plugin.getDataFolder(), "carpanlar.db");
            plugin.getDataFolder().mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());

            try (Statement st = connection.createStatement()) {
                st.execute("PRAGMA journal_mode=WAL");
                st.execute("PRAGMA synchronous=NORMAL");
                st.execute("PRAGMA busy_timeout=2000");
                st.execute("""
                        CREATE TABLE IF NOT EXISTS perfsell_category_progress (
                            player_uuid TEXT NOT NULL,
                            category VARCHAR(32) NOT NULL,
                            sold_value DOUBLE NOT NULL DEFAULT 0,
                            PRIMARY KEY (player_uuid, category)
                        )
                        """);
            }
            flushTask = plugin.getServer().getScheduler().runTaskTimer(plugin, this::flushDirty, 20L, 20L);
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Kategori ilerleme veritabanı kurulamadı.", ex);
        }
    }

    public void close() {
        if (flushTask != null) {
            flushTask.cancel();
            flushTask = null;
        }
        flushDirty();
        progressCache.clear();
        dirtyKeys.clear();
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ignored) {
            }
            connection = null;
        }
    }

    /**
     * Verilen materyalin ait olduğu kategoriyi döner (yoksa null).
     */
    public CategoryDefinition getCategoryForMaterial(Material material) {
        String id = materialToCategory.get(material);
        return id == null ? null : categories.get(id);
    }

    /**
     * Oyuncunun bir kategorideki BİRİKİMLİ ilerlemesini döner (SQLite'tan okunur).
     * Kayıt yoksa 0.0 döner.
     */
    public double getProgress(UUID playerUuid, String categoryId) {
        if (connection == null) return 0.0;
        String dbCategory = toPerfSellCategoryId(categoryId);
        Map<String, Double> playerCache = progressCache.get(playerUuid);
        if (playerCache == null) {
            playerCache = loadPlayerProgress(playerUuid);
            progressCache.put(playerUuid, playerCache);
        }
        return playerCache.getOrDefault(dbCategory, 0.0);
    }

    private Map<String, Double> loadPlayerProgress(UUID playerUuid) {
        Map<String, Double> result = new HashMap<>();
        String sql = "SELECT category, sold_value FROM perfsell_category_progress WHERE player_uuid = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, playerUuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    result.put(rs.getString("category"), rs.getDouble("sold_value"));
                }
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Kategori ilerlemesi okunamadı.", ex);
        }
        return result;
    }

    /**
     * Oyuncunun şu anki etkin çarpanını döner (kategorinin ilerlemesine göre).
     * Kategori bulunamazsa (materyal hiçbir kategoriye ait değilse) 1.0 döner.
     */
    public double getMultiplier(UUID playerUuid, Material material) {
        CategoryDefinition category = getCategoryForMaterial(material);
        if (category == null) return 1.0;
        double progress = getProgress(playerUuid, category.getId());
        return category.getMultiplierForProgress(progress);
    }

    /**
     * Bir satış tamamlandıktan SONRA çağrılır: verilen materyalin taban worth
     * toplamını (unitPrice * amount, kategori/VIP çarpanları OLMADAN) ilgili
     * kategorinin ilerlemesine ekler. Materyal hiçbir kategoriye ait değilse
     * hiçbir şey yapmaz.
     */
    public void addProgress(UUID playerUuid, Material material, double baseValueAdded) {
        CategoryDefinition category = getCategoryForMaterial(material);
        if (category == null || connection == null || baseValueAdded <= 0) return;

        String dbCategory = toPerfSellCategoryId(category.getId());
        Map<String, Double> playerCache = progressCache.computeIfAbsent(playerUuid, this::loadPlayerProgress);
        playerCache.merge(dbCategory, baseValueAdded, Double::sum);
        dirtyKeys.add(playerUuid + "|" + dbCategory);
    }

    private void flushDirty() {
        if (connection == null || dirtyKeys.isEmpty()) return;
        String sql = """
                INSERT INTO perfsell_category_progress (player_uuid, category, sold_value)
                VALUES (?, ?, ?)
                ON CONFLICT(player_uuid, category)
                DO UPDATE SET sold_value = excluded.sold_value
                """;
        Set<String> keys = new HashSet<>(dirtyKeys);
        try {
            connection.setAutoCommit(false);
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                for (String key : keys) {
                    int split = key.indexOf('|');
                    if (split <= 0) continue;
                    String uuid = key.substring(0, split);
                    String category = key.substring(split + 1);
                    Map<String, Double> cache = progressCache.get(UUID.fromString(uuid));
                    if (cache == null) continue;
                    Double value = cache.get(category);
                    if (value == null) continue;
                    ps.setString(1, uuid);
                    ps.setString(2, category);
                    ps.setDouble(3, value);
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            connection.commit();
            dirtyKeys.removeAll(keys);
        } catch (Exception ex) {
            try { connection.rollback(); } catch (SQLException ignored) {}
            plugin.getLogger().log(Level.WARNING, "Kategori ilerlemesi toplu kaydedilemedi.", ex);
        } finally {
            try { connection.setAutoCommit(true); } catch (SQLException ignored) {}
        }
    }

    /**
     * mevcut çarpan veritabanındaki kategori kimlikleri.
     * AzySell'in görünen kategori ID'leri farklı olsa bile aynı carpanlar.db
     * doğrudan takıldığında mevcut oyuncu ilerlemeleri okunur.
     */
    private String toPerfSellCategoryId(String azyCategoryId) {
        return switch (azyCategoryId.toLowerCase(java.util.Locale.ROOT)) {
            case "farm", "crops" -> "crops";
            case "mining", "ores" -> "ores";
            case "mobdrops", "mob_drops" -> "mob_drops";
            case "blocks" -> "blocks";
            case "combat", "armor_and_tools" -> "armor_and_tools";
            case "fishing", "fish" -> "fish";
            case "enchanting", "enchanted_books" -> "enchanted_books";
            case "potions" -> "potions";
            case "misc", "natural_items" -> "natural_items";
            default -> azyCategoryId;
        };
    }

    public List<CategoryDefinition> getCategories() {
        return new ArrayList<>(categories.values());
    }

    public CategoryDefinition getCategory(String id) {
        return categories.get(id);
    }
}

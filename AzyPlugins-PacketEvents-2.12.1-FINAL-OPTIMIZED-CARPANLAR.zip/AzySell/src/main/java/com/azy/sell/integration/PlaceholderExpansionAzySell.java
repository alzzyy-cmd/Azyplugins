package com.azy.sell.integration;

import com.azy.sell.AzySell;
import com.azy.sell.history.HistoryPeriod;
import com.azy.sell.history.SellHistoryManager;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class PlaceholderExpansionAzySell extends PlaceholderExpansion {
    private final AzySell plugin;
    private final Map<UUID, Cached> cache = new ConcurrentHashMap<>();

    public PlaceholderExpansionAzySell(AzySell plugin) { this.plugin = plugin; }

    @Override public @NotNull String getIdentifier() { return "azysell"; }
    @Override public @NotNull String getAuthor() { return "AzyPlugins"; }
    @Override public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "0";
        HistoryPeriod period;
        if (params.equalsIgnoreCase("total") || params.equalsIgnoreCase("total_earned") || params.equalsIgnoreCase("all_time_earned")) {
            period = HistoryPeriod.ALL_TIME;
        } else if (params.equalsIgnoreCase("daily_earned")) {
            period = HistoryPeriod.DAILY;
        } else if (params.equalsIgnoreCase("weekly_earned")) {
            period = HistoryPeriod.WEEKLY;
        } else {
            return null;
        }

        long now = System.currentTimeMillis();
        Cached old = cache.get(player.getUniqueId());
        if (old != null && now - old.time < 30_000L) return format(old.values.get(period));
        SellHistoryManager.PersonalTotals daily = plugin.getHistoryManager().getPersonalTotals(player.getUniqueId(), HistoryPeriod.DAILY);
        SellHistoryManager.PersonalTotals weekly = plugin.getHistoryManager().getPersonalTotals(player.getUniqueId(), HistoryPeriod.WEEKLY);
        SellHistoryManager.PersonalTotals all = plugin.getHistoryManager().getPersonalTotals(player.getUniqueId(), HistoryPeriod.ALL_TIME);
        Map<HistoryPeriod, Double> values = Map.of(HistoryPeriod.DAILY, daily.totalPrice(), HistoryPeriod.WEEKLY, weekly.totalPrice(), HistoryPeriod.ALL_TIME, all.totalPrice());
        cache.put(player.getUniqueId(), new Cached(now, values));
        return format(values.get(period));
    }

    private String format(Double value) { return value == null ? "0" : (value % 1 == 0 ? String.valueOf(value.longValue()) : String.format("%.2f", value)); }
    private record Cached(long time, Map<HistoryPeriod, Double> values) {}
}

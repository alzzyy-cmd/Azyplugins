package com.azy.sell.history;

import com.azy.sell.AzySell;
import org.bukkit.Material;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Satış geçmişini SQLite üzerinde tutar (DonutWorth2'nin sellhistory.yml'sine benzer
 * amaç, ama sorgulanabilir bir veritabanı formatında). Her satış işlemi için
 * (oyuncu, eşya, miktar, toplam_fiyat, tarih) kaydı tutulur.
 */
public class SellHistoryManager {

    private final AzySell plugin;
    private Connection connection;

    public SellHistoryManager(AzySell plugin) {
        this.plugin = plugin;
    }

    public void setup() {
        try {
            File dbFile = new File(plugin.getDataFolder(), "sellhistory.db");
            plugin.getDataFolder().mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());

            try (Statement st = connection.createStatement()) {
                st.execute("""
                        CREATE TABLE IF NOT EXISTS sell_history (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            player_uuid TEXT NOT NULL,
                            material TEXT NOT NULL,
                            amount INTEGER NOT NULL,
                            total_price REAL NOT NULL,
                            sold_at INTEGER NOT NULL
                        )
                        """);
                // Oyuncu bazlı özet (getSummary): WHERE player_uuid=? + GROUP BY material + SUM(amount, total_price)
                // tamamen bu index üzerinden karşılanır, ana tabloya (heap lookup) hiç inilmez.
                st.execute("""
                        CREATE INDEX IF NOT EXISTS idx_player_material_covering
                        ON sell_history(player_uuid, material, amount, total_price)
                        """);
                // Sunucu geneli sorgular (getGlobalTop / getGlobalDistinctItemCount / getGlobalTotals):
                // GROUP BY material zaten index sırasına göre geldiği için SQLite temp B-Tree kurmadan
                // sıralı taramayla gruplayabilir, COUNT(DISTINCT material) da bu index'ten anında okunur.
                st.execute("""
                        CREATE INDEX IF NOT EXISTS idx_material_covering
                        ON sell_history(material, amount, total_price)
                        """);
                // Eski tekil-kolon index kalmışsa (önceki sürümden) kaldır; artık gereksiz —
                // yukarıdaki composite index onun yerine de geçiyor ve fazladan disk/yazma maliyeti yaratmasın.
                st.execute("DROP INDEX IF EXISTS idx_player");
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "sellhistory.db açılamadı!", ex);
        }
    }

    public void recordSale(UUID playerUuid, Material material, int amount, double totalPrice) {
        if (connection == null) return;
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO sell_history (player_uuid, material, amount, total_price, sold_at) VALUES (?, ?, ?, ?, ?)")) {
            ps.setString(1, playerUuid.toString());
            ps.setString(2, material.name());
            ps.setInt(3, amount);
            ps.setDouble(4, totalPrice);
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Satış geçmişi kaydedilemedi", ex);
        }
    }

    /**
     * Oyuncunun eşya bazlı satış özetini SAYFALI döner. /satisgecmisi bunu kullanır.
     *
     * @param limit  kaç sonuç dönsün (bir sayfa boyutu, örn. 45)
     * @param offset kaç sonuç atlanacak (sayfa * limit)
     * @param sortMode sıralama modu (en pahalı / en ucuz / A-Z / Z-A)
     */
    public List<HistoryEntry> getSummary(UUID playerUuid, int limit, int offset, SortMode sortMode) {
        return getSummaryInternal(playerUuid, limit, offset, sortMode, HistoryPeriod.ALL_TIME);
    }

    private List<HistoryEntry> getSummaryInternal(UUID playerUuid, int limit, int offset, SortMode sortMode, HistoryPeriod period) {
        List<HistoryEntry> results = new ArrayList<>(); if (connection == null) return results;
        String orderBy = switch (sortMode) { case LOWEST_PRICE -> "total_price ASC"; case NAME_A_Z -> "material ASC"; case NAME_Z_A -> "material DESC"; case HIGHEST_PRICE -> "total_price DESC"; };
        String sql = period == HistoryPeriod.ALL_TIME
                ? "SELECT material, SUM(amount) total_amount, SUM(total_price) total_price FROM sell_history WHERE player_uuid = ? GROUP BY material ORDER BY " + orderBy
                : "SELECT material, SUM(amount) total_amount, SUM(total_price) total_price FROM sell_history WHERE player_uuid = ? AND sold_at >= ? GROUP BY material ORDER BY " + orderBy;
        try (PreparedStatement ps=connection.prepareStatement(sql)) {
            ps.setString(1,playerUuid.toString()); if(period!=HistoryPeriod.ALL_TIME) ps.setLong(2,System.currentTimeMillis()-period.getDurationMillis());
            try(ResultSet rs=ps.executeQuery()) { while(rs.next()){ Material m=Material.matchMaterial(rs.getString("material")); if(m!=null) results.add(new HistoryEntry(m,rs.getLong("total_amount"),rs.getDouble("total_price"))); } }
        } catch(SQLException ex){plugin.getLogger().log(Level.WARNING,"Satış geçmişi okunamadı",ex);}
        int from=Math.min(offset,results.size()), to=Math.min(from+limit,results.size()); return new ArrayList<>(results.subList(from,to));
    }

    public List<HistoryEntry> getSummary(UUID playerUuid, int limit, int offset, SortMode sortMode, HistoryPeriod period) {
        return getSummaryInternal(playerUuid, limit, offset, sortMode, period);
    }

    /** Geriye dönük uyumluluk için: varsayılan sıralama (en pahalı) ile çağırır. */
    public List<HistoryEntry> getSummary(UUID playerUuid, int limit, int offset) {
        return getSummary(playerUuid, limit, offset, SortMode.HIGHEST_PRICE);
    }

    /** Oyuncunun kaç FARKLI eşya çeşidi sattığı (sayfalama için toplam sayfa hesabında kullanılır). */
    public int getPlayerDistinctItemCount(UUID playerUuid) {
        if (connection == null) return 0;
        int count=0; String sql="SELECT DISTINCT material FROM sell_history WHERE player_uuid = ?";
        try(PreparedStatement ps=connection.prepareStatement(sql)){ps.setString(1,playerUuid.toString());try(ResultSet rs=ps.executeQuery()){while(rs.next())if(Material.matchMaterial(rs.getString(1))!=null)count++;}}catch(SQLException ex){plugin.getLogger().log(Level.WARNING,"Eşya çeşidi sayısı okunamadı",ex);}
        return count;
    }

    /**
     * SUNUCU GENELİ (tüm oyuncular toplamı) en çok satılan eşyalar, sayfalanabilir.
     * /tophistory admin komutu bunu kullanır: "hangi eşya toplam ne kadar satılmış,
     * ne kadar para kazandırmış" sorusuna cevap verir.
     *
     * @param limit  kaç sonuç dönsün (bir sayfa boyutu, örn. 45)
     * @param offset kaç sonuç atlanacak (sayfa * limit)
     * @param sortMode sıralama modu (en pahalı / en ucuz / A-Z / Z-A)
     */
    public List<HistoryEntry> getGlobalTop(int limit, int offset, SortMode sortMode) { return getGlobalTopInternal(limit, offset, sortMode, HistoryPeriod.ALL_TIME); }

    private List<HistoryEntry> getGlobalTopInternal(int limit,int offset,SortMode sortMode,HistoryPeriod period){
        List<HistoryEntry> results=new ArrayList<>(); if(connection==null)return results;
        String orderBy=switch(sortMode){case LOWEST_PRICE->"total_price ASC";case NAME_A_Z->"material ASC";case NAME_Z_A->"material DESC";case HIGHEST_PRICE->"total_price DESC";};
        String sql=period==HistoryPeriod.ALL_TIME?"SELECT material,SUM(amount) total_amount,SUM(total_price) total_price FROM sell_history GROUP BY material ORDER BY "+orderBy:"SELECT material,SUM(amount) total_amount,SUM(total_price) total_price FROM sell_history WHERE sold_at >= ? GROUP BY material ORDER BY "+orderBy;
        try(PreparedStatement ps=connection.prepareStatement(sql)){if(period!=HistoryPeriod.ALL_TIME)ps.setLong(1,System.currentTimeMillis()-period.getDurationMillis());try(ResultSet rs=ps.executeQuery()){while(rs.next()){Material m=Material.matchMaterial(rs.getString("material"));if(m!=null)results.add(new HistoryEntry(m,rs.getLong("total_amount"),rs.getDouble("total_price")));}}}catch(SQLException ex){plugin.getLogger().log(Level.WARNING,"Sunucu geneli satış istatistiği okunamadı",ex);}
        int from=Math.min(offset,results.size()),to=Math.min(from+limit,results.size());return new ArrayList<>(results.subList(from,to));
    }

    public List<HistoryEntry> getGlobalTop(int limit, int offset, SortMode sortMode, HistoryPeriod period) {
        return getGlobalTopInternal(limit, offset, sortMode, period);
    }

    /** Geriye dönük uyumluluk için: varsayılan sıralama (en pahalı) ile çağırır. */
    public List<HistoryEntry> getGlobalTop(int limit, int offset) {
        return getGlobalTop(limit, offset, SortMode.HIGHEST_PRICE);
    }

    /** Sunucu genelinde kaç FARKLI eşya çeşidi satılmış (sayfalama için toplam sayfa hesabında kullanılır). */
    public int getGlobalDistinctItemCount() {
        if(connection==null)return 0; int count=0; try(PreparedStatement ps=connection.prepareStatement("SELECT DISTINCT material FROM sell_history");ResultSet rs=ps.executeQuery()){while(rs.next())if(Material.matchMaterial(rs.getString(1))!=null)count++;}catch(SQLException ex){plugin.getLogger().log(Level.WARNING,"Eşya çeşidi sayısı okunamadı",ex);} return count;
    }

    public int getPlayerDistinctItemCount(UUID playerUuid, HistoryPeriod period) {
        if(period==HistoryPeriod.ALL_TIME)return getPlayerDistinctItemCount(playerUuid); int count=0;
        try(PreparedStatement ps=connection.prepareStatement("SELECT DISTINCT material FROM sell_history WHERE player_uuid=? AND sold_at>=?")){ps.setString(1,playerUuid.toString());ps.setLong(2,System.currentTimeMillis()-period.getDurationMillis());try(ResultSet rs=ps.executeQuery()){while(rs.next())if(Material.matchMaterial(rs.getString(1))!=null)count++;}}catch(SQLException ex){plugin.getLogger().log(Level.WARNING,"Zaman aralığı eşya çeşidi okunamadı",ex);} return count;
    }

    public int getGlobalDistinctItemCount(HistoryPeriod period) {
        if(period==HistoryPeriod.ALL_TIME)return getGlobalDistinctItemCount(); int count=0;
        try(PreparedStatement ps=connection.prepareStatement("SELECT DISTINCT material FROM sell_history WHERE sold_at>=?")){ps.setLong(1,System.currentTimeMillis()-period.getDurationMillis());try(ResultSet rs=ps.executeQuery()){while(rs.next())if(Material.matchMaterial(rs.getString(1))!=null)count++;}}catch(SQLException ex){plugin.getLogger().log(Level.WARNING,"Zaman aralığı sunucu eşya çeşidi okunamadı",ex);} return count;
    }

    /** Sunucu genelinde şimdiye kadar satılan toplam eşya sayısı ve toplam kazanılan para. */
    public GlobalTotals getGlobalTotals() {
        if (connection == null) return new GlobalTotals(0, 0);
        String sql = "SELECT SUM(amount) as total_amount, SUM(total_price) as total_price FROM sell_history";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new GlobalTotals(rs.getLong("total_amount"), rs.getDouble("total_price"));
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Sunucu geneli toplam okunamadı", ex);
        }
        return new GlobalTotals(0, 0);
    }

    public PersonalTotals getPersonalTotals(UUID playerUuid, HistoryPeriod period) {
        if (connection == null) return new PersonalTotals(0, 0);
        String filter = period.getDurationMillis() < 0 ? "" : " AND sold_at >= ?";
        String sql = "SELECT COALESCE(SUM(amount),0), COALESCE(SUM(total_price),0) FROM sell_history WHERE player_uuid = ?" + filter;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, playerUuid.toString());
            if (period.getDurationMillis() >= 0) ps.setLong(2, System.currentTimeMillis() - period.getDurationMillis());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new PersonalTotals(rs.getLong(1), rs.getDouble(2));
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Zaman aralığı kazancı okunamadı", ex);
        }
        return new PersonalTotals(0, 0);
    }

    public GlobalTotals getGlobalTotals(HistoryPeriod period) {
        if (connection == null) return new GlobalTotals(0, 0);
        String filter = period.getDurationMillis() < 0 ? "" : " WHERE sold_at >= ?";
        String sql = "SELECT COALESCE(SUM(amount),0), COALESCE(SUM(total_price),0) FROM sell_history" + filter;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            if (period.getDurationMillis() >= 0) ps.setLong(1, System.currentTimeMillis() - period.getDurationMillis());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return new GlobalTotals(rs.getLong(1), rs.getDouble(2));
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Zaman aralığı sunucu toplamı okunamadı", ex);
        }
        return new GlobalTotals(0, 0);
    }

    public record PersonalTotals(long totalAmount, double totalPrice) {}

    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ignored) {
            }
        }
    }

    public record HistoryEntry(Material material, long totalAmount, double totalPrice) {
    }

    public record GlobalTotals(long totalAmount, double totalPrice) {
    }
}

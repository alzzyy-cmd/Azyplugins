package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * CategoryItemsGui salt-okunur bilgi ekranıdır; eşya alınamaz/bırakılamaz.
 * Butonlar: geri dön, sayfa gezinme, ucuz/pahalı sıralama değiştirme.
 */
public class CategoryItemsGuiListener implements Listener {

    private final AzySell plugin;

    public CategoryItemsGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof CategoryItemsGui gui)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getInventory()) return;

        int slot = event.getRawSlot();
        if (slot == CategoryItemsGui.SLOT_BACK) {
            new CategoryProgressGui(plugin, gui.getCategory()).open(player);
        } else if (slot == CategoryItemsGui.SLOT_PREV) {
            new CategoryItemsGui(plugin, gui.getCategory(), gui.getPage() - 1, gui.isCheapestFirst()).open(player);
        } else if (slot == CategoryItemsGui.SLOT_NEXT) {
            new CategoryItemsGui(plugin, gui.getCategory(), gui.getPage() + 1, gui.isCheapestFirst()).open(player);
        } else if (slot == CategoryItemsGui.SLOT_SORT) {
            new CategoryItemsGui(plugin, gui.getCategory(), 0, !gui.isCheapestFirst()).open(player);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof CategoryItemsGui) {
            event.setCancelled(true);
        }
    }
}

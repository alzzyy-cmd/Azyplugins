package com.azy.sell;

import com.azy.sell.category.CategoryItemsGuiListener;
import com.azy.sell.category.CategoryProgressGuiListener;
import com.azy.sell.category.CategoryProgressManager;
import com.azy.sell.category.MultiplierSummaryGui;
import com.azy.sell.category.MultiplierSummaryGuiListener;
import com.azy.sell.gui.SellGui;
import com.azy.sell.gui.SellGuiListener;
import com.azy.sell.history.SellHistoryGui;
import com.azy.sell.history.SellHistoryGuiListener;
import com.azy.sell.history.SellHistoryManager;
import com.azy.sell.history.TopHistoryGui;
import com.azy.sell.history.TopHistoryGuiListener;
import com.azy.sell.items.SellAxeItem;
import com.azy.sell.items.SellAxeListener;
import com.azy.sell.items.SellAxeTimeListener;
import com.azy.sell.integration.PlaceholderExpansionAzySell;
import com.azy.sell.autosell.AutoSellManager;
import com.azy.sell.autosell.SellFilterGuiListener;
import com.azy.sell.multiplier.PriceCalculator;
import com.azy.sell.multiplier.SellMultiplierManager;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AzySell extends JavaPlugin implements TabCompleter {

    private static final Pattern HEX_PATTERN = Pattern.compile("#([A-Fa-f0-9]{6})");

    /** Sunucu konsoluna onEnable() sırasında basılan ASCII-art logo. Sadece konsola (server log) yazılır, oyun içi chat'e gönderilmez. */
    private static final String[] BANNER = {
            "   _        _____   __   __   _____    _____    _        _     ",
            "  / \\      |__  /|  \\ \\ / /  /  ___|  |  ___|  | |      | |    ",
            " / _ \\       / /     \\ V /   \\ `--.   | |__    | |      | |    ",
            "/ ___ \\     / /_      | |     `--. \\  |  __|   | |___   | |___ ",
            "/_/   \\_\\  /____|     |_|    /\\__/ /  |_____|  \\_____|  \\_____|",
    };

    private EconomyManager economyManager;
    private PriceCalculator priceCalculator;
    private SellMultiplierManager multiplierManager;
    private SellHistoryManager historyManager;
    private SellService sellService;
    private SellAxeItem sellAxeItem;
    private CategoryProgressManager categoryProgressManager;private FileConfiguration sellAxeConfig;
    private AutoSellManager autoSellManager;

    @Override
    public void onEnable() {
        printBanner();
        saveDefaultConfig();
        saveResource("sellaxe.yml", false);
        this.sellAxeConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "sellaxe.yml"));

        // AzyWorth zorunlu bağımlılık (plugin.yml -> depend). Yüklü değilse Bukkit
        // bu plugin'i zaten hiç enable etmez, ama savunmacı programlama için kontrol ediyoruz.
        this.priceCalculator = new PriceCalculator(this);
        if (!priceCalculator.linkAzyWorth()) {
            getLogger().severe("AzyWorth bulunamadı! AzySell çalışamaz, devre dışı bırakılıyor.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.economyManager = new EconomyManager(this);
        if (!economyManager.setup()) {
            getLogger().warning("Vault veya bir ekonomi plugin'i (EssentialsX vb.) bulunamadı! Satış kazançları eklenemeyecek.");
        }

        this.multiplierManager = new SellMultiplierManager(this);
        multiplierManager.load();

        this.historyManager = new SellHistoryManager(this);
        historyManager.setup();

        this.categoryProgressManager = new CategoryProgressManager(this);
        categoryProgressManager.loadCategories();
        categoryProgressManager.setup();

        this.sellService = new SellService(this);
        this.autoSellManager = new AutoSellManager(this);
        autoSellManager.load();
        this.sellAxeItem = new SellAxeItem(this);

        if (getCommand("sat") != null) getCommand("sat").setTabCompleter(this);
        if (getCommand("sellaxe") != null) getCommand("sellaxe").setTabCompleter(this);
        if (getCommand("azysellcarpan") != null) getCommand("azysellcarpan").setTabCompleter(this);

        getServer().getPluginManager().registerEvents(new SellGuiListener(this), this);
        getServer().getPluginManager().registerEvents(new CategoryProgressGuiListener(this), this);
        getServer().getPluginManager().registerEvents(new CategoryItemsGuiListener(this), this);
        getServer().getPluginManager().registerEvents(new MultiplierSummaryGuiListener(this), this);
        getServer().getPluginManager().registerEvents(new SellAxeListener(this, sellAxeItem), this);
        getServer().getPluginManager().registerEvents(new SellFilterGuiListener(this), this);
        SellAxeTimeListener axeTimeListener = new SellAxeTimeListener(this, sellAxeItem);
        axeTimeListener.start();

        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new PlaceholderExpansionAzySell(this).register();
            getLogger().info("PlaceholderAPI satış kazancı placeholder'ları etkin.");
        }
        getServer().getPluginManager().registerEvents(new TopHistoryGuiListener(this), this);
        getServer().getPluginManager().registerEvents(new SellHistoryGuiListener(this), this);

        // SmartSpawner entegrasyonu: sunucudaki diğer plugin'ler (SmartSpawner
        // dahil) muhtemelen bu noktada zaten yüklenmiş olur (onEnable sırası
        // plugin.yml'deki 'depend'/'softdepend' ve yükleme sırasına göre belirlenir;
        // SmartSpawner AzySell'den önce yüklenmişse tespit garantidir. Aksi halde
        // tryEnable sessizce hiçbir şey yapmaz, hata vermez).

        getLogger().info("AzySell aktif edildi.");
    }

    /** ASCII banner'ı sunucu konsoluna satır satır yazar (renklendirme yok, düz metin). */
    private void printBanner() {
        for (String line : BANNER) {
            getLogger().info(line);
        }
    }

    @Override
    public void onDisable() {
        if (historyManager != null) {
            historyManager.close();
        }
        if (categoryProgressManager != null) {
            categoryProgressManager.close();
        }
        if (autoSellManager != null) autoSellManager.save();
        getLogger().info("AzySell devre dışı bırakıldı.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase()) {
            case "sat" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                    return true;
                }
                if (!player.hasPermission("azysell.use")) {
                    player.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                if (args.length > 0 && (args[0].equalsIgnoreCase("auto") || args[0].equalsIgnoreCase("otomatik"))) {
                    if (args.length >= 2 && (args[1].equalsIgnoreCase("toggle") || args[1].equalsIgnoreCase("on") || args[1].equalsIgnoreCase("aç") || args[1].equalsIgnoreCase("off") || args[1].equalsIgnoreCase("kapat"))) {
                        boolean enabled;
                        if (args[1].equalsIgnoreCase("on") || args[1].equalsIgnoreCase("aç")) {
                            enabled = autoSellManager.setEnabled(player, true);
                        } else if (args[1].equalsIgnoreCase("off") || args[1].equalsIgnoreCase("kapat")) {
                            enabled = autoSellManager.setEnabled(player, false);
                        } else {
                            enabled = autoSellManager.toggle(player);
                        }
                        player.sendMessage(msg(enabled ? "&aOtomatik satış açıldı." : "&cOtomatik satış kapatıldı."));
                    } else {
                        autoSellManager.openFilter(player);
                    }
                    return true;
                }
                if (args.length > 0 && (args[0].equalsIgnoreCase("filter") || args[0].equalsIgnoreCase("filtre"))) {
                    autoSellManager.openFilter(player);
                    return true;
                }
                new SellGui(this).open(player);
                return true;
            }
            case "sellmultiplier", "satcarpan", "sellmulti", "carpan" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                    return true;
                }
                if (!player.hasPermission("azysell.use")) {
                    player.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                new MultiplierSummaryGui(this).open(player);
                return true;
            }
            case "satisgecmisi" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                    return true;
                }
                new SellHistoryGui(this, player.getUniqueId()).open(player);
                return true;
            }
            case "tophistory" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                    return true;
                }
                if (!player.hasPermission("azysell.admin")) {
                    player.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                new TopHistoryGui(this).open(player);
                return true;
            }
            case "sellaxe" -> {
                if (!sender.hasPermission("azysell.axe.admin")) {
                    sender.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                if (args.length < 3 || !args[0].equalsIgnoreCase("give")) {
                    sender.sendMessage(msg("&cKullanım: /sellaxe give <oyuncu> time <süre>"));
                    sender.sendMessage(msg("&cKullanım: /sellaxe give <oyuncu> usage <sayı>"));
                    return true;
                }
                Player target = getServer().getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage(msg("&cOyuncu bulunamadı veya çevrimdışı."));
                    return true;
                }
                ItemStack item;
                if (args[2].equalsIgnoreCase("usage") && args.length >= 4) {
                    try {
                        int uses = Integer.parseInt(args[3]);
                        if (uses <= 0) throw new NumberFormatException();
                        item = sellAxeItem.createUsage(uses);
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(msg("&cKullanım sayısı pozitif bir tam sayı olmalı."));
                        return true;
                    }
                } else if (args[2].equalsIgnoreCase("time") && args.length >= 4) {
                    long duration = parseDuration(args[3]);
                    if (duration <= 0) {
                        sender.sendMessage(msg("&cGeçersiz süre. Örnek: 1d, 12h, 30m."));
                        return true;
                    }
                    item = sellAxeItem.createTime(duration);
                } else {
                    sender.sendMessage(msg("&cKullanım: /sellaxe give <oyuncu> time <süre> veya usage <sayı>"));
                    return true;
                }
                java.util.Map<Integer, ItemStack> leftovers = target.getInventory().addItem(item);
                for (ItemStack leftover : leftovers.values()) {
                    target.getWorld().dropItemNaturally(target.getLocation(), leftover);
                }
                sender.sendMessage(msg("&aSatış baltası &f" + target.getName() + " &aadlı oyuncuya verildi."));
                return true;
            }
            case "azysellreload" -> {
                if (!sender.hasPermission("azysell.reload")) {
                    sender.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                reloadConfig();
                sellAxeConfig = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "sellaxe.yml"));
                multiplierManager.load();
                categoryProgressManager.loadCategories();
                sender.sendMessage(msg("&aAzySell configleri yeniden yüklendi."));
                return true;
            }
            case "azysellcarpan" -> {
                Player target;
                if (args.length > 0) {
                    target = getServer().getPlayer(args[0]);
                    if (target == null) {
                        sender.sendMessage(msg("&cOyuncu bulunamadı veya çevrimdışı."));
                        return true;
                    }
                } else if (sender instanceof Player p) {
                    target = p;
                } else {
                    sender.sendMessage(msg("&cKonsoldan kullanırken bir oyuncu adı belirtmelisin."));
                    return true;
                }
                double extra = multiplierManager.getExtraMultiplier(target);
                double global = priceCalculator.getGlobalMultiplier();
                sender.sendMessage(msg("&7" + target.getName() + " &7için:"));
                sender.sendMessage(msg("&7- Global çarpan: &f" + global + "x"));
                sender.sendMessage(msg("&7- VIP ekstra çarpan: &f+" + (extra * 100) + "%"));
                sender.sendMessage(msg("&7- Toplam etkin çarpan: &a" + (global * (1 + extra)) + "x"));
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(java.util.Locale.ROOT);
        if (name.equals("sat")) {
            if (args.length == 1) return partial(args[0], java.util.List.of("auto", "filter", "otomatik", "filtre"));
            if (args.length == 2 && (args[0].equalsIgnoreCase("auto") || args[0].equalsIgnoreCase("otomatik"))) return partial(args[1], java.util.List.of("toggle", "on", "off", "aç", "kapat"));
            return java.util.Collections.emptyList();
        }
        if (name.equals("sellaxe")) {
            if (args.length == 1) return partial(args[0], java.util.List.of("give"));
            if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
                return getServer().getOnlinePlayers().stream().map(Player::getName)
                        .filter(n -> n.toLowerCase(java.util.Locale.ROOT).startsWith(args[1].toLowerCase(java.util.Locale.ROOT)))
                        .sorted(String.CASE_INSENSITIVE_ORDER).toList();
            }
            if (args.length == 3 && args[0].equalsIgnoreCase("give")) return partial(args[2], java.util.List.of("time", "usage"));
            return java.util.Collections.emptyList();
        }
        if (name.equals("azysellcarpan")) {
            return getServer().getOnlinePlayers().stream().map(Player::getName)
                    .filter(n -> args.length == 1 && n.toLowerCase(java.util.Locale.ROOT).startsWith(args[0].toLowerCase(java.util.Locale.ROOT)))
                    .sorted(String.CASE_INSENSITIVE_ORDER).toList();
        }
        return java.util.Collections.emptyList();
    }

    private java.util.List<String> partial(String input, java.util.List<String> options) {
        String q = input == null ? "" : input.toLowerCase(java.util.Locale.ROOT);
        return options.stream().filter(o -> o.toLowerCase(java.util.Locale.ROOT).startsWith(q)).toList();
    }

    private long parseDuration(String raw) {
        Matcher m = Pattern.compile("(?i)^(\\d+)([smhdw])$").matcher(raw.trim());
        if (!m.matches()) return -1;
        try {
            long value = Long.parseLong(m.group(1));
            return switch (m.group(2).toLowerCase()) {
                case "s" -> Math.multiplyExact(value, 1_000L);
                case "m" -> Math.multiplyExact(value, 60_000L);
                case "h" -> Math.multiplyExact(value, 3_600_000L);
                case "d" -> Math.multiplyExact(value, 86_400_000L);
                case "w" -> Math.multiplyExact(value, 604_800_000L);
                default -> -1;
            };
        } catch (ArithmeticException | NumberFormatException ex) {
            return -1;
        }
    }

    public AutoSellManager getAutoSellManager() { return autoSellManager; }

    public String msg(String raw) {
        Matcher matcher = HEX_PATTERN.matcher(raw);
        StringBuilder buffer = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.toCharArray()) {
                replacement.append('§').append(c);
            }
            matcher.appendReplacement(buffer, replacement.toString());
        }
        matcher.appendTail(buffer);
        return ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }

    public FileConfiguration getSellAxeConfig() { return sellAxeConfig; }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public PriceCalculator getPriceCalculator() {
        return priceCalculator;
    }

    public SellMultiplierManager getMultiplierManager() {
        return multiplierManager;
    }

    public SellHistoryManager getHistoryManager() {
        return historyManager;
    }

    public SellService getSellService() {
        return sellService;
    }

    public SellAxeItem getSellAxeItem() {
        return sellAxeItem;
    }

    public CategoryProgressManager getCategoryProgressManager() {
        return categoryProgressManager;
    }
}

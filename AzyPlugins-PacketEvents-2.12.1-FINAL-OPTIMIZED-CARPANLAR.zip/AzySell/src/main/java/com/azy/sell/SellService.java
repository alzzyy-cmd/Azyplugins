package com.azy.sell;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.block.ShulkerBox;

import java.util.HashMap;
import java.util.Map;

/**
 * Satışın gerçekleştiği TEK merkezi yer. Hem Sell GUI (envanter kapanınca)
 * hem Sell Axe (sandık kırılınca) burayı çağırır.
 *
 * ÖNEMLİ DÜZELTME (shulker box bug'ı):
 * Önceki sürüm, bir ShulkerBox ItemStack'ini sadece Material.SHULKER_BOX olarak
 * görüp worth.yml'deki shulker fiyatını (örn. 150) veriyordu; kutunun İÇİNDEKİ
 * eşyaların (örn. toplam 1.000.000 değerinde eşya) worth'ü HİÇ HESABA KATILMIYORDU
 * ve o eşyalar kutuyla birlikte kalıcı olarak siliniyordu (para karşılığı verilmeden).
 *
 * Şimdi: bir slotta shulker box (veya renkli varyantları) tespit edilirse,
 * ÖNCE BlockStateMeta üzerinden içindeki envantere bakılır, içindeki her item
 * ayrı ayrı fiyatlandırılıp toplama eklenir, SONRA kutunun kendi worth'ü eklenir.
 * Böylece "1m değerinde eşya + 150 değerinde kutu" = 1.000.150 olarak satılır,
 * hiçbir değer kaybolmaz.
 */
public class SellService {

    private final AzySell plugin;

    public SellService(AzySell plugin) {
        this.plugin = plugin;
    }

    /**
     * Verilen envanterdeki tüm satılabilir eşyaları satar (shulker box içerikleri dahil).
     * Satılamayan (fiyatı olmayan) eşyalara dokunmaz, olduğu gibi bırakır.
     *
     * ÖNEMLİ: Vault/EssentialsX para yatırma işlemi BAŞARISIZ olursa (ekonomi eklentisi
     * işlemi reddederse), satılan eşyalar SLOT'LARINA GERİ KONUR ve satış hiç
     * gerçekleşmemiş gibi ele alınır. Önceki sürüm bunu kontrol etmiyordu; yani para
     * yatma başarısız olsa bile eşyalar zaten silinmiş oluyordu - oyuncu hem eşyasını
     * hem parasını kaybedebiliyordu. Artık böyle bir kayıp mümkün değil.
     */
    public SellResult sellInventory(Player player, Inventory inventory) {
        return sellInventory(player, inventory, 1.0);
    }

    public SellResult sellInventory(Player player, Inventory inventory, double criticalMultiplier) {
        Map<Material, Integer> soldCounts = new HashMap<>();
        Map<Material, Double> soldTotals = new HashMap<>();
        Map<Integer, ItemStack> removedSlots = new HashMap<>();
        double totalEarned = 0;

        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (stack == null || stack.getType().isAir()) continue;

            // Özel AzySell eşyaları asla satılamaz.
            if (plugin.getSellAxeItem() != null &&
                    plugin.getSellAxeItem().isSellAxe(stack)) {
                continue;
            }

            ItemStack original = stack.clone();
            SellLine line = priceStack(player, stack, soldCounts, soldTotals, criticalMultiplier);
            if (line.total() <= 0) continue;

            totalEarned += line.total();
            if (line.removeWholeStack()) {
                removedSlots.put(slot, original);
                inventory.setItem(slot, null);
            } else if (line.replacement() != null) {
                removedSlots.put(slot, original);
                inventory.setItem(slot, line.replacement());
            }
        }

        if (totalEarned <= 0) return new SellResult(0, 0, null);

        if (!plugin.getEconomyManager().deposit(player, totalEarned)) {
            // Ekonomi başarısızsa, orijinal stack'leri geri yükle; shulker içeriği de korunur.
            for (Map.Entry<Integer, ItemStack> entry : removedSlots.entrySet()) {
                inventory.setItem(entry.getKey(), entry.getValue());
            }
            player.sendMessage(plugin.msg("&cSatış işlemi tamamlanamadı. Eşyaların tamamen iade edildi."));
            return new SellResult(0, 0, null);
        }

        int totalItems = soldCounts.values().stream().mapToInt(Integer::intValue).sum();
        for (Map.Entry<Material, Integer> entry : soldCounts.entrySet()) {
            double actualTotal = soldTotals.getOrDefault(entry.getKey(), 0.0);
            plugin.getHistoryManager().recordSale(player.getUniqueId(), entry.getKey(), entry.getValue(), actualTotal);
            plugin.getPriceCalculator().recordMarketSale(entry.getKey(), entry.getValue());

            // Kategori ilerlemesi satışın gerçek taban değerinden beslenir.
            double baseUnitValue = plugin.getPriceCalculator().getBaseValue(entry.getKey());
            plugin.getCategoryProgressManager().addProgress(player.getUniqueId(), entry.getKey(),
                    baseUnitValue * entry.getValue());
        }

        announceSale(player, totalItems, totalEarned);
        return new SellResult(totalItems, totalEarned, null);
    }

    /** Tek bir envanter stack'ini otomatik satış için satar. */
    public SellResult sellStack(Player player, ItemStack stack, boolean announce) {
        if (stack == null || stack.getType().isAir()) return new SellResult(0, 0, null);
        if (plugin.getSellAxeItem() != null &&
                plugin.getSellAxeItem().isSellAxe(stack)) {
            return new SellResult(0, 0, null);
        }

        Map<Material, Integer> soldCounts = new HashMap<>();
        Map<Material, Double> soldTotals = new HashMap<>();
        SellLine line = priceStack(player, stack.clone(), soldCounts, soldTotals, 1.0);
        if (line.total() <= 0) return new SellResult(0, 0, null);
        if (!plugin.getEconomyManager().deposit(player, line.total())) return new SellResult(0, 0, null);

        for (Map.Entry<Material, Integer> entry : soldCounts.entrySet()) {
            double actualTotal = soldTotals.getOrDefault(entry.getKey(), 0.0);
            plugin.getHistoryManager().recordSale(player.getUniqueId(), entry.getKey(), entry.getValue(), actualTotal);
            plugin.getPriceCalculator().recordMarketSale(entry.getKey(), entry.getValue());
            double baseUnitValue = plugin.getPriceCalculator().getBaseValue(entry.getKey());
            plugin.getCategoryProgressManager().addProgress(player.getUniqueId(), entry.getKey(),
                    baseUnitValue * entry.getValue());
        }

        int totalItems = soldCounts.values().stream().mapToInt(Integer::intValue).sum();
        if (announce) announceSale(player, totalItems, line.total());
        return new SellResult(totalItems, line.total(), line.removeWholeStack() ? null : line.replacement());
    }

    /**
     * Bir stack'i fiyatlandırır. Shulker içindeki fiyatlı eşyalar satılır; fiyatı
     * olmayan içerikler korunur. Kutu ancak içerik tamamen satılabilir durumdaysa
     * ve kutunun kendisine fiyat verilmişse satılır. Böylece hiçbir eşya sessizce
     * yok olmaz.
     */
    private SellLine priceStack(Player player, ItemStack stack,
                                Map<Material, Integer> soldCounts,
                                Map<Material, Double> soldTotals,
                                double criticalMultiplier) {
        return priceStack(player, stack, soldCounts, soldTotals, criticalMultiplier, 1);
    }

    /**
     * Bir stack'i fiyatlandırır. Shulker içindeki fiyatlı eşyalar satılır; fiyatı
     * olmayan içerikler korunur. Kutu ancak içerik tamamen satılabilir durumdaysa
     * ve kutunun kendisine fiyat verilmişse satılır. Böylece hiçbir eşya sessizce
     * yok olmaz. copiesMultiplier, iç içe shulker kutularındaki toplam kopya sayısını
     * doğru hesaplamak için kullanılır.
     */
    private SellLine priceStack(Player player, ItemStack stack,
                                Map<Material, Integer> soldCounts,
                                Map<Material, Double> soldTotals,
                                double criticalMultiplier,
                                int copiesMultiplier) {
        if (stack == null || stack.getType().isAir() || copiesMultiplier <= 0) return SellLine.empty();

        if (isShulkerBox(stack.getType()) && stack.getItemMeta() instanceof BlockStateMeta blockStateMeta
                && blockStateMeta.getBlockState() instanceof ShulkerBox shulkerBox) {
            ItemStack modifiedStack = stack.clone();
            BlockStateMeta modifiedMeta = (BlockStateMeta) modifiedStack.getItemMeta();
            if (!(modifiedMeta.getBlockState() instanceof ShulkerBox modifiedBox)) return SellLine.empty();

            double total = 0;
            boolean changed = false;
            boolean hasUnpricedContents = false;
            int nestedCopies = Math.multiplyExact(Math.max(1, copiesMultiplier), Math.max(1, stack.getAmount()));

            ItemStack[] contents = shulkerBox.getInventory().getContents();
            for (int slot = 0; slot < contents.length; slot++) {
                ItemStack inner = contents[slot];
                if (inner == null || inner.getType().isAir()) continue;

                ItemStack innerOriginal = inner.clone();
                SellLine innerLine = priceStack(player, inner, soldCounts, soldTotals, criticalMultiplier, nestedCopies);
                if (innerLine.hasUnpricedContents()) hasUnpricedContents = true;
                if (innerLine.total() > 0) {
                    total += innerLine.total();
                    changed = true;
                    if (innerLine.removeWholeStack()) {
                        modifiedBox.getInventory().setItem(slot, null);
                    } else if (innerLine.replacement() != null) {
                        modifiedBox.getInventory().setItem(slot, innerLine.replacement());
                    }
                } else {
                    modifiedBox.getInventory().setItem(slot, innerOriginal);
                    hasUnpricedContents = true;
                }
            }

            modifiedMeta.setBlockState(modifiedBox);
            modifiedStack.setItemMeta(modifiedMeta);

            boolean boxPriced = plugin.getPriceCalculator().hasPrice(stack);
            if (boxPriced && !hasUnpricedContents) {
                double unit = plugin.getPriceCalculator().getUnitSellPrice(player, stack);
                if (unit > 0) {
                    int boxAmount = Math.multiplyExact(Math.max(1, stack.getAmount()), Math.max(1, copiesMultiplier));
                    double boxTotal = unit * boxAmount * criticalMultiplier;
                    total += boxTotal;
                    soldCounts.merge(stack.getType(), boxAmount, Integer::sum);
                    soldTotals.merge(stack.getType(), boxTotal, Double::sum);
                    return new SellLine(total, false, null, true);
                }
            }

            if (changed) return new SellLine(total, hasUnpricedContents, modifiedStack, false);
            return SellLine.empty();
        }

        if (!plugin.getPriceCalculator().hasPrice(stack)) return SellLine.empty();
        double unitPrice = plugin.getPriceCalculator().getUnitSellPrice(player, stack);
        if (unitPrice <= 0) return SellLine.empty();
        int amount = Math.multiplyExact(Math.max(1, stack.getAmount()), Math.max(1, copiesMultiplier));
        double total = unitPrice * amount * criticalMultiplier;
        soldCounts.merge(stack.getType(), amount, Integer::sum);
        soldTotals.merge(stack.getType(), total, Double::sum);
        return new SellLine(total, false, null, true);
    }

    private boolean isShulkerBox(Material material) {
        return material.name().endsWith("SHULKER_BOX");
    }

    private record SellLine(double total, boolean hasUnpricedContents, ItemStack replacement, boolean removeWholeStack) {
        static SellLine empty() { return new SellLine(0, false, null, false); }
    }

    /**
     * Kalıcı satış duyurusu: hem action bar (anlık) hem CHAT (kalıcı, scroll edilebilir).
     */
    private void announceSale(Player player, int totalItems, double totalEarned) {
        String template = plugin.getConfig().getString("messages.sold",
                "&a{amount} eşya sattın, kazanç: &f${total}&a!");
        String formatted = template
                .replace("{amount}", String.valueOf(totalItems))
                .replace("{total}", plugin.getEconomyManager().format(totalEarned));

        player.sendMessage(plugin.msg(formatted));
    }

    public record SellResult(int totalItems, double totalEarned, ItemStack replacement) {
        public boolean isEmpty() {
            return totalItems <= 0;
        }
    }
}

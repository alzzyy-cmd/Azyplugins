package com.azy.sell.items;

import com.azy.sell.AzySell;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.configuration.ConfigurationSection;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Sell Axe: sandığı kırınca içindeki tüm satılabilir eşyaları anında satar.
 *
 * TAMAMEN YML EDİTLENEBİLİR: Bu sınıf hiçbir sabit değer içermez — materyal,
 * isim, lore, kırılmazlık, gizleme flag'leri VE büyüler (enchantment) tamamen
 * config.yml'deki "sell-axe" bölümünden okunur.
 *
 * Büyüler için Bukkit'in "addUnsafeEnchantment" API'si kullanılır — böylece
 * vanilla max seviyesinin üstünde bir seviye yazsan bile aynen uygulanır.
 */
public class SellAxeItem {

    private static final String KEY_NAME = "azysell_axe";
    private static final String KEY_USES_LEFT_NAME = "azysell_axe_uses_left";
    private static final String KEY_EXPIRES_AT = "azysell_axe_expires_at";
    private static final String KEY_REMAINING_MILLIS = "azysell_axe_remaining_millis";
    private static final String KEY_INSTANCE = "azysell_axe_instance";

    private final AzySell plugin;
    private final NamespacedKey markerKey;
    private final NamespacedKey usesLeftKey;
    private final NamespacedKey expiresAtKey;
    private final NamespacedKey remainingMillisKey;
    private final NamespacedKey instanceKey;

    public SellAxeItem(AzySell plugin) {
        this.plugin = plugin;
        this.markerKey = new NamespacedKey(plugin, KEY_NAME);
        this.usesLeftKey = new NamespacedKey(plugin, KEY_USES_LEFT_NAME);
        this.expiresAtKey = new NamespacedKey(plugin, KEY_EXPIRES_AT);
        this.remainingMillisKey = new NamespacedKey(plugin, KEY_REMAINING_MILLIS);
        this.instanceKey = new NamespacedKey(plugin, KEY_INSTANCE);
    }

    public ItemStack create() {
        return createUsage(getMaxUses());
    }

    public ItemStack createUsage(int uses) {

        Material material = Material.matchMaterial(
                plugin.getSellAxeConfig().getString("sell-axe.material", "NETHERITE_AXE"));
        if (material == null) material = Material.GOLDEN_AXE;

        ItemStack axe = new ItemStack(material);
        ItemMeta meta = axe.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(markerKey, PersistentDataType.BYTE, (byte) 1);
            meta.getPersistentDataContainer().set(instanceKey, PersistentDataType.STRING, java.util.UUID.randomUUID().toString());

            if (uses > 0) {
                meta.getPersistentDataContainer().set(usesLeftKey, PersistentDataType.INTEGER, uses);
            }

            if (plugin.getSellAxeConfig().getBoolean("sell-axe.unbreakable", true)) {
                meta.setUnbreakable(true);
            }
            if (plugin.getSellAxeConfig().getBoolean("sell-axe.hide-enchantments", true)) {
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }
            if (plugin.getSellAxeConfig().getBoolean("sell-axe.hide-attributes", true)) {
                meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
                meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE);
            }

            axe.setItemMeta(meta);
        }

        applyConfiguredEnchantments(axe);
        refreshLore(axe);
        return axe;
    }

    public ItemStack createTime(long durationMillis) {
        ItemStack axe = createUsage(-1);
        ItemMeta meta = axe.getItemMeta();
        if (meta != null) {
            // Süre mutlak saat değil, oyuncu üzerindeyken tüketilecek kalan aktif süredir.
            meta.getPersistentDataContainer().set(remainingMillisKey, PersistentDataType.LONG, durationMillis);
            meta.getPersistentDataContainer().remove(expiresAtKey);
            axe.setItemMeta(meta);
        }
        refreshLore(axe);
        return axe;
    }

    public ItemStack createUsage(int uses, boolean ignored) { return createUsage(uses); }

    private void applyConfiguredEnchantments(ItemStack axe) {
        for (Enchantment existing : new ArrayList<>(axe.getEnchantments().keySet())) {
            axe.removeEnchantment(existing);
        }

        ConfigurationSection enchSection = plugin.getSellAxeConfig().getConfigurationSection("sell-axe.enchantments");
        if (enchSection == null) return;

        for (String key : enchSection.getKeys(false)) {
            int level = enchSection.getInt(key, 0);
            if (level <= 0) continue;
            Enchantment ench = resolveEnchantment(key);
            if (ench == null) {
                plugin.getLogger().warning("Bilinmeyen büyü, sell-axe.enchantments'ta atlandı: " + key);
                continue;
            }
            axe.addUnsafeEnchantment(ench, level);
        }
    }

    @SuppressWarnings("deprecation")
    private Enchantment resolveEnchantment(String rawKey) {
        String key = rawKey.trim().toLowerCase(Locale.ROOT);
        NamespacedKey nsk = NamespacedKey.minecraft(key);
        Enchantment ench = org.bukkit.Registry.ENCHANTMENT.get(nsk);
        if (ench != null) return ench;

        ench = Enchantment.getByName(rawKey.trim().toUpperCase(Locale.ROOT));
        if (ench != null) return ench;

        String upper = rawKey.trim().toUpperCase(Locale.ROOT);
        NamespacedKey mapped = switch (upper) {
            case "DIG_SPEED", "EFFICIENCY" -> NamespacedKey.minecraft("efficiency");
            case "DURABILITY", "UNBREAKING" -> NamespacedKey.minecraft("unbreaking");
            case "LOOT_BONUS_BLOCKS", "FORTUNE" -> NamespacedKey.minecraft("fortune");
            case "LOOT_BONUS_MOBS", "LOOTING" -> NamespacedKey.minecraft("looting");
            case "DAMAGE_ALL", "SHARPNESS" -> NamespacedKey.minecraft("sharpness");
            case "DAMAGE_UNDEAD", "SMITE" -> NamespacedKey.minecraft("smite");
            case "DAMAGE_ARTHROPODS", "BANE_OF_ARTHROPODS" -> NamespacedKey.minecraft("bane_of_arthropods");
            case "KNOCKBACK" -> NamespacedKey.minecraft("knockback");
            case "FIRE_ASPECT" -> NamespacedKey.minecraft("fire_aspect");
            case "MENDING" -> NamespacedKey.minecraft("mending");
            case "SILK_TOUCH" -> NamespacedKey.minecraft("silk_touch");
            case "VANISHING_CURSE" -> NamespacedKey.minecraft("vanishing_curse");
            case "BINDING_CURSE" -> NamespacedKey.minecraft("binding_curse");
            default -> null;
        };
        if (mapped == null) return null;
        return org.bukkit.Registry.ENCHANTMENT.get(mapped);
    }

    public boolean isSellAxe(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(markerKey, PersistentDataType.BYTE);
    }

    public int getMaxUses() {
        return plugin.getSellAxeConfig().getInt("sell-axe.max-uses", 2500);
    }

    public int getUsesLeft(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) return -1;
        ItemMeta meta = stack.getItemMeta();
        if (!meta.getPersistentDataContainer().has(usesLeftKey, PersistentDataType.INTEGER)) return -1;
        Integer value = meta.getPersistentDataContainer().get(usesLeftKey, PersistentDataType.INTEGER);
        return value == null ? -1 : value;
    }

    public int decrementUses(ItemStack stack) {
        int current = getUsesLeft(stack);
        if (current < 0) return -1;

        int updated = Math.max(0, current - 1);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(usesLeftKey, PersistentDataType.INTEGER, updated);
            stack.setItemMeta(meta);
        }
        refreshLore(stack);
        return updated;
    }

    public void refreshLore(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return;

        meta.setDisplayName(plugin.msg(plugin.getSellAxeConfig().getString("sell-axe.name", "&5Ametist Satış Baltası")));

        List<String> lore = new ArrayList<>(plugin.getSellAxeConfig().getStringList("sell-axe.lore").stream()
                .map(plugin::msg).toList());

        int usesLeft = getUsesLeft(stack);
        if (usesLeft >= 0) lore.add(plugin.msg("&7Kalan kullanım: &f" + usesLeft));

        if (hasExpiry(stack)) {
            long left = Math.max(0, getExpiresAt(stack));
            lore.add(plugin.msg("&f" + formatDuration(left)));
        }

        meta.setLore(lore);
        stack.setItemMeta(meta);
    }

    private String formatDuration(long millis) {
        long totalMinutes = Math.max(0L, millis) / 60_000L;
        long hours = totalMinutes / 60L;
        long minutes = totalMinutes % 60L;
        return hours + "h " + minutes + "m";
    }

    public void give(Player player) {
        java.util.Map<Integer, ItemStack> leftovers = player.getInventory().addItem(create());
        for (ItemStack leftover : leftovers.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), leftover);
        }
    }

    /**
     * Bu balta zamanlı mı? (Kalan aktif süre PDC'de saklı.)
     */
    public boolean hasExpiry(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) return false;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return false;
        return meta.getPersistentDataContainer().has(remainingMillisKey, PersistentDataType.LONG);
    }

    /**
     * Kalan aktif süre (millisaniye). Yoksa 0 döner.
     */
    public long getExpiresAt(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) return 0L;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return 0L;
        Long v = meta.getPersistentDataContainer().get(remainingMillisKey, PersistentDataType.LONG);
        return v == null ? 0L : v;
    }

    /**
     * Geçen süreyi kalan aktif süreden düşer, lore'u yeniler.
     * Balta süresi bitmişse true döner (çağrılı taraf item'i silmelidir).
     */
    public boolean tickTime(ItemStack stack, long elapsedMillis) {
        if (!hasExpiry(stack)) return false;
        long remaining = getExpiresAt(stack) - Math.max(0L, elapsedMillis);
        if (remaining <= 0L) {
            ItemMeta meta = stack.getItemMeta();
            if (meta != null) {
                meta.getPersistentDataContainer().remove(remainingMillisKey);
                stack.setItemMeta(meta);
            }
            return true;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return false;
        meta.getPersistentDataContainer().set(remainingMillisKey, PersistentDataType.LONG, remaining);
        stack.setItemMeta(meta);
        refreshLore(stack);
        return false;
    }
}

package com.azy.sell.autosell;

import com.azy.sell.AzySell;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Fiyatı tanımlı eşyaların filtre seçim ekranı. */
public final class SellFilterSelectionGui implements InventoryHolder {
    private static final int SIZE = 54;
    private static final int PREV = 45;
    private static final int CATEGORY = 46;
    private static final int SEARCH = 52;
    private static final int NEXT = 53;
    private static final int PAGE_SIZE = 45;

    private final AzySell plugin;
    private final AutoSellManager manager;
    private final int page;
    private final String category;
    private final String query;
    private Inventory inventory;

    public SellFilterSelectionGui(AzySell plugin, AutoSellManager manager, int page, String category, String query) {
        this.plugin = plugin;
        this.manager = manager;
        this.page = page;
        this.category = category;
        this.query = query;
    }

    public void open(Player player) {
        List<Material> materials = new ArrayList<>();
        for (Material material : plugin.getPriceCalculator().getPricedMaterials()) {
            if (category != null && !category.equalsIgnoreCase(plugin.getPriceCalculator().getWorthCategory(material))) continue;
            if (query != null && !query.isBlank() && !matchesQuery(material, query)) continue;
            materials.add(material);
        }
        materials.sort(Comparator.comparing(Enum::name));

        int pages = Math.max(1, (int) Math.ceil(materials.size() / (double) PAGE_SIZE));
        int currentPage = Math.max(0, Math.min(page, pages - 1));
        inventory = Bukkit.createInventory(this, SIZE,
                plugin.msg("&8Eşya Seçimi &7(" + (currentPage + 1) + "/" + pages + ")"));

        int start = currentPage * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, materials.size());
        for (int i = start; i < end; i++) {
            Material material = materials.get(i);
            inventory.setItem(i - start, item(material, manager.isFiltered(player, material)));
        }

        inventory.setItem(PREV, button(Material.ARROW, "&aGeri", "&7Filtre ekranına dön"));
        inventory.setItem(CATEGORY, categoryButton());
        inventory.setItem(SEARCH, button(Material.COMPASS, "&bArama", "&7Türkçe veya İngilizce eşya adı yaz"));
        inventory.setItem(NEXT, button(Material.ARROW, "&aİleri"));
        player.openInventory(inventory);
    }

    private ItemStack categoryButton() {
        ItemStack stack = new ItemStack(Material.HOPPER);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            String label = "Tümü";
            if (category != null && plugin.getCategoryProgressManager().getCategory(category) != null) {
                label = plugin.getCategoryProgressManager().getCategory(category).getDisplayName();
            }
            meta.setDisplayName(plugin.msg("&eKategori: &b" + label));
            List<String> lore = new ArrayList<>();
            lore.add(plugin.msg("&7Sonraki kategori"));
            lore.add(plugin.msg("&7Mevcut: &f" + label));
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack item(Material material, boolean selected) {
        // Ham vanilla ItemStack: display name/lore yok. İstemci kendi dilini kullanır.
        return new ItemStack(material);
    }

    private ItemStack button(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(name));
            if (lore.length > 0) meta.setLore(java.util.Arrays.stream(lore).map(plugin::msg).toList());
            stack.setItemMeta(meta);
        }
        return stack;
    }


    private boolean matchesQuery(Material material, String rawQuery) {
        String query = normalize(rawQuery);
        if (query.isEmpty()) return true;
        String english = normalize(material.name());
        String prettyName = normalize(pretty(material.name()));
        String turkish = normalize(turkishName(material));
        return english.contains(query) || prettyName.contains(query) || turkish.contains(query);
    }

    private String normalize(String value) {
        if (value == null) return "";
        return java.text.Normalizer.normalize(value.toLowerCase(Locale.ROOT), java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
    }

    private String turkishName(Material material) {
        return switch (material) {
            case DIAMOND -> "elmas";
            case DIAMOND_BLOCK -> "elmas blok";
            case DIAMOND_ORE -> "elmas cevheri";
            case DEEPSLATE_DIAMOND_ORE -> "derin kayrak elmas cevheri";
            case EMERALD -> "zümrüt";
            case EMERALD_BLOCK -> "zümrüt blok";
            case EMERALD_ORE -> "zümrüt cevheri";
            case IRON_INGOT -> "demir külçesi";
            case IRON_BLOCK -> "demir blok";
            case IRON_ORE -> "demir cevheri";
            case GOLD_INGOT -> "altın külçesi";
            case GOLD_BLOCK -> "altın blok";
            case GOLD_ORE -> "altın cevheri";
            case COPPER_INGOT -> "bakır külçesi";
            case COPPER_BLOCK -> "bakır blok";
            case COAL -> "kömür";
            case COAL_BLOCK -> "kömür blok";
            case REDSTONE -> "kızıltaş";
            case REDSTONE_BLOCK -> "kızıltaş blok";
            case LAPIS_LAZULI -> "lapis lazuli";
            case LAPIS_BLOCK -> "lapis blok";
            case NETHERITE_INGOT -> "netherit külçesi";
            case NETHERITE_BLOCK -> "netherit blok";
            case ANCIENT_DEBRIS -> "kadim enkaz";
            case NETHERITE_SCRAP -> "netherit hurdası";
            case DIAMOND_SWORD -> "elmas kılıç";
            case DIAMOND_PICKAXE -> "elmas kazma";
            case DIAMOND_AXE -> "elmas balta";
            case NETHERITE_SWORD -> "netherit kılıç";
            case NETHERITE_PICKAXE -> "netherit kazma";
            case NETHERITE_AXE -> "netherit balta";
            case IRON_SWORD -> "demir kılıç";
            case IRON_PICKAXE -> "demir kazma";
            case IRON_AXE -> "demir balta";
            case OAK_LOG -> "meşe kütüğü";
            case SPRUCE_LOG -> "ladin kütüğü";
            case BIRCH_LOG -> "huş kütüğü";
            case JUNGLE_LOG -> "orman kütüğü";
            case ACACIA_LOG -> "akasya kütüğü";
            case DARK_OAK_LOG -> "koyu meşe kütüğü";
            case MANGROVE_LOG -> "mangrov kütüğü";
            case CHERRY_LOG -> "kiraz kütüğü";
            case BAMBOO -> "bambu";
            case WHEAT -> "buğday";
            case WHEAT_SEEDS -> "buğday tohumu";
            case CARROT -> "havuç";
            case POTATO -> "patates";
            case BAKED_POTATO -> "fırınlanmış patates";
            case BEETROOT -> "pancar";
            case BEETROOT_SEEDS -> "pancar tohumu";
            case MELON -> "kavun";
            case MELON_SLICE -> "kavun dilimi";
            case PUMPKIN -> "balkabağı";
            case SUGAR_CANE -> "şeker kamışı";
            case CACTUS -> "kaktüs";
            case KELP -> "yosun";
            case BREAD -> "ekmek";
            case APPLE -> "elma";
            case GOLDEN_APPLE -> "altın elma";
            case ENCHANTED_GOLDEN_APPLE -> "büyülü altın elma";
            case POTION -> "iksir";
            case EXPERIENCE_BOTTLE -> "deneyim şişesi";
            case BLAZE_ROD -> "alev çubuğu";
            case ENDER_PEARL -> "ender incisi";
            case ENDER_EYE -> "ender gözü";
            case ELYTRA -> "elytra";
            case TOTEM_OF_UNDYING -> "ölümsüzlük totemi";
            case SHULKER_SHELL -> "shulker kabuğu";
            case NETHER_STAR -> "nether yıldızı";
            case OBSIDIAN -> "obsidyen";
            case COBBLESTONE -> "kırık taş";
            case STONE -> "taş";
            case DIRT -> "toprak";
            case GRASS_BLOCK -> "çim bloğu";
            case SAND -> "kum";
            case GRAVEL -> "çakıl";
            case CLAY -> "kil";
            default -> material.name().replace('_', ' ').toLowerCase(Locale.ROOT);
        };
    }

    private String pretty(String name) {
        StringBuilder builder = new StringBuilder();
        for (String part : name.toLowerCase(Locale.ROOT).split("_")) {
            if (!builder.isEmpty()) builder.append(' ');
            if (!part.isEmpty()) builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.toString();
    }

    public static int prev() { return PREV; }
    public static int category() { return CATEGORY; }
    public static int search() { return SEARCH; }
    public static int next() { return NEXT; }
    public int getPage() { return page; }
    public String getCategory() { return category; }
    public String getQuery() { return query; }

    @Override
    public Inventory getInventory() { return inventory; }
}

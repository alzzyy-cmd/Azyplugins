package com.azy.sell.autosell;

import com.azy.sell.AzySell;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerChatEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;
import io.papermc.paper.event.player.PlayerInventorySlotChangeEvent;

import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Otomatik satış filtre GUI'si ve olay tabanlı otomatik satış dinleyicisi. */
public final class SellFilterGuiListener implements Listener {
    private final AzySell plugin;
    private final ConcurrentHashMap<UUID, Boolean> awaitingSearch = new ConcurrentHashMap<>();

    public SellFilterGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof SellFilterGui) && !(holder instanceof SellFilterSelectionGui)) return;
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getInventory()) return;

        if (holder instanceof SellFilterGui gui) {
            handleMain(player, gui, event.getRawSlot(), event.isRightClick());
        } else {
            handleSelection(player, (SellFilterSelectionGui) holder, event.getRawSlot());
        }
    }

    private void handleMain(Player player, SellFilterGui gui, int slot, boolean rightClick) {
        int limit = plugin.getAutoSellManager().getSlotLimit(player);
        if (slot >= 0 && slot < 45) {
            if (slot >= limit) return;
            var clicked = eventItem(gui, slot);
            if (clicked == null || clicked.getType().isAir()
                    || clicked.getType() == Material.GRAY_STAINED_GLASS_PANE
                    || clicked.getType() == Material.RED_STAINED_GLASS_PANE) {
                new SellFilterSelectionGui(plugin, plugin.getAutoSellManager(), 0, null, null).open(player);
                return;
            }
            if (rightClick) {
                plugin.getAutoSellManager().setFilter(player, clicked.getType(), false);
                gui.open(player);
            } else {
                new SellFilterSelectionGui(plugin, plugin.getAutoSellManager(), 0, null, null).open(player);
            }
            return;
        }

        if (slot == SellFilterGui.status()) {
            boolean enabled = plugin.getAutoSellManager().toggle(player);
            player.sendMessage(plugin.msg(enabled ? "&aOtomatik satış açıldı." : "&cOtomatik satış kapatıldı."));
            gui.open(player);
        } else if (slot == SellFilterGui.search()) {
            awaitingSearch.put(player.getUniqueId(), true);
            player.closeInventory();
            player.sendMessage(plugin.msg("&eAramak istediğin eşyanın adını sohbete yaz. &7İptal: iptal"));
        } else if (slot == SellFilterGui.category() || slot == 52) {
            new SellFilterSelectionGui(plugin, plugin.getAutoSellManager(), 0, null, null).open(player);
        } else if (slot == SellFilterGui.clear()) {
            for (Material material : plugin.getAutoSellManager().getFilters(player)) {
                plugin.getAutoSellManager().setFilter(player, material, false);
            }
            gui.open(player);
        } else if (slot == SellFilterGui.prev()) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.8f, 1.15f);
            new SellFilterGui(plugin, plugin.getAutoSellManager(), gui.getPage() - 1, gui.getQuery()).open(player);
        } else if (slot == SellFilterGui.next()) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.8f, 1.15f);
            new SellFilterGui(plugin, plugin.getAutoSellManager(), gui.getPage() + 1, gui.getQuery()).open(player);
        }
    }

    private org.bukkit.inventory.ItemStack eventItem(SellFilterGui gui, int slot) {
        return gui.getInventory().getItem(slot);
    }

    private void handleSelection(Player player, SellFilterSelectionGui gui, int slot) {
        if (slot >= 0 && slot < 45) {
            var clicked = gui.getInventory().getItem(slot);
            if (clicked == null || clicked.getType().isAir()) return;
            if (plugin.getAutoSellManager().isFiltered(player, clicked.getType())) {
                plugin.getAutoSellManager().setFilter(player, clicked.getType(), false);
            } else {
                plugin.getAutoSellManager().setFilter(player, clicked.getType(), true);
            }
            new SellFilterSelectionGui(plugin, plugin.getAutoSellManager(), gui.getPage(), gui.getCategory(), gui.getQuery()).open(player);
        } else if (slot == SellFilterSelectionGui.prev()) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.8f, 1.15f);
            new SellFilterGui(plugin, plugin.getAutoSellManager(), 0, gui.getQuery()).open(player);
        } else if (slot == SellFilterSelectionGui.next()) {
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 0.8f, 1.15f);
            new SellFilterSelectionGui(plugin, plugin.getAutoSellManager(), gui.getPage() + 1, gui.getCategory(), gui.getQuery()).open(player);
        } else if (slot == SellFilterSelectionGui.category()) {
            new SellFilterSelectionGui(plugin, plugin.getAutoSellManager(), 0, nextCategory(gui.getCategory()), gui.getQuery()).open(player);
        } else if (slot == SellFilterSelectionGui.search()) {
            awaitingSearch.put(player.getUniqueId(), true);
            player.closeInventory();
            player.sendMessage(plugin.msg("&eAramak istediğin eşyanın adını sohbete yaz. &7İptal: iptal"));
        }
    }

    private String nextCategory(String current) {
        List<String> ids = plugin.getCategoryProgressManager().getCategories().stream().map(com.azy.sell.category.CategoryDefinition::getId).toList();
        if (ids.isEmpty()) return null;
        if (current == null) return ids.get(0);
        int index = ids.indexOf(current);
        return index < 0 || index >= ids.size() - 1 ? null : ids.get(index + 1);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(PlayerChatEvent event) {
        if (!awaitingSearch.remove(event.getPlayer().getUniqueId())) return;
        event.setCancelled(true);
        String query = event.getMessage().trim();
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (query.equalsIgnoreCase("iptal")) {
                plugin.getAutoSellManager().openFilter(player);
            } else {
                new SellFilterSelectionGui(plugin, plugin.getAutoSellManager(), 0, null, query).open(player);
            }
        });
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSlotChange(PlayerInventorySlotChangeEvent event) {
        Player player = event.getPlayer();
        int slot = event.getSlot();
        if (slot >= 0 && slot < 36) {
            plugin.getServer().getScheduler().runTask(plugin, () ->
                    plugin.getAutoSellManager().processSlot(player, slot));
        }
    }

    /** Sadece oyuncunun kendi pickup'ı. Hopper/container hareketleri burada yakalanmaz. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        Material material = event.getItem().getItemStack().getType();
        // Pickup sonrası yalnızca alınan materyalin bulunduğu slotları kontrol et.
        // Tüm 36 slotu her pickup'ta taramak gereksiz yük oluşturuyordu.
        plugin.getServer().getScheduler().runTask(plugin, () ->
                plugin.getAutoSellManager().processMaterial(player, material));
    }

    /** Envanter tıklamalarında PlayerInventorySlotChangeEvent gerçek değişen slotu yakalar. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClickForAutoSell(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof SellFilterGui || holder instanceof SellFilterSelectionGui) return;
        // Ayrı bir tam-enventer taraması yapma. Slot değişimi event'i asıl değişikliği
        // yakalar; bu event'te yeniden tarama yapmak çift satış/lag üretebiliyordu.
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryDragForAutoSell(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof SellFilterGui || holder instanceof SellFilterSelectionGui) return;
        // Drag sonrası değişen oyuncu slotlarını PlayerInventorySlotChangeEvent
        // üzerinden işle. Burada ikinci bir full-inventory taraması yapma.
    }

}
# AzySell Çarpan Veritabanı

## Dosya
PerfSell kaldırıldıktan sonra oyuncuların mevcut çarpan ilerlemesini taşımak için:
`plugins/AzySell/carpanlar.db`

AzySell bu dosyayı otomatik açar. Dosyanın yeniden adlandırılması yeterlidir; oyuncu kayıtları
silinmez.

## Kategori eşleşmeleri
- `crops` -> Tarım
- `ores` -> Maden
- `mob_drops` -> Mob Düşüşleri
- `blocks` -> Bloklar
- `armor_and_tools` -> Savaş
- `fish` -> Balıkçılık
- `enchanted_books` -> Büyü
- `potions` -> İksirler
- `natural_items` -> Diğer

İç veritabanındaki eski kategori adları korunur; GUI'de oyuncuya Türkçe adlar gösterilir.

## AutoSell
AutoSell artık sürekli envanter taramaz. Sadece oyuncunun gerçek envanter slotu değiştiğinde
gelen stack'i işler. Böylece hopper/container kaynaklı genel tarama nedeniyle mevcut eşyalar
yanlışlıkla satılmaz.

## Filtre eşyaları
Filtre seçim ekranındaki itemler özel display-name/lore ile değiştirilmez. Ham Bukkit
ItemStack gösterilir; Minecraft istemcisi kendi dilindeki vanilla item adını kullanır.

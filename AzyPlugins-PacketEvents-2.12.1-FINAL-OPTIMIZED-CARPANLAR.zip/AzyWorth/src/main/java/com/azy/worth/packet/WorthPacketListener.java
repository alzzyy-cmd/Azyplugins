package com.azy.worth.packet;

import com.azy.worth.AzyWorth;
import org.bukkit.block.ShulkerBox;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * PacketEvents uyumluluk katmanının Bukkit tarafındaki fiyat hesaplama yardımcısı.
 * PacketEvents sınıflarına doğrudan referans vermez; böylece farklı PacketEvents
 * sürümlerinde class-linkage hatası oluşturmaz.
 */
public final class WorthPacketListener {
    private static final String FIYAT_PREFIX = "Fiyat: ";
    private static final Set<String> SHULKER_BOX_TYPES = Set.of(
            "SHULKER_BOX","WHITE_SHULKER_BOX","ORANGE_SHULKER_BOX","MAGENTA_SHULKER_BOX",
            "LIGHT_BLUE_SHULKER_BOX","YELLOW_SHULKER_BOX","LIME_SHULKER_BOX","PINK_SHULKER_BOX",
            "GRAY_SHULKER_BOX","LIGHT_GRAY_SHULKER_BOX","CYAN_SHULKER_BOX","PURPLE_SHULKER_BOX",
            "BLUE_SHULKER_BOX","BROWN_SHULKER_BOX","GREEN_SHULKER_BOX","RED_SHULKER_BOX","BLACK_SHULKER_BOX"
    );
    private final AzyWorth plugin;
    public WorthPacketListener(AzyWorth plugin) { this.plugin = plugin; }

    public ItemStack addPriceLore(ItemStack original) {
        return addPriceLore(original, null);
    }

    /**
     * Fiyat lore'unu ekler. player verilirse ve AzySell bağlıysa fiyat, oyuncunun
     * VIP + kategori çarpanıyla ÇARPILMIŞ gösterilir; yoksa taban fiyat gösterilir.
     */
    public ItemStack addPriceLore(ItemStack original, org.bukkit.entity.Player player) {
        if (original == null || original.getType().isAir() || isAzySellSpecial(original)) return original;
        ItemStack item = original.clone();
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return original;

        List<String> lore = meta.hasLore() && meta.getLore() != null
                ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.removeIf(line -> stripColor(line).startsWith(FIYAT_PREFIX));

        boolean shulker = SHULKER_BOX_TYPES.contains(item.getType().name());
        boolean own = plugin.getWorthManager().hasPriceForItem(item);
        double contents = shulker ? getShulkerContentsValue(meta) : 0.0;

        if (!own && contents <= 0.0) return original;

        double unit = own ? plugin.getWorthManager().getUnitPriceForItem(item) : 0.0;
        double mult = player != null ? plugin.getTotalMultiplier(player, item.getType()) : 1.0;
        double displayPrice = (unit + contents) * mult * Math.max(1, item.getAmount());
        String suffix = shulker && contents > 0.0 ? " &7(içerik dahil)" : "";
        if (mult > 1.0) suffix += " &8(çarpanlı)";
        // Fiyat artık oyuncunun elindeki stack'in toplam değerini gösterir.
        // Bu değişiklik yalnızca PacketEvents ile client'a gönderilen görsel lore'u
        // etkiler; sunucudaki gerçek ItemStack miktarı değiştirilmez.
        lore.add(plugin.msg("&7" + FIYAT_PREFIX + "&a$" + formatPrice(displayPrice) + " &8(" + Math.max(1, item.getAmount()) + " adet)" + suffix));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isAzySellSpecial(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        var pdc = meta.getPersistentDataContainer();
        NamespacedKey axeKey = NamespacedKey.fromString("azysell:azysell_axe");
        NamespacedKey upgradeKey = NamespacedKey.fromString("azysell:azysell_axe_upgrade");
        return (axeKey != null && pdc.has(axeKey, PersistentDataType.BYTE))
                || (upgradeKey != null && pdc.has(upgradeKey, PersistentDataType.BYTE));
    }

    private double getShulkerContentsValue(ItemMeta meta) {
        if (!(meta instanceof BlockStateMeta state)) return 0.0;
        if (!(state.getBlockState() instanceof ShulkerBox box)) return 0.0;
        double total = 0.0;
        for (ItemStack content : box.getInventory().getContents()) {
            if (content == null || content.getType().isAir()) continue;
            if (plugin.getWorthManager().hasPriceForItem(content)) {
                total += plugin.getWorthManager().getUnitPriceForItem(content) * content.getAmount();
            }
        }
        return total;
    }

    private String stripColor(String text) {
        return text == null ? "" : text.replaceAll("(?i)[&§][0-9A-FK-ORX]", "");
    }
    private String formatPrice(double price) {
        double abs = Math.abs(price);
        if (abs >= 1_000_000_000.0) return String.format("%.1fB", price / 1_000_000_000.0);
        if (abs >= 1_000_000.0) return String.format("%.1fM", price / 1_000_000.0);
        if (abs >= 1_000.0) return String.format("%.1fK", price / 1_000.0);
        if (price == Math.floor(price)) return String.valueOf((long) price);
        return String.format("%.2f", price);
    }
}

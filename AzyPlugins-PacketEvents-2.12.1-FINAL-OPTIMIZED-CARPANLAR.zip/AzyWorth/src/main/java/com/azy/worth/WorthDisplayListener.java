package com.azy.worth;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Set;

public class WorthDisplayListener implements Listener {
    private final AzyWorth plugin;
    public WorthDisplayListener(AzyWorth plugin) {
        this.plugin = plugin;
    }

    @EventHandler public void onHeldItemChange(PlayerItemHeldEvent event) {
        plugin.getServer().getScheduler().runTask(plugin, () -> showWorth(event.getPlayer(), event.getPlayer().getInventory().getItem(event.getNewSlot())));
    }
    @EventHandler public void onPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player) plugin.getServer().getScheduler().runTask(plugin, () -> showWorth(player, player.getInventory().getItemInMainHand()));
    }
    @EventHandler public void onCraft(CraftItemEvent event) {
        if (event.getWhoClicked() instanceof Player player) plugin.getServer().getScheduler().runTask(plugin, () -> showWorth(player, player.getInventory().getItemInMainHand()));
    }
    @EventHandler public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        // Hem üst GUI hem oyuncu envanteri tıklamalarında mevcut el eşyasını yenile.
        // Eski holder kontrolü kaldırıldı; o kontrol geçerli oyuncu envanterini de yanlışlıkla engelliyordu.
        plugin.getServer().getScheduler().runTask(plugin, () -> showWorth(player, player.getInventory().getItemInMainHand()));
    }
    @EventHandler public void onSwapHand(PlayerSwapHandItemsEvent event) {
        plugin.getServer().getScheduler().runTask(plugin, () -> showWorth(event.getPlayer(), event.getPlayer().getInventory().getItemInMainHand()));
    }
    @EventHandler public void onDrop(PlayerDropItemEvent event) {
        plugin.getServer().getScheduler().runTask(plugin, () -> showWorth(event.getPlayer(), event.getPlayer().getInventory().getItemInMainHand()));
    }
    @EventHandler public void onConsume(PlayerItemConsumeEvent event) {
        plugin.getServer().getScheduler().runTask(plugin, () -> showWorth(event.getPlayer(), event.getPlayer().getInventory().getItemInMainHand()));
    }
    @EventHandler public void onInventoryOpen(InventoryOpenEvent event) {
        if (event.getPlayer() instanceof Player player) showWorth(player, player.getInventory().getItemInMainHand());
    }

    private void showWorth(Player player, ItemStack item) {
        if (item == null || item.getType().isAir() || isAzySellSpecial(item)) {
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(""));
            return;
        }
        boolean shulker = SHULKER_BOX_TYPES.contains(item.getType().name());
        boolean own = plugin.getWorthManager().hasPriceForItem(item);
        double contents = shulker && item.getItemMeta() != null ? getShulkerContentsValue(item.getItemMeta()) : 0.0;
        if (!own && contents <= 0) {
            player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(""));
            return;
        }
        double unit = own ? plugin.getWorthManager().getUnitPriceForItem(item) : 0.0;
        double mult = plugin.getTotalMultiplier(player, item.getType());
        double total = (unit * item.getAmount() + (contents * item.getAmount())) * mult;
        String suffix = shulker && contents > 0 ? " &7(içerik dahil)" : "";
        if (mult > 1.0) suffix += " &8(çarpanlı)";
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(plugin.msg("&7Toplam Değer: &a$" + formatPrice(total) + suffix)));
    }

    private boolean isAzySellSpecial(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;
        var pdc = meta.getPersistentDataContainer();
        NamespacedKey axeKey = NamespacedKey.fromString("azysell:azysell_axe");
        NamespacedKey upgradeKey = NamespacedKey.fromString("azysell:azysell_axe_upgrade");
        return (axeKey != null && pdc.has(axeKey, PersistentDataType.BYTE))
                || (upgradeKey != null && pdc.has(upgradeKey, PersistentDataType.BYTE));
    }

    private double getShulkerContentsValue(ItemMeta meta) {
        if (!(meta instanceof BlockStateMeta state)) return 0.0;
        if (!(state.getBlockState() instanceof ShulkerBox box)) return 0.0;
        double total = 0;
        for (ItemStack content : box.getInventory().getContents()) {
            if (content == null || content.getType().isAir()) continue;
            if (plugin.getWorthManager().hasPriceForItem(content)) total += plugin.getWorthManager().getUnitPriceForItem(content) * content.getAmount();
        }
        return total;
    }

    private static final Set<String> SHULKER_BOX_TYPES = Set.of("SHULKER_BOX", "WHITE_SHULKER_BOX", "ORANGE_SHULKER_BOX", "MAGENTA_SHULKER_BOX", "LIGHT_BLUE_SHULKER_BOX", "YELLOW_SHULKER_BOX", "LIME_SHULKER_BOX", "PINK_SHULKER_BOX", "GRAY_SHULKER_BOX", "LIGHT_GRAY_SHULKER_BOX", "CYAN_SHULKER_BOX", "PURPLE_SHULKER_BOX", "BLUE_SHULKER_BOX", "BROWN_SHULKER_BOX", "GREEN_SHULKER_BOX", "RED_SHULKER_BOX", "BLACK_SHULKER_BOX");

    private String formatPrice(double price) {
        double abs = Math.abs(price);
        if (abs >= 1_000_000_000) return String.format("%.1fB", price / 1_000_000_000);
        if (abs >= 1_000_000) return String.format("%.1fM", price / 1_000_000);
        if (abs >= 1_000) return String.format("%.1fK", price / 1_000);
        if (price == Math.floor(price)) return String.valueOf((long) price);
        return String.format("%.2f", price);
    }
}

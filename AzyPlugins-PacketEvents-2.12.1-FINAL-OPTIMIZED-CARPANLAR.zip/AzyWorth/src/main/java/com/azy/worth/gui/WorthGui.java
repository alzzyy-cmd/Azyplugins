package com.azy.worth.gui;

import com.azy.worth.AzyWorth;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * /fiyatlar (alias: /worth) komutuyla açılan sayfalı eşya fiyat listesi.
 * Her sayfada 44 item gösterilir (54 slottan biri sıralama butonu, biri
 * kategori filtre butonu, ikisi gezinme butonları için ayrılır).
 *
 * KATEGORİ FİLTRESİ: hunideki (SLOT_CATEGORY) butona hover yapılınca lore'da
 * AzySell'deki 9 kategori (Tarım, Cevherler, Mob Dropları, Bloklar, Savaş,
 * Balıkçılık, Büyü, İksirler, Diğer) listelenir - hepsi BEYAZ, o an aktif
 * seçili olan kategori AÇIK MAVİ (AQUA) renkte vurgulanır. Butona tıklamak
 * bir sonraki kategoriye geçer (null -> ilk kategori -> ... -> son -> null).
 * categoryFilter null ise "Tümü" gösterilir, hiçbir filtre uygulanmaz.
 */
public class WorthGui implements InventoryHolder {

    private static final int PAGE_SIZE = 45;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_SORT = 48;
    private static final int SLOT_CATEGORY = 49;
    private static final int SLOT_NEXT = 53;

    private final AzyWorth plugin;
    private final int page;
    private final SortMode sortMode;
    /** Şu an seçili kategori id'si (örn. "mining"); null ise tüm kategoriler gösterilir. */
    private final String categoryFilter;
    private Inventory inventory;

    public WorthGui(AzyWorth plugin, int page) {
        this(plugin, page, SortMode.HIGHEST_PRICE, null);
    }

    public WorthGui(AzyWorth plugin, int page, SortMode sortMode, String categoryFilter) {
        this.plugin = plugin;
        this.page = page;
        this.sortMode = sortMode;
        this.categoryFilter = categoryFilter;
    }

    public void open(Player player) {
        List<Map.Entry<Material, Double>> entries = new ArrayList<>(
                plugin.getWorthManager().getAllBasePrices().entrySet());
        // Fiyatı 0 (ya da altı) olan ve AIR gibi görsel olarak "boş slot" gibi
        // görünen materyaller listeden tamamen çıkarılır - hem gereksiz kalabalık
        // yapmasınlar hem de AIR item'ı envanterde boş bir kare gibi görünüp
        // kafa karıştırmasın diye.
        entries.removeIf(entry -> entry.getKey() == Material.AIR || entry.getValue() <= 0.0);

        // Kategori filtresi uygulanıyorsa, sadece o kategoriye ait materyaller kalır.
        if (categoryFilter != null) {
            entries.removeIf(entry -> !plugin.getCategoryManager().isInCategory(entry.getKey(), categoryFilter));
        }

        sortEntries(entries);

        int maxPages = Math.max(1, (int) Math.ceil(entries.size() / (double) PAGE_SIZE));
        int clampedPage = Math.max(0, Math.min(page, maxPages - 1));

        String categoryLabel = categoryFilter == null ? "Tümü" : plugin.getCategoryManager().getDisplayName(categoryFilter);
        String title = plugin.msg("&8Eşya Fiyatları &7(" + categoryLabel + " • " + (clampedPage + 1) + "/" + maxPages + ")");
        inventory = Bukkit.createInventory(this, 54, title);

        int start = clampedPage * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, entries.size());
        for (int i = start; i < end; i++) {
            Map.Entry<Material, Double> entry = entries.get(i);
            double unitPrice = entry.getValue() * plugin.getWorthManager().getGlobalMultiplier();
            inventory.setItem(i - start, buildEntryItem(entry.getKey(), unitPrice));
        }

        inventory.setItem(SLOT_PREV, navButton(clampedPage > 0 ? "&aÖnceki Sayfa" : "&7İlk Sayfadasın"));
        if (clampedPage < maxPages - 1) {
            inventory.setItem(SLOT_NEXT, navButton("&aSonraki Sayfa"));
        }
        inventory.setItem(SLOT_SORT, sortButton());
        inventory.setItem(SLOT_CATEGORY, categoryButton());

        player.openInventory(inventory);
    }

    private void sortEntries(List<Map.Entry<Material, Double>> entries) {
        switch (sortMode) {
            case LOWEST_PRICE -> entries.sort((a, b) -> Double.compare(a.getValue(), b.getValue()));
            case HIGHEST_PRICE -> entries.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        }
    }

    private ItemStack buildEntryItem(Material material, double unitPrice) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.translatable(material.translationKey())
                    .color(NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false));
            meta.setLore(List.of(plugin.msg("&7Değer: &a$" + format(unitPrice))));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack navButton(String name) {
        ItemStack stack = new ItemStack(Material.ARROW);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack sortButton() {
        ItemStack stack = new ItemStack(Material.COMPARATOR);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&eSıralama: " + sortMode.getDisplayName()));
            meta.setLore(List.of(plugin.msg("&7Değiştirmek için tıkla")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /**
     * Kategori filtre butonu: HOPPER materyali, lore'da tüm kategoriler BEYAZ
     * listelenir, o an aktif seçili kategori AÇIK MAVİ (AQUA) renkte vurgulanır.
     * "Tümü" seçeneği listenin en başında gösterilir.
     */
    private ItemStack categoryButton() {
        ItemStack stack = new ItemStack(Material.HOPPER);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            String currentLabel = categoryFilter == null ? "Tümü" : plugin.getCategoryManager().getDisplayName(categoryFilter);
            meta.setDisplayName(plugin.msg("&eKategori: &b" + currentLabel));

            List<String> lore = new ArrayList<>();
            lore.add(plugin.msg("&7Değiştirmek için tıkla"));
            lore.add("");
            // "Tümü" seçeneği
            lore.add(plugin.msg(categoryFilter == null ? "&b▶ Tümü" : "&fTümü"));
            for (String categoryId : plugin.getCategoryManager().getCategoryIds()) {
                String label = plugin.getCategoryManager().getDisplayName(categoryId);
                boolean isActive = categoryId.equals(categoryFilter);
                lore.add(plugin.msg(isActive ? "&b▶ " + label : "&f" + label));
            }
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String format(double price) {
        if (price == Math.floor(price)) return String.valueOf((long) price);
        return String.format("%.2f", price);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public int getPage() {
        return page;
    }

    public SortMode getSortMode() {
        return sortMode;
    }

    public String getCategoryFilter() {
        return categoryFilter;
    }

    public static int getSlotPrev() { return SLOT_PREV; }
    public static int getSlotNext() { return SLOT_NEXT; }
    public static int getSlotSort() { return SLOT_SORT; }
    public static int getSlotCategory() { return SLOT_CATEGORY; }
}

package com.azy.worth;

import com.azy.worth.gui.WorthGui;
import com.azy.worth.gui.WorthGuiListener;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AzyWorth extends JavaPlugin implements TabCompleter {
    private static final Pattern HEX_PATTERN = Pattern.compile("#([A-Fa-f0-9]{6})");
    private static final String[] BANNER = {
            "   _        _____   __   __  __          __   _____    _____     _______    _   _ ",
            "  / \\      |__  /|  \\ \\ / /  \\ \\        / /  |  _  |  |  __ \\   |__   __|  | | | |",
            " / _ \\       / /     \\ V /    \\ \\  /\\  / /   | | | |  | |__) |     | |     | |_| |",
            "/ ___ \\     / /_      | |      \\ \\/  \\/ /    | |_| |  |  _  /      | |     |  _  |",
            "/_/   \\_\\  /____|     |_|       \\  /\\  /     \\_____/  |_| \\_\\      |_|     |_| |_|",
    };

    private WorthManager worthManager;
    private WorthCategoryManager categoryManager;
    private com.azy.worth.packet.PacketEventsBridge packetEventsBridge;
    private MultiplierHook multiplierHook;

    @Override
    public void onLoad() {
        // PacketEvents sürümünü derleme zamanında sabitlemiyoruz. Bridge,
        // sunucuda kurulu PacketEvents API'sini reflection ile algılar.
        // Uyumlu bir API bulunamazsa AzyWorth kapanmaz; ActionBar fiyat gösterimi
        // normal şekilde çalışmaya devam eder.
    }

    @Override
    public void onEnable() {
        printBanner();
        this.worthManager = new WorthManager(this);
        worthManager.load();
        this.categoryManager = new WorthCategoryManager(this);
        categoryManager.load();
        if (getCommand("worth") != null) getCommand("worth").setTabCompleter(this);
        if (getCommand("fiyatlar") != null) getCommand("fiyatlar").setTabCompleter(this);

        getServer().getPluginManager().registerEvents(new WorthDisplayListener(this), this);
        getServer().getPluginManager().registerEvents(new WorthGuiListener(this), this);

        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new PlaceholderExpansionAzyWorth(this).register();
            getLogger().info("PlaceholderAPI bulundu, %azyworth_...% placeholder'ları kaydedildi.");
        } else {
            getLogger().info("PlaceholderAPI bulunamadı, %azyworth_...% placeholder'ları devre dışı.");
        }
        this.multiplierHook = MultiplierHook.tryCreate();
        this.packetEventsBridge = new com.azy.worth.packet.PacketEventsBridge(this);
        if (packetEventsBridge.register()) {
            getLogger().info("AzyWorth aktif edildi. PacketEvents fiyat gösterimi etkin.");
        } else {
            getLogger().warning("PacketEvents fiyat katmanı bağlanamadı.");
        }
    }

    /**
     * Oyuncunun fiyat gösterimine uygulanacak TOPLAM çarpan (VIP * kategori).
     * AzySell bağlı değilse her zaman 1.0 döner (taban fiyat gösterilir).
     */
    public double getTotalMultiplier(Player player, Material material) {
        if (multiplierHook == null || player == null) return 1.0;
        return multiplierHook.multiplierFor(player, material);
    }

    @Override
    public java.util.List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(java.util.Locale.ROOT);
        if (!(name.equals("worth") || name.equals("fiyatlar"))) return java.util.Collections.emptyList();
        if (args.length != 1) return java.util.Collections.emptyList();

        java.util.List<String> options = new java.util.ArrayList<>();
        options.add("tümü");
        for (String id : categoryManager.getCategoryIds()) {
            String label = categoryManager.getDisplayName(id);
            options.add(label.replaceAll("(?i)[&§][0-9A-FK-ORX]", ""));
        }
        String q = args[0].toLowerCase(java.util.Locale.ROOT);
        return options.stream().filter(x -> x.toLowerCase(java.util.Locale.ROOT).startsWith(q)).toList();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase()) {
            case "worth", "fiyatlar" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir."); return true; }
                if (!player.hasPermission("azyworth.use")) { player.sendMessage(msg("&cBu komutu kullanma iznin yok.")); return true; }

                // /fiyatlar ve /worth artık yalnızca kategori GUI'sini açar.
                // /worth elmas 64 gibi doğrudan eşya/miktar sorguları kaldırıldı.
                String rawCategory = String.join(" ", args).trim();
                String category = rawCategory.isEmpty()
                        || rawCategory.equalsIgnoreCase("tümü")
                        || rawCategory.equalsIgnoreCase("tumu")
                        ? null : categoryManager.resolveCategory(rawCategory);

                if (!rawCategory.isEmpty() && category == null
                        && !rawCategory.equalsIgnoreCase("tümü")
                        && !rawCategory.equalsIgnoreCase("tumu")) {
                    player.sendMessage(msg("&cGeçersiz fiyat kategorisi: &f" + rawCategory));
                    player.sendMessage(msg("&7Kullanılabilir kategorileri GUI üzerinden seçebilirsin."));
                    return true;
                }
                new WorthGui(this, 0, com.azy.worth.gui.SortMode.HIGHEST_PRICE, category).open(player);
                return true;
            }
            case "azyworthreload" -> {
                if (!sender.hasPermission("azyworth.reload")) { sender.sendMessage(msg("&cBu komutu kullanma iznin yok.")); return true; }
                worthManager.load(); categoryManager.load(); sender.sendMessage(msg("&aAzyWorth fiyat listesi yeniden yüklendi.")); return true;
            }
            case "azyworthset" -> {
                if (!sender.hasPermission("azyworth.admin")) { sender.sendMessage(msg("&cBu komutu kullanma iznin yok.")); return true; }
                if (args.length < 2) { sender.sendMessage(msg("&cKullanım: /azyworthset <material> <fiyat>")); return true; }
                Material material = Material.matchMaterial(args[0].toUpperCase());
                if (material == null) { sender.sendMessage(msg("&cGeçersiz materyal: " + args[0])); return true; }
                try { double price = Double.parseDouble(args[1]); worthManager.setPrice(material, price); sender.sendMessage(msg("&a" + material.name() + " &7fiyatı &a$" + price + " &7olarak ayarlandı.")); }
                catch (NumberFormatException ex) { sender.sendMessage(msg("&cGeçersiz fiyat: " + args[1])); }
                return true;
            }
            case "setworth" -> {
                if (!sender.hasPermission("azyworth.admin")) { sender.sendMessage(msg("&cBu komutu kullanma iznin yok.")); return true; }
                if (args.length == 1) {
                    if (!(sender instanceof Player player)) { sender.sendMessage(msg("&cKonsoldan kullanırken materyal adını da belirtmelisin: /setworth <material> <fiyat>")); return true; }
                    ItemStack item = player.getInventory().getItemInMainHand();
                    if (item.getType().isAir()) { player.sendMessage(msg("&cElinde bir eşya tutmuyorsun.")); return true; }
                    try { double price = Double.parseDouble(args[0]); if (price < 0) { player.sendMessage(msg("&cFiyat negatif olamaz.")); return true; } worthManager.setPrice(item.getType(), price); player.sendMessage(msg("&aElindeki eşyanın (&e" + item.getType().name() + "&a) fiyatı &e$" + price + " &aolarak ayarlandı.")); }
                    catch (NumberFormatException ex) { player.sendMessage(msg("&cGeçersiz fiyat: " + args[0])); }
                    return true;
                }
                if (args.length == 2) {
                    Material material = Material.matchMaterial(args[0].toUpperCase());
                    if (material == null) { sender.sendMessage(msg("&cGeçersiz materyal: " + args[0])); return true; }
                    try { double price = Double.parseDouble(args[1]); if (price < 0) { sender.sendMessage(msg("&cFiyat negatif olamaz.")); return true; } worthManager.setPrice(material, price); sender.sendMessage(msg("&a" + material.name() + " &7fiyatı &a$" + price + " &7olarak ayarlandı.")); }
                    catch (NumberFormatException ex) { sender.sendMessage(msg("&cGeçersiz fiyat: " + args[1])); }
                    return true;
                }
                sender.sendMessage(msg("&cKullanım: /setworth <fiyat> veya /setworth <material> <fiyat>")); return true;
            }
            default -> { return false; }
        }
    }

    public String msg(String raw) {
        Matcher matcher = HEX_PATTERN.matcher(raw); StringBuilder buffer = new StringBuilder();
        while (matcher.find()) { String hex = matcher.group(1); StringBuilder replacement = new StringBuilder("§x"); for (char c : hex.toCharArray()) replacement.append('§').append(c); matcher.appendReplacement(buffer, replacement.toString()); }
        matcher.appendTail(buffer); return ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }
    public WorthManager getWorthManager() { return worthManager; }
    public WorthCategoryManager getCategoryManager() { return categoryManager; }
}

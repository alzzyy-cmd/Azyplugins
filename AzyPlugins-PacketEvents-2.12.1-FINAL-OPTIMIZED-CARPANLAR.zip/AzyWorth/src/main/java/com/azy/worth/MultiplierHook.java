package com.azy.worth;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

/**
 * AzySell'e reflection ile bağlanan isteğe bağlı çarpan köprüsü.
 * AzySell yüklüyse fiyat gösterimlerine (envanter lore + action bar) oyuncunun
 * VIP ve kategori çarpanını da yansıtır. AzySell YOKSA bu köprü hiç bağlanmaz,
 * AzyWorth tek başına taban fiyatları göstermeye devam eder (çökme yok).
 *
 * Beklenen AzySell metod imzaları (hepsi reflection ile çözülür):
 *   AzySell#getMultiplierManager()  -> SellMultiplierManager#getExtraMultiplier(Player)
 *   AzySell#getCategoryProgressManager() -> CategoryProgressManager#getMultiplier(UUID, Material)
 */
public final class MultiplierHook {

    private final Plugin azySell;

    private MultiplierHook(Plugin azySell) {
        this.azySell = azySell;
    }

    /** AzySell yüklü ve API'leri erişilebilirse köprüyü kurar; aksi halde null döner. */
    public static MultiplierHook tryCreate() {
        Plugin found = Bukkit.getPluginManager().getPlugin("AzySell");
        if (found == null || !found.isEnabled()) return null;
        return new MultiplierHook(found);
    }

    /**
     * Oyuncu ve materyal için TOPLAM çarpanı döner: (1 + vipEkstra) * kategoriCarpani.
     * Herhangi bir hata/uyumsuzlukta 1.0 (çarpansız) döner, asla exception fırlatmaz.
     */
    public double multiplierFor(Player player, Material material) {
        if (player == null || material == null) return 1.0;
        try {
            double vip = vipExtra(player);
            double category = categoryMultiplier(player, material);
            return (1.0 + vip) * category;
        } catch (Throwable t) {
            return 1.0;
        }
    }

    private double vipExtra(Player player) throws Exception {
        Object mm = azySell.getClass().getMethod("getMultiplierManager").invoke(azySell);
        Object v = mm.getClass().getMethod("getExtraMultiplier", Player.class).invoke(mm, player);
        return ((Number) v).doubleValue();
    }

    private double categoryMultiplier(Player player, Material material) throws Exception {
        Object cpm = azySell.getClass().getMethod("getCategoryProgressManager").invoke(azySell);
        Object v = cpm.getClass()
                .getMethod("getMultiplier", java.util.UUID.class, Material.class)
                .invoke(cpm, player.getUniqueId(), material);
        return ((Number) v).doubleValue();
    }
}

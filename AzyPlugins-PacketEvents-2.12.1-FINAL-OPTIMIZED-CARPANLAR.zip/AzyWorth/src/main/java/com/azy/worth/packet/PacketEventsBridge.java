package com.azy.worth.packet;

import com.azy.worth.AzyWorth;
import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.item.ItemStack;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.util.SpigotConversionUtil;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetSlot;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetPlayerInventory;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowItems;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** PacketEvents 2.12.1 için doğrudan ve küçük paket fiyat katmanı. */
public final class PacketEventsBridge {
    private final AzyWorth plugin;
    private final WorthPacketListener calculator;
    private PacketListenerAbstract listener;
    private boolean registered;

    public PacketEventsBridge(AzyWorth plugin) {
        this.plugin = plugin;
        this.calculator = new WorthPacketListener(plugin);
    }

    public boolean register() {
        if (registered) return true;
        try {
            var api = PacketEvents.getAPI();
            if (api == null || !api.isLoaded() || api.isTerminated()) return false;
            listener = new PacketListenerAbstract() {
                @Override
                public void onPacketSend(PacketSendEvent event) {
                    try {
                        if (event.getPacketType() == PacketType.Play.Server.SET_SLOT) {
                            handleSetSlot(event);
                        } else if (event.getPacketType() == PacketType.Play.Server.SET_PLAYER_INVENTORY) {
                            handlePlayerInventory(event);
                        } else if (event.getPacketType() == PacketType.Play.Server.WINDOW_ITEMS) {
                            handleWindowItems(event);
                        }
                    } catch (Throwable ignored) {
                        // Tek bir paket bozulursa diğer paketlerin işlenmesi devam eder.
                    }
                }
            };
            api.getEventManager().registerListener(listener);
            registered = true;
            plugin.getLogger().info("PacketEvents 2.12.1 fiyat katmanı bağlandı.");
            return true;
        } catch (Throwable t) {
            plugin.getLogger().warning("PacketEvents fiyat katmanı bağlanamadı: " + t.getClass().getSimpleName());
            listener = null;
            registered = false;
            return false;
        }
    }

    private void handleSetSlot(PacketSendEvent event) {
        WrapperPlayServerSetSlot wrapper = new WrapperPlayServerSetSlot(event);
        ItemStack packetItem = wrapper.getItem();
        ItemStack changed = modify(packetItem, player(event));
        if (changed != packetItem) {
            wrapper.setItem(changed);
            wrapper.write();
            event.markForReEncode(true);
        }
    }

    private void handlePlayerInventory(PacketSendEvent event) {
        WrapperPlayServerSetPlayerInventory wrapper = new WrapperPlayServerSetPlayerInventory(event);
        ItemStack packetItem = wrapper.getStack();
        ItemStack changed = modify(packetItem, player(event));
        if (changed != packetItem) {
            wrapper.setStack(changed);
            wrapper.write();
            event.markForReEncode(true);
        }
    }

    private void handleWindowItems(PacketSendEvent event) {
        WrapperPlayServerWindowItems wrapper = new WrapperPlayServerWindowItems(event);
        Player player = player(event);
        List<ItemStack> items = wrapper.getItems();
        List<ItemStack> changed = new ArrayList<>(items.size());
        boolean dirty = false;
        for (ItemStack item : items) {
            ItemStack replacement = modify(item, player);
            changed.add(replacement);
            dirty |= replacement != item;
        }
        Optional<ItemStack> carried = wrapper.getCarriedItem();
        ItemStack carriedValue = carried.orElse(null);
        ItemStack changedCarried = modify(carriedValue, player);
        dirty |= changedCarried != carriedValue;
        if (dirty) {
            wrapper.setItems(changed);
            wrapper.setCarriedItem(changedCarried);
            wrapper.write();
            event.markForReEncode(true);
        }
    }

    private ItemStack modify(ItemStack packetItem, Player player) {
        if (packetItem == null) return null;
        org.bukkit.inventory.ItemStack bukkit = SpigotConversionUtil.toBukkitItemStack(packetItem);
        if (bukkit == null || bukkit.getType().isAir()) return packetItem;
        org.bukkit.inventory.ItemStack modified = calculator.addPriceLore(bukkit, player);
        if (modified == bukkit || modified.equals(bukkit)) return packetItem;
        return SpigotConversionUtil.fromBukkitItemStack(modified);
    }

    @SuppressWarnings("unchecked")
    private Player player(PacketSendEvent event) {
        Object player = event.getPlayer();
        return player instanceof Player p ? p : null;
    }

    public void close() {
        if (!registered || listener == null) return;
        try {
            PacketEvents.getAPI().getEventManager().unregisterListener(listener);
        } catch (Throwable ignored) {
        } finally {
            registered = false;
            listener = null;
        }
    }

}

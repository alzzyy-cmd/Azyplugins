# AzySell / AzyWorth - son düzeltmeler

## 1. Packet fiyat gösterimi
PacketEvents üzerinden gösterilen fiyat artık ItemStack miktarını da hesaba katıyor.
Örnek: bir item 10$ ve stack 64 ise client'ta 640$ gösterilir.
Gerçek sunucu ItemStack'i değiştirilmez.

## 2. Güncel çarpan veritabanı
Yüklenen yeni PerfSell DB'den yalnızca AzySell'in ihtiyaç duyduğu
`perfsell_category_progress` tablosu alınarak `carpanlar.db` oluşturuldu.
- 2406 kayıt
- 9 kategori
- SQLite integrity_check: ok

Kullanım:
`plugins/AzySell/carpanlar.db`

## 3. AutoSell optimizasyonu
- InventoryClick/Drag olaylarında artık her seferinde 36 slot taranmıyor.
- PlayerInventorySlotChangeEvent gerçek değişen slotu işliyor.
- Pickup sonrası yalnızca alınan materyali taşıyan slotlar kontrol ediliyor.
- Hopper/container için genel inventory taraması yok.

## 4. Çarpan DB optimizasyonu
Kategori ilerlemesi RAM cache'leniyor.
- Oyuncunun ilk erişiminde tek SELECT ile kategoriler yükleniyor.
- Her satışta SQLite SELECT yapılmıyor.
- Değişiklikler 20 tick'te bir tek transaction/batch ile yazılıyor.
- Plugin kapanırken dirty kayıtlar flush ediliyor.
- SQLite WAL + NORMAL synchronous + busy_timeout kullanılıyor.

Maven derlemesi bu ortamda çalıştırılmadı; kaynak kodu statik olarak kontrol edildi.

package com.azy.sell;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.*;

public final class AzySell extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private Economy economy;
    private NamespacedKey axeKey, axeCreatedKey, axeLevelKey, upgradeKey;
    private final Set<UUID> filterEnabled = new HashSet<>();
    private final Set<UUID> autoEnabled = new HashSet<>();
    private final Map<UUID, Inventory> sellMenus = new HashMap<>();
    private final Set<UUID> searching = new HashSet<>();

    private static final long AXE_LIFETIME = 24L * 60L * 60L * 1000L;
    private static final int MAX_LEVEL = 5;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        axeKey = new NamespacedKey(this, "sell_axe");
        axeCreatedKey = new NamespacedKey(this, "sell_axe_created");
        axeLevelKey = new NamespacedKey(this, "sell_axe_level");
        upgradeKey = new NamespacedKey(this, "sell_axe_upgrade");

        RegisteredServiceProvider<Economy> rsp =
                getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp != null) economy = rsp.getProvider();

        getServer().getPluginManager().registerEvents(this, this);

        register("sell");
        register("sat");
        register("sellaxe");

        Bukkit.getScheduler().runTaskTimer(this, this::updateAxeLore, 20L, 20L * 30L);
    }

    private void register(String command) {
        PluginCommand c = getCommand(command);
        if (c == null) {
            getLogger().severe("plugin.yml içinde '" + command + "' komutu bulunamadı.");
            return;
        }
        c.setExecutor(this);
        c.setTabCompleter(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Bu komut sadece oyuncular içindir.");
            return true;
        }

        String name = command.getName().toLowerCase(Locale.ROOT);

        if (name.equals("sell") || name.equals("sat")) {
            if (args.length == 0) {
                openSell(p, null);
                return true;
            }

            String a = args[0].toLowerCase(Locale.ROOT);
            if (a.equals("filter") || a.equals("filtre")) {
                toggle(filterEnabled, p, "Filtre", "Filter");
                return true;
            }
            if (a.equals("auto") || a.equals("otomatik")) {
                toggle(autoEnabled, p, "Otomatik satış", "Auto sell");
                return true;
            }
            if (a.equals("search") || a.equals("ara")) {
                beginSearch(p);
                return true;
            }

            p.sendMessage(color("&cKullanım: &f/" + label +
                    " &7| &f/" + label + " filter&7/&f" + label +
                    " filtre &7| &f/" + label + " auto&7/&f" + label + " otomatik"));
            return true;
        }

        if (name.equals("sellaxe")) {
            if (args.length == 0 || args[0].equalsIgnoreCase("ver")) {
                if (!p.hasPermission("azysell.axe.get")) {
                    p.sendMessage(color("&cBu baltayı alma yetkin yok."));
                    return true;
                }
                giveAxe(p);
                return true;
            }

            if (args[0].equalsIgnoreCase("upgrade")
                    || args[0].equalsIgnoreCase("yukseltici")
                    || args[0].equalsIgnoreCase("yükseltici")) {
                if (!p.hasPermission("azysell.axe.get")) {
                    p.sendMessage(color("&cBu yükselticiyi alma yetkin yok."));
                    return true;
                }
                p.getInventory().addItem(createUpgrade());
                p.sendMessage(color("&aSatış baltası yükselticisi verildi."));
                return true;
            }

            if (args[0].equalsIgnoreCase("bilgi")) {
                p.sendMessage(color("&dAmetist Satış Baltası &7sandık/barrel içeriğini satar."));
                return true;
            }
        }
        return false;
    }

    private void toggle(Set<UUID> set, Player p, String tr, String en) {
        if (!set.add(p.getUniqueId())) {
            set.remove(p.getUniqueId());
            p.sendMessage(color("&c" + tr + " &7(&f" + en + "&7): &ckapalı"));
        } else {
            p.sendMessage(color("&a" + tr + " &7(&f" + en + "&7): &aaçık"));
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("sell") || name.equals("sat")) {
            if (args.length == 1) {
                return partial(args[0], List.of("filter", "filtre", "auto", "otomatik", "search", "ara"));
            }
            return List.of();
        }
        if (name.equals("sellaxe")) {
            if (args.length == 1) {
                return partial(args[0], List.of("ver", "upgrade", "yükseltici", "yukseltici", "bilgi"));
            }
        }
        return List.of();
    }

    private List<String> partial(String input, List<String> values) {
        String q = input.toLowerCase(Locale.ROOT);
        return values.stream().filter(v -> v.startsWith(q)).toList();
    }

    /* -------------------- SELL GUI -------------------- */

    private ItemStack button(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(color(name));
        if (lore != null && lore.length > 0) {
            List<String> colored = new ArrayList<>();
            for (String line : lore) {
                colored.add(color(line));
            }
            meta.setLore(colored);
        }
        item.setItemMeta(meta);
        return item;
    }

    private void openSell(Player p, String search) {
        Inventory inv = Bukkit.createInventory(null, 54, color("&5Satış Menüsü"));
        sellMenus.put(p.getUniqueId(), inv);

        // Keep the original 45-slot selling area.
        inv.setItem(45, button(Material.NAME_TAG, "&dArama / Search",
                "&7Türkçe: aramak için tıkla", "&7English: click to search"));
        inv.setItem(49, button(Material.LIME_STAINED_GLASS_PANE, "&aSAT / SELL",
                "&7Satılabilir eşyaları satar."));
        inv.setItem(53, button(
                autoEnabled.contains(p.getUniqueId()) ? Material.LIME_DYE : Material.GRAY_DYE,
                autoEnabled.contains(p.getUniqueId()) ? "&aOtomatik / Auto: AÇIK" : "&7Otomatik / Auto: KAPALI",
                "&7Durumu değiştirmek için tıkla."));

        if (search != null && !search.isBlank()) {
            inv.setItem(47, button(Material.COMPASS, "&bArama / Search",
                    "&f" + search, "&7Temizlemek için tekrar arama yap."));
        }

        p.openInventory(inv);
    }

    private void beginSearch(Player p) {
        searching.add(p.getUniqueId());
        p.closeInventory();
        p.sendMessage(color("&bArama / Search &7» &fAramak istediğin eşyanın adını yaz."));
        p.sendMessage(color("&7İngilizce veya Türkçe yazabilirsin. İptal: &ccancel"));
    }

    @EventHandler
    public void chatSearch(AsyncPlayerChatEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        if (!searching.remove(id)) return;
        e.setCancelled(true);

        String query = e.getMessage().trim();
        if (query.equalsIgnoreCase("cancel") || query.equalsIgnoreCase("iptal")) {
            Bukkit.getScheduler().runTask(this, () -> openSell(e.getPlayer(), null));
            return;
        }

        Bukkit.getScheduler().runTask(this, () -> openSell(e.getPlayer(), query));
    }

    @EventHandler
    public void sellClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory inv = sellMenus.get(p.getUniqueId());
        if (inv == null || e.getView().getTopInventory() != inv) return;

        int slot = e.getRawSlot();

        // Bottom inventory is free to use.
        if (slot >= inv.getSize()) return;

        if (slot >= 0 && slot < 45) return;

        e.setCancelled(true);

        if (slot == 45) {
            beginSearch(p);
            return;
        }

        if (slot == 49) {
            sellInventory(p, inv);
            return;
        }

        if (slot == 53) {
            UUID id = p.getUniqueId();
            if (autoEnabled.contains(id)) {
                autoEnabled.remove(id);
            } else {
                autoEnabled.add(id);
            }
            String query = null;
            openSell(p, query);
        }
    }

    @EventHandler
    public void sellDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory inv = sellMenus.get(p.getUniqueId());
        if (inv == null || e.getView().getTopInventory() != inv) return;

        for (int slot : e.getRawSlots()) {
            if (slot >= 45 && slot < inv.getSize()) {
                e.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void sellClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        Inventory inv = sellMenus.remove(p.getUniqueId());
        if (inv == null) return;

        // GUI buttons must never be returned to the player.
        inv.setItem(45, null);
        inv.setItem(47, null);
        inv.setItem(49, null);
        inv.setItem(53, null);

        if (autoEnabled.contains(p.getUniqueId())) {
            sellInventory(p, inv);
        } else {
            returnItems(p, inv);
        }
    }

    private void sellInventory(Player p, Inventory inv) {
        double total = 0;
        int count = 0;

        double multiplier = getConfig().getDouble("multiplier", 1.0);

        for (int i = 0; i < 45; i++) {
            ItemStack item = inv.getItem(i);
            if (item == null || item.getType() == Material.AIR) continue;

            double price = price(item.getType()) * multiplier;
            if (price <= 0) continue;

            total += price * item.getAmount();
            count += item.getAmount();
            inv.setItem(i, null);
        }

        if (total <= 0) {
            p.sendMessage(color("&cSatılabilir eşya bulunamadı. / No sellable items found."));
            return;
        }

        if (economy == null) {
            p.sendMessage(color("&cVault ekonomisi bulunamadı; eşyalar geri verildi."));
            returnItems(p, inv);
            return;
        }

        economy.depositPlayer(p, total);
        p.sendMessage(color("&aSatış tamamlandı! &7Eşya: &f" + count
                + " &8| &aKazanç: &e$" + format(total)));
    }

    private void returnItems(Player p, Inventory inv) {
        for (int i = 0; i < 45; i++) {
            ItemStack x = inv.getItem(i);
            if (x == null || x.getType() == Material.AIR) continue;

            Map<Integer, ItemStack> left = p.getInventory().addItem(x);
            left.values().forEach(v ->
                    p.getWorld().dropItemNaturally(p.getLocation(), v));
            inv.setItem(i, null);
        }
    }

    private double price(Material m) {
        if (m == null || m == Material.AIR) return 0;
        return getConfig().getDouble("items." + m.name(), 0);
    }

    /* -------------------- SELL AXE -------------------- */

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void axeInteract(PlayerInteractEvent e) {
        ItemStack hand = e.getItem();
        if (!isAxe(hand)) return;

        // The selling axe is deliberately NOT a normal tree-cutting tool.
        Block b = e.getClickedBlock();

        if (e.getAction() == Action.LEFT_CLICK_BLOCK || e.getAction() == Action.RIGHT_CLICK_BLOCK) {
            if (b == null || !isContainer(b.getType())) {
                e.setCancelled(true);
                return;
            }

            e.setCancelled(true);
            Player p = e.getPlayer();

            if (expired(hand)) {
                p.sendMessage(color("&cAmetist satış baltasının süresi doldu."));
                p.getInventory().setItemInMainHand(null);
                return;
            }

            sellContainer(p, (Container) b.getState(), hand);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void axeBreak(BlockBreakEvent e) {
        ItemStack hand = e.getPlayer().getInventory().getItemInMainHand();
        if (!isAxe(hand)) return;

        // Never let the special axe break any block, especially chests or trees.
        e.setCancelled(true);

        if (expired(hand)) {
            e.getPlayer().getInventory().setItemInMainHand(null);
            e.getPlayer().sendMessage(color("&cAmetist satış baltasının süresi doldu."));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void axeAnimation(PlayerAnimationEvent e) {
        // Prevent the vanilla swing animation from making the special axe
        // visually jump when it is used on a container.
        ItemStack hand = e.getPlayer().getInventory().getItemInMainHand();
        if (isAxe(hand)) e.setCancelled(true);
    }

    private boolean isContainer(Material m) {
        return m == Material.CHEST || m == Material.TRAPPED_CHEST || m == Material.BARREL;
    }

    private void sellContainer(Player p, Container c, ItemStack axe) {
        Inventory inv = c.getInventory();
        double total = 0;
        int sold = 0;
        double multiplier = getConfig().getDouble("multiplier", 1.0);

        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack x = inv.getItem(i);
            if (x == null || x.getType() == Material.AIR) continue;

            double pr = price(x.getType()) * multiplier;
            if (pr <= 0) continue;

            total += pr * x.getAmount();
            sold += x.getAmount();
            inv.setItem(i, null);
        }

        if (total <= 0) {
            p.sendMessage(color("&cBu sandıkta satılabilir eşya yok."));
            return;
        }

        if (economy == null) {
            p.sendMessage(color("&cVault ekonomisi bulunamadı; sandık içeriği korunuyor."));
            return;
        }

        economy.depositPlayer(p, total);
        p.sendMessage(color("&aSandık içeriği satıldı! &7" + sold
                + " eşya &8| &a$" + format(total)));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.2f);
    }

    /* -------------------- AXE ITEM -------------------- */

    private ItemStack createUpgrade() {
        ItemStack i = new ItemStack(Material.AMETHYST_SHARD);
        ItemMeta m = i.getItemMeta();
        m.setDisplayName(color("&dAmetist Satış Baltası Yükselticisi"));
        m.setLore(List.of(
                color("&7Satış baltasının seviyesini yükseltir."),
                color("&eSağ tık / Sol tık: &fGUI aç")
        ));
        m.getPersistentDataContainer().set(upgradeKey, PersistentDataType.BYTE, (byte) 1);
        i.setItemMeta(m);
        return i;
    }

    private ItemStack createAxe(int level) {
        ItemStack i = new ItemStack(Material.NETHERITE_AXE);
        ItemMeta m = i.getItemMeta();

        m.setDisplayName(color("&5ᴀᴍᴇᴛɪsᴛ sᴀᴛıŞ ʙᴀʟᴛᴀsı"));
        m.addEnchant(Enchantment.UNBREAKING, 3, true);
        m.addEnchant(Enchantment.MENDING, 1, true);

        m.getPersistentDataContainer().set(axeKey, PersistentDataType.BYTE, (byte) 1);
        m.getPersistentDataContainer().set(
                axeCreatedKey, PersistentDataType.LONG, System.currentTimeMillis());
        m.getPersistentDataContainer().set(
                axeLevelKey, PersistentDataType.INTEGER, level);

        m.setLore(axeLore(level, System.currentTimeMillis()));
        i.setItemMeta(m);
        return i;
    }

    private void giveAxe(Player p) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(createAxe(1));
        left.values().forEach(v -> p.getWorld().dropItemNaturally(p.getLocation(), v));
        p.sendMessage(color("&dAmetist satış baltası verildi."));
    }

    private boolean isAxe(ItemStack i) {
        return i != null
                && i.getType() == Material.NETHERITE_AXE
                && i.hasItemMeta()
                && i.getItemMeta().getPersistentDataContainer()
                .has(axeKey, PersistentDataType.BYTE);
    }

    private boolean isUpgrade(ItemStack i) {
        return i != null
                && i.hasItemMeta()
                && i.getItemMeta().getPersistentDataContainer()
                .has(upgradeKey, PersistentDataType.BYTE);
    }

    private boolean expired(ItemStack i) {
        if (!isAxe(i)) return false;
        Long t = i.getItemMeta().getPersistentDataContainer()
                .get(axeCreatedKey, PersistentDataType.LONG);
        return t == null || System.currentTimeMillis() - t >= AXE_LIFETIME;
    }

    private int level(ItemStack i) {
        Integer l = i.getItemMeta().getPersistentDataContainer()
                .get(axeLevelKey, PersistentDataType.INTEGER);
        return l == null ? 1 : l;
    }

    private List<String> axeLore(int level, long created) {
        long remain = Math.max(0,
                AXE_LIFETIME - (System.currentTimeMillis() - created));
        long h = remain / 3_600_000L;
        long m = (remain % 3_600_000L) / 60_000L;

        return List.of(
                color("&7Sandıkların içindekileri otomatik satar."),
                color("&7Seviye: &d" + level + "&7/&d" + MAX_LEVEL),
                color(""),
                color("&7Kırılmazlık III &8• &7Tamir"),
                color("&7Kendini yok etmeye kalan süre"),
                color("&d" + h + "h " + m + "m")
        );
    }

    private void updateAxeLore() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            for (int slot = 0; slot < p.getInventory().getSize(); slot++) {
                ItemStack i = p.getInventory().getItem(slot);
                if (!isAxe(i)) continue;

                if (expired(i)) {
                    p.getInventory().setItem(slot, null);
                    continue;
                }

                ItemMeta m = i.getItemMeta();
                Long c = m.getPersistentDataContainer()
                        .get(axeCreatedKey, PersistentDataType.LONG);
                if (c != null) {
                    m.setLore(axeLore(level(i), c));
                    i.setItemMeta(m);
                }
            }
        }
    }

    /* -------------------- UPGRADE GUI -------------------- */

    @EventHandler(priority = EventPriority.HIGHEST)
    public void upgradeInteract(PlayerInteractEvent e) {
        Action a = e.getAction();
        if (a != Action.LEFT_CLICK_AIR && a != Action.RIGHT_CLICK_AIR
                && a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack i = e.getItem();
        if (!isUpgrade(i)) return;

        e.setCancelled(true);
        openUpgrade(e.getPlayer());
    }

    private void openUpgrade(Player p) {
        Inventory inv = Bukkit.createInventory(null, 9, color("&5Satış Baltası Yükseltme"));

        for (int slot = 0; slot < 9; slot++) {
            if (slot == 4 || slot == 8) continue;
            inv.setItem(slot, glass(
                    Material.GRAY_STAINED_GLASS_PANE, "&7"));
        }

        // 5. slot (index 4) is deliberately empty.
        inv.setItem(8, glass(Material.LIME_STAINED_GLASS_PANE, "&aONAYLA"));
        p.openInventory(inv);
    }

    private ItemStack glass(Material m, String n) {
        ItemStack i = new ItemStack(m);
        ItemMeta x = i.getItemMeta();
        x.setDisplayName(color(n));
        i.setItemMeta(x);
        return i;
    }

    @EventHandler
    public void upgradeClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!ChatColor.stripColor(e.getView().getTitle())
                .equals("Satış Baltası Yükseltme")) return;

        int slot = e.getRawSlot();

        // 5th slot: only a valid Ametist selling axe may be placed here.
        if (slot == 4) {
            if (e.getClick().isShiftClick()) {
                e.setCancelled(true);
                return;
            }

            ItemStack cursor = e.getCursor();
            if (cursor != null && cursor.getType() != Material.AIR && !isAxe(cursor)) {
                e.setCancelled(true);
                p.sendMessage(color("&c5. slota sadece Ametist Satış Baltası koyabilirsin."));
                return;
            }

            e.setCancelled(false);
            return;
        }

        // Nothing else in the top inventory can be moved.
        e.setCancelled(true);

        if (slot != 8) return;

        ItemStack axe = e.getView().getTopInventory().getItem(4);
        if (!isAxe(axe)) {
            p.sendMessage(color("&cÖnce satış baltasını 5. slota koymalısınız."));
            return;
        }

        int l = level(axe);
        if (l >= MAX_LEVEL) {
            p.sendMessage(color("&cDaha fazla yükseltemezsiniz! Satış baltası zaten maksimum seviyede."));
            return;
        }

        if (!takeOneUpgrade(p)) {
            p.sendMessage(color("&cBir yükselticiye ihtiyacın var."));
            return;
        }

        ItemMeta am = axe.getItemMeta();
        am.getPersistentDataContainer().set(
                axeLevelKey, PersistentDataType.INTEGER, l + 1);

        Long created = am.getPersistentDataContainer()
                .get(axeCreatedKey, PersistentDataType.LONG);
        if (created != null) am.setLore(axeLore(l + 1, created));

        axe.setItemMeta(am);

        Map<Integer, ItemStack> left = p.getInventory().addItem(axe);
        left.values().forEach(v ->
                p.getWorld().dropItemNaturally(p.getLocation(), v));

        e.getView().getTopInventory().setItem(4, null);

        p.sendMessage(color("&aSatış baltası yükseltildi! &7Seviye: &d"
                + (l + 1) + "/" + MAX_LEVEL));
        p.closeInventory();
    }

    @EventHandler
    public void upgradeDrag(InventoryDragEvent e) {
        if (!ChatColor.stripColor(e.getView().getTitle())
                .equals("Satış Baltası Yükseltme")) return;

        for (int slot : e.getRawSlots()) {
            if (slot != 4) {
                e.setCancelled(true);
                return;
            }
        }

        ItemStack cursor = e.getOldCursor();
        if (cursor != null && cursor.getType() != Material.AIR && !isAxe(cursor)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void upgradeClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player p)) return;
        if (!ChatColor.stripColor(e.getView().getTitle())
                .equals("Satış Baltası Yükseltme")) return;

        ItemStack axe = e.getView().getTopInventory().getItem(4);
        if (isAxe(axe)) {
            Map<Integer, ItemStack> left = p.getInventory().addItem(axe);
            left.values().forEach(v ->
                    p.getWorld().dropItemNaturally(p.getLocation(), v));
            e.getView().getTopInventory().setItem(4, null);
        }
    }

    private boolean takeOneUpgrade(Player p) {
        for (int i = 0; i < p.getInventory().getSize(); i++) {
            ItemStack x = p.getInventory().getItem(i);
            if (!isUpgrade(x)) continue;

            if (x.getAmount() > 1) x.setAmount(x.getAmount() - 1);
            else p.getInventory().setItem(i, null);
            return true;
        }
        return false;
    }

    private String format(double d) {
        return String.format(Locale.US, "%,.2f", d);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}

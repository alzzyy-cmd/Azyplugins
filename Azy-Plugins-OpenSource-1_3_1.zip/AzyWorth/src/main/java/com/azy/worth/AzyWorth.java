package com.azy.worth;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.*;

public final class AzyWorth extends JavaPlugin implements Listener, org.bukkit.command.CommandExecutor {
    private final Map<Material, Double> prices = new EnumMap<>(Material.class);
    private final Map<String, List<Material>> categories = new LinkedHashMap<>();
    private final Map<UUID, Integer> pages = new HashMap<>();
    private final Map<UUID, String> openCategory = new HashMap<>();

    @Override public void onEnable() {
        saveDefaultConfig();
        loadPrices();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("AzyWorth aktif. " + prices.size() + " eşya fiyatı yüklendi.");
    }

    public void loadPrices() {
        prices.clear();
        for (String key : getConfig().getConfigurationSection("items").getKeys(false)) {
            try { prices.put(Material.valueOf(key.toUpperCase(Locale.ROOT)), getConfig().getDouble("items." + key)); }
            catch (IllegalArgumentException ignored) { }
        }
        buildCategories();
    }

    private void buildCategories() {
        categories.clear();
        addCategory("tarım", "Tarım", Set.of("WHEAT","WHEAT_SEEDS","CARROT","POTATO","BEETROOT","BEETROOT_SEEDS","MELON","MELON_SLICE","PUMPKIN","PUMPKIN_SEEDS","SUGAR_CANE","COCOA_BEANS","NETHER_WART","CACTUS","BAMBOO","SWEET_BERRIES","GLOW_BERRIES","APPLE","CHORUS_FRUIT"));
        addCategory("savaş", "Savaş", Set.of("DIAMOND_SWORD","NETHERITE_SWORD","IRON_SWORD","DIAMOND_AXE","NETHERITE_AXE","BOW","CROSSBOW","TRIDENT","SHIELD","ARROW","TOTEM_OF_UNDYING","ENDER_PEARL","GOLDEN_APPLE","ENCHANTED_GOLDEN_APPLE"));
        addCategory("maden", "Maden", Set.of("COAL","IRON_INGOT","RAW_IRON","COPPER_INGOT","RAW_COPPER","GOLD_INGOT","RAW_GOLD","DIAMOND","EMERALD","LAPIS_LAZULI","REDSTONE","NETHER_QUARTZ","ANCIENT_DEBRIS","NETHERITE_SCRAP","NETHERITE_INGOT"));
        addCategory("blok", "Bloklar", Set.of("STONE","COBBLESTONE","OAK_PLANKS","SPRUCE_PLANKS","BIRCH_PLANKS","JUNGLE_PLANKS","ACACIA_PLANKS","DARK_OAK_PLANKS","CHERRY_PLANKS","GLASS","BRICKS","STONE_BRICKS","SAND","RED_SAND","GRAVEL"));
        addCategory("nether", "Nether", Set.of("NETHERRACK","SOUL_SAND","SOUL_SOIL","GLOWSTONE_DUST","GLOWSTONE","NETHER_BRICK","NETHER_WART","MAGMA_CREAM","BLAZE_ROD","GHAST_TEAR","QUARTZ","NETHER_QUARTZ_ORE","ANCIENT_DEBRIS"));
        addCategory("end", "End", Set.of("END_STONE","END_STONE_BRICKS","PURPUR_BLOCK","PURPUR_PILLAR","CHORUS_FRUIT","CHORUS_FLOWER","SHULKER_SHELL","ENDER_PEARL","DRAGON_BREATH","ELYTRA"));
        addCategory("mob", "Mob", Set.of("ROTTEN_FLESH","BONE","STRING","SPIDER_EYE","GUNPOWDER","ENDER_PEARL","BLAZE_ROD","GHAST_TEAR","SLIME_BALL","MAGMA_CREAM","LEATHER","FEATHER","INK_SAC"));
        addCategory("balık", "Balık", Set.of("COD","SALMON","TROPICAL_FISH","PUFFERFISH","NAUTILUS_SHELL","HEART_OF_THE_SEA"));
        addCategory("ağaç", "Ağaç", Set.of("OAK_LOG","SPRUCE_LOG","BIRCH_LOG","JUNGLE_LOG","ACACIA_LOG","DARK_OAK_LOG","CHERRY_LOG","MANGROVE_LOG","PALE_OAK_LOG","OAK_LEAVES","SPRUCE_LEAVES","BIRCH_LEAVES","JUNGLE_LEAVES","ACACIA_LEAVES","DARK_OAK_LEAVES","CHERRY_LEAVES"));
    }

    private void addCategory(String key, String title, Set<String> wanted) {
        List<Material> list = new ArrayList<>();
        for (String s : wanted) { try { Material m=Material.valueOf(s); if (prices.containsKey(m)) list.add(m); } catch (Exception ignored) {} }
        if (!list.isEmpty()) categories.put(key, list);
    }

    public double getPrice(ItemStack item) { return item == null || item.getType() == Material.AIR ? 0 : prices.getOrDefault(item.getType(), 0.0); }
    public double getPrice(Material material) { return prices.getOrDefault(material, 0.0); }
    public double total(Inventory inv) { double total=0; for(ItemStack i:inv.getContents()) if(i!=null) total += getPrice(i)*i.getAmount(); return total; }
    public Set<String> getCategoryKeys(){ return categories.keySet(); }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (command.getName().equalsIgnoreCase("worth")) {
            if (args.length == 0) { openCategoryMenu(p); return true; }
            String key=args[0].toLowerCase(Locale.ROOT);
            if (categories.containsKey(key)) { pages.put(p.getUniqueId(),0); openCategory.put(p.getUniqueId(),key); openCategory(p,key,0); return true; }
            if (key.equals("reload")) { if(p.hasPermission("azyworth.reload")){ reloadConfig(); loadPrices(); p.sendMessage(color("&aAzyWorth fiyatları yenilendi.")); } return true; }
            p.sendMessage(color("&cKategori bulunamadı. Kullanılabilir: &f"+String.join(", ",categories.keySet()))); return true;
        }
        if (command.getName().equalsIgnoreCase("worthprice")) {
            if(args.length==0){p.sendMessage(color("&c/worthprice <eşya>"));return true;}
            try { Material m=Material.matchMaterial(args[0]); double price=getPrice(m); p.sendMessage(color("&7"+m.name()+" &8» &a$"+price)); } catch(Exception e){p.sendMessage(color("&cEşya bulunamadı."));} return true;
        }
        return false;
    }

    private void openCategoryMenu(Player p){
        Inventory inv=Bukkit.createInventory(null,54,color("&5Worth Kategorileri"));
        int slot=0; for(String k:categories.keySet()){ if(slot>=45)break; Material icon=categories.get(k).get(0); ItemStack it=new ItemStack(icon); ItemMeta im=it.getItemMeta(); im.setDisplayName(color("&d"+title(k))); im.setLore(List.of(color("&7Fiyatları görmek için tıkla."))); it.setItemMeta(im); inv.setItem(slot++,it); }
        p.openInventory(inv);
    }
    private void openCategory(Player p,String key,int page){
        List<Material> list=categories.get(key); if(list==null){openCategoryMenu(p);return;}
        int per=45; int max=Math.max(1,(list.size()+per-1)/per); page=Math.max(0,Math.min(page,max-1)); pages.put(p.getUniqueId(),page);
        Inventory inv=Bukkit.createInventory(null,54,color("&5Worth &8» &d"+title(key)+" &7("+(page+1)+"/"+max+")"));
        int from=page*per; for(int i=0;i<per && from+i<list.size();i++){Material m=list.get(from+i); ItemStack it=new ItemStack(m); ItemMeta im=it.getItemMeta(); im.setDisplayName(color("&f"+pretty(m.name()))); im.setLore(List.of(color("&7Satış fiyatı: &a$"+getPrice(m)))); it.setItemMeta(im); inv.setItem(i,it);}
        if(page>0) inv.setItem(45,button(Material.ARROW,"&cÖnceki"));
        inv.setItem(49,button(Material.BARRIER,"&7Kategoriler"));
        if(page<max-1) inv.setItem(53,button(Material.ARROW,"&aSonraki"));
        p.openInventory(inv);
    }
    private ItemStack button(Material m,String name){ItemStack it=new ItemStack(m);ItemMeta im=it.getItemMeta();im.setDisplayName(color(name));it.setItemMeta(im);return it;}
    @EventHandler public void click(InventoryClickEvent e){ if(!(e.getWhoClicked() instanceof Player p))return; String title=ChatColor.stripColor(e.getView().getTitle()); if(title.startsWith("Worth Kategorileri")){e.setCancelled(true);if(e.getCurrentItem()==null)return;Material m=e.getCurrentItem().getType();for(var en:categories.entrySet())if(!en.getValue().isEmpty()&&en.getValue().get(0)==m){openCategory.put(p.getUniqueId(),en.getKey());openCategory(p,en.getKey(),0);return;}} else if(title.startsWith("Worth ")){e.setCancelled(true);if(e.getRawSlot()==49){openCategoryMenu(p);return;}String key=openCategory.get(p.getUniqueId());if(key==null)return;int page=pages.getOrDefault(p.getUniqueId(),0);if(e.getRawSlot()==45)openCategory(p,key,page-1);else if(e.getRawSlot()==53)openCategory(p,key,page+1);}}
    @EventHandler public void close(InventoryCloseEvent e){pages.remove(e.getPlayer().getUniqueId());openCategory.remove(e.getPlayer().getUniqueId());}
    private String title(String k){return switch(k){case"tarım"->"Tarım";case"savaş"->"Savaş";case"maden"->"Maden";case"blok"->"Bloklar";case"nether"->"Nether";case"end"->"End";case"mob"->"Mob";case"balık"->"Balık";case"ağaç"->"Ağaç";default->k;};}
    private String pretty(String s){return s.toLowerCase(Locale.ROOT).replace('_',' ');}
    private String color(String s){return ChatColor.translateAlternateColorCodes('&',s);}
}

# Azy Plugins - Open Source

Bu paket yalnızca kaynak kodları içerir. Hazır JAR dosyaları bilerek dahil edilmedi.

## AzySell

Mevcut AzySell kaynak kodu temel alınarak düzenlendi:

- `/sell` ve `/sat` yalnızca istenen `filter/filtre` ve `auto/otomatik` seçeneklerini sunar.
- Tab completion Türkçe + İngilizce seçenekleri tamamlar.
- Satış GUI'sinde `Arama / Search` butonu ve iki dilli arama istemi bulunur.
- Satış GUI'sindeki butonlar oyuncunun eşyalarıyla karışmaz.
- `multiplier` artık satış fiyatında gerçekten uygulanır.
- Ametist satış baltası Netherite'dir.
- Baltanın sadece sandık/trapped chest/barrel içeriğini satmasına izin verilir.
- Özel balta normal blokları ve ağaçları kıramaz.
- Sandık yerinde kalır; yalnızca satılabilir içerik boşaltılır.
- Sol ve sağ tık ile sandık içeriği satılabilir.
- Özel baltanın vanilla swing animasyonu iptal edilir.
- 24 saatlik süre ve lore güncellemesi korunur.
- Yükseltici sağ/sol tıkla açılır.
- Yükseltme GUI'si 9 slotludur: 5. slot balta, 9. slot yeşil onay, diğer slotlar gri camdır.
- Maksimum seviyede yükseltme engellenir.
- Başarılı yükseltmede yükseltici tüketilir ve başarı mesajı gösterilir.
- GUI kapanınca balta kaybolmaz.
- Shift-click/drag gibi GUI kenar durumları engellenmiştir.

## AzyWorth

Mevcut AzyWorth kaynak kodu pakete yalnızca mevcut plugin olarak dahil edilmiştir; yeni bir plugin oluşturulmadı.

## Derleme

Paper 1.21.4 + Java 21 + Maven kullanacak şekilde mevcut `pom.xml` dosyaları korunmuştur.

Vault, AzySell için sunucuda dependency olarak gereklidir.

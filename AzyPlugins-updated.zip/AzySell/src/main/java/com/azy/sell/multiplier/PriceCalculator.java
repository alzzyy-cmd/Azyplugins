package com.azy.sell.multiplier;

import com.azy.sell.AzySell;
import com.azy.worth.AzyWorth;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

/**
 * Nihai satış fiyatını hesaplayan tek merkez.
 * Formül: taban_fiyat * global_multiplier(AzyWorth) * (1 + vip_ekstra_carpan(AzySell))
 *
 * Böylece:
 *  - AzyWorth'teki mevcut multiplier/fiyatlar asla değişmez, olduğu gibi kullanılır.
 *  - VIP çarpanı bunun ÜSTÜNE binen, tamamen ayrı ve isteğe bağlı bir katmandır.
 *
 * NOT: ItemStack alan metotlar (getUnitSellPrice(Player, ItemStack) gibi) AzyWorth'ün
 * özel-isim fiyat sistemini (custom-prices.yml) de hesaba katar; Material alan eski
 * metotlar SADECE materyal bazlı fiyata bakar. SellService artık ItemStack overload'ını
 * kullanıyor, böylece özel isimli eşyalar (varsa) doğru fiyatlanır.
 */
public class PriceCalculator {

    private final AzySell plugin;
    private AzyWorth azyWorth;

    public PriceCalculator(AzySell plugin) {
        this.plugin = plugin;
    }

    /**
     * AzyWorth plugin'ine bağlanır. AzyWorth yüklü değilse (teorik olarak plugin.yml'deki
     * "depend" bunu zaten engeller ama savunmacı programlama için) false döner.
     */
    public boolean linkAzyWorth() {
        Plugin found = plugin.getServer().getPluginManager().getPlugin("AzyWorth");
        if (found instanceof AzyWorth worth) {
            this.azyWorth = worth;
            return true;
        }
        return false;
    }

    public boolean isReady() {
        return azyWorth != null;
    }

    public boolean hasPrice(Material material) {
        return isReady() && azyWorth.getWorthManager().hasPrice(material);
    }

    public boolean hasPrice(ItemStack stack) {
        return isReady() && azyWorth.getWorthManager().hasPriceForItem(stack);
    }

    /** Bir adet eşyanın, oyuncunun VIP çarpanı dahil nihai satış fiyatı (materyal bazlı, ESKİ metot). */
    public double getUnitSellPrice(Player player, Material material) {
        if (!isReady()) return 0;
        double base = azyWorth.getWorthManager().getUnitPrice(material); // taban * global multiplier
        double vipExtra = plugin.getMultiplierManager().getExtraMultiplier(player);
        return base * (1 + vipExtra);
    }

    /**
     * Bir adet eşyanın, oyuncunun VIP çarpanı dahil nihai satış fiyatı.
     * Item'ın özel bir ismi varsa ve custom-prices.yml'de tanımlıysa o fiyat kullanılır,
     * yoksa materyal bazlı fiyata düşülür.
     */
    public double getUnitSellPrice(Player player, ItemStack stack) {
        if (!isReady()) return 0;
        double base = azyWorth.getWorthManager().getUnitPriceForItem(stack);
        double vipExtra = plugin.getMultiplierManager().getExtraMultiplier(player);
        return base * (1 + vipExtra);
    }

    public double getGlobalMultiplier() {
        return isReady() ? azyWorth.getWorthManager().getGlobalMultiplier() : 1.0;
    }
}

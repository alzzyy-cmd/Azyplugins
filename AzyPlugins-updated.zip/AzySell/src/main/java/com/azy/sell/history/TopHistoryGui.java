package com.azy.sell.history;

import com.azy.sell.AzySell;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * /tophistory admin komutuyla açılan ekran.
 * Sunucu genelinde (TÜM oyuncular toplamı) en çok satılan / en çok kazandıran
 * eşyaları, satış adedi ve toplam kazancıyla birlikte gösterir. Sayfalanabilir
 * (her sayfada 45 eşya, alt satırda önceki/sonraki butonları + genel toplam).
 */
public class TopHistoryGui implements InventoryHolder {

    private static final int PAGE_SIZE = 44;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_SORT = 48;
    private static final int SLOT_SUMMARY = 49;
    private static final int SLOT_NEXT = 53;

    private final AzySell plugin;
    private final int page;
    private final SortMode sortMode;
    private Inventory inventory;

    public TopHistoryGui(AzySell plugin) {
        this(plugin, 0, SortMode.HIGHEST_PRICE);
    }

    public TopHistoryGui(AzySell plugin, int page) {
        this(plugin, page, SortMode.HIGHEST_PRICE);
    }

    public TopHistoryGui(AzySell plugin, int page, SortMode sortMode) {
        this.plugin = plugin;
        this.page = page;
        this.sortMode = sortMode;
    }

    public void open(Player player) {
        int totalDistinct = plugin.getHistoryManager().getGlobalDistinctItemCount();
        int maxPages = Math.max(1, (int) Math.ceil(totalDistinct / (double) PAGE_SIZE));
        int clampedPage = Math.max(0, Math.min(page, maxPages - 1));

        List<SellHistoryManager.HistoryEntry> entries =
                plugin.getHistoryManager().getGlobalTop(PAGE_SIZE, clampedPage * PAGE_SIZE, sortMode);
        SellHistoryManager.GlobalTotals totals = plugin.getHistoryManager().getGlobalTotals();

        String title = plugin.msg("&8Sunucu Satış İstatistikleri &7(Sayfa " + (clampedPage + 1) + "/" + maxPages + ")");
        inventory = Bukkit.createInventory(this, 54, title);

        int rankOffset = clampedPage * PAGE_SIZE;
        for (int i = 0; i < entries.size() && i < PAGE_SIZE; i++) {
            inventory.setItem(i, buildEntryItem(entries.get(i), rankOffset + i + 1));
        }

        if (clampedPage > 0) {
            inventory.setItem(SLOT_PREV, navButton("&aÖnceki Sayfa"));
        }
        if (clampedPage < maxPages - 1) {
            inventory.setItem(SLOT_NEXT, navButton("&aSonraki Sayfa"));
        }
        inventory.setItem(SLOT_SORT, sortButton());

        ItemStack summary = new ItemStack(Material.PAPER);
        ItemMeta meta = summary.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&e&lGenel Toplam"));
            meta.setLore(List.of(
                    plugin.msg("&7Toplam satılan eşya: &f" + totals.totalAmount()),
                    plugin.msg("&7Toplam ödenen para: &a$" + format(totals.totalPrice())),
                    plugin.msg("&7Farklı eşya çeşidi: &f" + totalDistinct)
            ));
            summary.setItemMeta(meta);
        }
        inventory.setItem(SLOT_SUMMARY, summary);

        player.openInventory(inventory);
    }

    private ItemStack buildEntryItem(SellHistoryManager.HistoryEntry entry, int rank) {
        ItemStack stack = new ItemStack(entry.material());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.text("#" + rank + " ", NamedTextColor.YELLOW)
                    .decoration(TextDecoration.ITALIC, false)
                    .append(Component.translatable(entry.material().translationKey(), NamedTextColor.WHITE)));
            meta.setLore(List.of(
                    plugin.msg("&7Toplam satılan miktar: &f" + entry.totalAmount()),
                    plugin.msg("&7Toplam kazandırdığı para: &a$" + format(entry.totalPrice()))
            ));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack navButton(String name) {
        ItemStack stack = new ItemStack(Material.ARROW);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack sortButton() {
        ItemStack stack = new ItemStack(Material.HOPPER);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&eSıralama: " + sortMode.getDisplayName()));
            meta.setLore(List.of(plugin.msg("&7Değiştirmek için tıkla")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String format(double price) {
        if (price == Math.floor(price)) return String.valueOf((long) price);
        return String.format("%.2f", price);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public int getPage() {
        return page;
    }

    public SortMode getSortMode() {
        return sortMode;
    }

    public static int getSlotPrev() { return SLOT_PREV; }
    public static int getSlotNext() { return SLOT_NEXT; }
    public static int getSlotSort() { return SLOT_SORT; }
}

package com.azy.sell.gui;

import com.azy.sell.AzySell;
import com.azy.sell.SellService;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.InventoryHolder;

public class SellGuiListener implements Listener {

    private final AzySell plugin;

    public SellGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof SellGuiHolder)) return;
        if (!(event.getPlayer() instanceof Player player)) return;

        SellService.SellResult result = plugin.getSellService().sellInventory(player, event.getInventory());
        if (result.isEmpty()) {
            // Hiçbir şey satılmadıysa (fiyatsız eşyalar konulmuş vs.) eşyaları oyuncuya geri ver.
            for (var stack : event.getInventory().getContents()) {
                if (stack != null && !stack.getType().isAir()) {
                    player.getInventory().addItem(stack);
                }
            }
        }
    }
}

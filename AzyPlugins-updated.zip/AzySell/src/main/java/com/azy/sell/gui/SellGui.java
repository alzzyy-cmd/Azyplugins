package com.azy.sell.gui;

import com.azy.sell.AzySell;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/**
 * Drag & Drop sell GUI'si. Senin isteğin doğrultusunda 6 satır (54 slot),
 * DonutWorth2'nin 36 slotluk (4 satır) GUI'sinden BÜYÜK.
 *
 * Kullanım: oyuncu satmak istediği eşyaları buraya sürükler, envanteri kapatınca
 * (SellGuiListener.onClose) içindeki her şey otomatik satılır.
 */
public class SellGui {

    public static final int SIZE = 54;

    private final AzySell plugin;

    public SellGui(AzySell plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        String title = plugin.msg(plugin.getConfig().getString("sell-gui.title", "&8Satılacak eşyaları buraya koy"));
        SellGuiHolder holder = new SellGuiHolder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, title);
        holder.setInventory(inv);
        player.openInventory(inv);
    }
}

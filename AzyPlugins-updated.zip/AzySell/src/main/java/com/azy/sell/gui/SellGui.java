package com.azy.sell.gui;

import com.azy.sell.AzySell;
import com.azy.sell.category.CategoryDefinition;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;

/**
 * Drag & Drop sell GUI'si (54 slot, 6 satır):
 *  - Satır 1-4 (slot 0-35): satılacak eşyaların bırakıldığı serbest alan.
 *  - Satır 5 (slot 36-44): kategori butonları - her biri o kategorinin ŞU ANKİ
 *    çarpanını gösterir, tıklanınca CategoryProgressGui açılır. Bu slotlara
 *    eşya BIRAKILAMAZ ve buradaki ikonlar ASLA satılmaz (SellGuiListener bu
 *    alanı satış mantığından tamamen hariç tutar).
 *  - Satır 6 (slot 45-53): oyuncunun kendi envanterinin son satırı için ayrılmış
 *    boşluk yerine burada da kategori bilgisi göstermek yerine boş bırakılır
 *    (Bukkit üst envanter/oyuncu envanteri ayrımı gereği bu satır üst GUI'ye ait).
 *
 * Kullanım: oyuncu satmak istediği eşyaları serbest alana sürükler, envanteri
 * kapatınca (SellGuiListener.onClose) içindeki her şey otomatik satılır.
 */
public class SellGui {

    public static final int SIZE = 54;
    public static final int SELLABLE_AREA_SIZE = 36; // 4 satır
    private static final int CATEGORY_ROW_START = 36; // 5. satır başlangıcı

    private final AzySell plugin;

    public SellGui(AzySell plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        String title = plugin.msg(plugin.getConfig().getString("sell-gui.title", "&8Satılacak eşyaları buraya koy"));
        SellGuiHolder holder = new SellGuiHolder();
        Inventory inv = Bukkit.createInventory(holder, SIZE, title);
        holder.setInventory(inv);
        holder.setSellableAreaSize(SELLABLE_AREA_SIZE);

        List<CategoryDefinition> categories = plugin.getCategoryProgressManager().getCategories();
        for (int i = 0; i < categories.size() && i < 9; i++) {
            inv.setItem(CATEGORY_ROW_START + i, buildCategoryButton(player, categories.get(i)));
        }

        player.openInventory(inv);
    }

    private ItemStack buildCategoryButton(Player player, CategoryDefinition category) {
        double progress = plugin.getCategoryProgressManager().getProgress(player.getUniqueId(), category.getId());
        double currentMultiplier = category.getMultiplierForProgress(progress);

        ItemStack stack = new ItemStack(category.getIcon());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(category.getDisplayName() + " &7(&a" + formatMultiplier(currentMultiplier) + "x&7)"));
            meta.setLore(List.of(
                    category.getDescription(),
                    "",
                    plugin.msg("&eTıkla ve ilerlemeni gör")
            ));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String formatMultiplier(double value) {
        if (value == Math.floor(value)) {
            return String.format("%.1f", value);
        }
        return String.valueOf(value);
    }

    /**
     * SellGuiListener'ın kategori satırındaki bir tıklamayı hangi kategoriye
     * eşlediğini bulmak için kullanılır. relativeSlot = tıklanan slot - CATEGORY_ROW_START.
     */
    public static CategoryDefinition getCategoryForSlot(AzySell plugin, int relativeSlot) {
        List<CategoryDefinition> categories = plugin.getCategoryProgressManager().getCategories();
        if (relativeSlot < 0 || relativeSlot >= categories.size()) return null;
        return categories.get(relativeSlot);
    }
}

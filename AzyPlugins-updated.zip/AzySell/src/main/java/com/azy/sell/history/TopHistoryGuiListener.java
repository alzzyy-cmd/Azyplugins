package com.azy.sell.history;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

public class TopHistoryGuiListener implements Listener {

    private final AzySell plugin;

    public TopHistoryGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof TopHistoryGui gui)) return;

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) {
            return;
        }

        Player player = (Player) event.getWhoClicked();
        int slot = event.getSlot();

        if (slot == TopHistoryGui.getSlotPrev()) {
            new TopHistoryGui(plugin, gui.getPage() - 1, gui.getSortMode()).open(player);
        } else if (slot == TopHistoryGui.getSlotNext()) {
            new TopHistoryGui(plugin, gui.getPage() + 1, gui.getSortMode()).open(player);
        } else if (slot == TopHistoryGui.getSlotSort()) {
            new TopHistoryGui(plugin, 0, gui.getSortMode().next()).open(player);
        }
    }
}

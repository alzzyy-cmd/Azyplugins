package com.azy.sell.history;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

public class SellHistoryGuiListener implements Listener {

    private final AzySell plugin;

    public SellHistoryGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof SellHistoryGui gui)) return;

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) {
            return;
        }

        Player player = (Player) event.getWhoClicked();
        int slot = event.getSlot();

        if (slot == SellHistoryGui.getSlotPrev()) {
            new SellHistoryGui(plugin, gui.getTargetPlayer(), gui.getPage() - 1).open(player);
        } else if (slot == SellHistoryGui.getSlotNext()) {
            new SellHistoryGui(plugin, gui.getTargetPlayer(), gui.getPage() + 1).open(player);
        }
    }
}

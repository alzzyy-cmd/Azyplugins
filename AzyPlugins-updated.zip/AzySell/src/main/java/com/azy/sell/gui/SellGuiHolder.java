package com.azy.sell.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class SellGuiHolder implements InventoryHolder {

    private Inventory inventory;
    /**
     * Satılabilir eşyaların konulabileceği alan bu slot numarasından ÖNCEKİ
     * slotlardır (0..sellableAreaSize-1). Bu slottan sonrası (kategori
     * butonları vb.) satış mantığına HİÇ dahil edilmez - oraya tıklamak veya
     * bir eşya bırakmak asla satılmaz.
     */
    private int sellableAreaSize;

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public void setSellableAreaSize(int sellableAreaSize) {
        this.sellableAreaSize = sellableAreaSize;
    }

    public int getSellableAreaSize() {
        return sellableAreaSize;
    }
}

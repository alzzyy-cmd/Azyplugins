package com.azy.sell.history;

import com.azy.sell.AzySell;
import org.bukkit.Material;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Satış geçmişini SQLite üzerinde tutar (DonutWorth2'nin sellhistory.yml'sine benzer
 * amaç, ama sorgulanabilir bir veritabanı formatında). Her satış işlemi için
 * (oyuncu, eşya, miktar, toplam_fiyat, tarih) kaydı tutulur.
 */
public class SellHistoryManager {

    private final AzySell plugin;
    private Connection connection;

    public SellHistoryManager(AzySell plugin) {
        this.plugin = plugin;
    }

    public void setup() {
        try {
            File dbFile = new File(plugin.getDataFolder(), "sellhistory.db");
            plugin.getDataFolder().mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());

            try (Statement st = connection.createStatement()) {
                st.execute("""
                        CREATE TABLE IF NOT EXISTS sell_history (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            player_uuid TEXT NOT NULL,
                            material TEXT NOT NULL,
                            amount INTEGER NOT NULL,
                            total_price REAL NOT NULL,
                            sold_at INTEGER NOT NULL
                        )
                        """);
                // Oyuncu bazlı özet (getSummary): WHERE player_uuid=? + GROUP BY material + SUM(amount, total_price)
                // tamamen bu index üzerinden karşılanır, ana tabloya (heap lookup) hiç inilmez.
                st.execute("""
                        CREATE INDEX IF NOT EXISTS idx_player_material_covering
                        ON sell_history(player_uuid, material, amount, total_price)
                        """);
                // Sunucu geneli sorgular (getGlobalTop / getGlobalDistinctItemCount / getGlobalTotals):
                // GROUP BY material zaten index sırasına göre geldiği için SQLite temp B-Tree kurmadan
                // sıralı taramayla gruplayabilir, COUNT(DISTINCT material) da bu index'ten anında okunur.
                st.execute("""
                        CREATE INDEX IF NOT EXISTS idx_material_covering
                        ON sell_history(material, amount, total_price)
                        """);
                // Eski tekil-kolon index kalmışsa (önceki sürümden) kaldır; artık gereksiz —
                // yukarıdaki composite index onun yerine de geçiyor ve fazladan disk/yazma maliyeti yaratmasın.
                st.execute("DROP INDEX IF EXISTS idx_player");
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "sellhistory.db açılamadı!", ex);
        }
    }

    public void recordSale(UUID playerUuid, Material material, int amount, double totalPrice) {
        if (connection == null) return;
        try (PreparedStatement ps = connection.prepareStatement(
                "INSERT INTO sell_history (player_uuid, material, amount, total_price, sold_at) VALUES (?, ?, ?, ?, ?)")) {
            ps.setString(1, playerUuid.toString());
            ps.setString(2, material.name());
            ps.setInt(3, amount);
            ps.setDouble(4, totalPrice);
            ps.setLong(5, System.currentTimeMillis());
            ps.executeUpdate();
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Satış geçmişi kaydedilemedi", ex);
        }
    }

    /**
     * Oyuncunun eşya bazlı satış özetini SAYFALI döner. /satisgecmisi bunu kullanır.
     *
     * @param limit  kaç sonuç dönsün (bir sayfa boyutu, örn. 45)
     * @param offset kaç sonuç atlanacak (sayfa * limit)
     */
    public List<HistoryEntry> getSummary(UUID playerUuid, int limit, int offset) {
        List<HistoryEntry> results = new ArrayList<>();
        if (connection == null) return results;

        String sql = """
                SELECT material, SUM(amount) as total_amount, SUM(total_price) as total_price
                FROM sell_history
                WHERE player_uuid = ?
                GROUP BY material
                ORDER BY total_price DESC
                LIMIT ? OFFSET ?
                """;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, playerUuid.toString());
            ps.setInt(2, limit);
            ps.setInt(3, offset);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Material material = Material.matchMaterial(rs.getString("material"));
                    if (material == null) continue;
                    results.add(new HistoryEntry(material, rs.getLong("total_amount"), rs.getDouble("total_price")));
                }
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Satış geçmişi okunamadı", ex);
        }
        return results;
    }

    /** Oyuncunun kaç FARKLI eşya çeşidi sattığı (sayfalama için toplam sayfa hesabında kullanılır). */
    public int getPlayerDistinctItemCount(UUID playerUuid) {
        if (connection == null) return 0;
        String sql = "SELECT COUNT(DISTINCT material) as cnt FROM sell_history WHERE player_uuid = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, playerUuid.toString());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("cnt");
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Eşya çeşidi sayısı okunamadı", ex);
        }
        return 0;
    }

    /**
     * SUNUCU GENELİ (tüm oyuncular toplamı) en çok satılan eşyalar, sayfalanabilir.
     * /tophistory admin komutu bunu kullanır: "hangi eşya toplam ne kadar satılmış,
     * ne kadar para kazandırmış" sorusuna cevap verir.
     *
     * @param limit  kaç sonuç dönsün (bir sayfa boyutu, örn. 45)
     * @param offset kaç sonuç atlanacak (sayfa * limit)
     */
    public List<HistoryEntry> getGlobalTop(int limit, int offset) {
        List<HistoryEntry> results = new ArrayList<>();
        if (connection == null) return results;

        String sql = """
                SELECT material, SUM(amount) as total_amount, SUM(total_price) as total_price
                FROM sell_history
                GROUP BY material
                ORDER BY total_price DESC
                LIMIT ? OFFSET ?
                """;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Material material = Material.matchMaterial(rs.getString("material"));
                    if (material == null) continue;
                    results.add(new HistoryEntry(material, rs.getLong("total_amount"), rs.getDouble("total_price")));
                }
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Sunucu geneli satış istatistiği okunamadı", ex);
        }
        return results;
    }

    /** Sunucu genelinde kaç FARKLI eşya çeşidi satılmış (sayfalama için toplam sayfa hesabında kullanılır). */
    public int getGlobalDistinctItemCount() {
        if (connection == null) return 0;
        String sql = "SELECT COUNT(DISTINCT material) as cnt FROM sell_history";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt("cnt");
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Eşya çeşidi sayısı okunamadı", ex);
        }
        return 0;
    }

    /** Sunucu genelinde şimdiye kadar satılan toplam eşya sayısı ve toplam kazanılan para. */
    public GlobalTotals getGlobalTotals() {
        if (connection == null) return new GlobalTotals(0, 0);
        String sql = "SELECT SUM(amount) as total_amount, SUM(total_price) as total_price FROM sell_history";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                return new GlobalTotals(rs.getLong("total_amount"), rs.getDouble("total_price"));
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Sunucu geneli toplam okunamadı", ex);
        }
        return new GlobalTotals(0, 0);
    }

    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ignored) {
            }
        }
    }

    public record HistoryEntry(Material material, long totalAmount, double totalPrice) {
    }

    public record GlobalTotals(long totalAmount, double totalPrice) {
    }
}

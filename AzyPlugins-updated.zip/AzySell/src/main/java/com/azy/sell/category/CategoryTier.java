package com.azy.sell.category;

/**
 * Bir kategorinin tek bir eşiğini (tier) temsil eder: bu eşiğe ulaşmak için
 * gereken TOPLAM birikimli satış miktarı ve o eşiğe ulaşınca aktif olan çarpan.
 */
public record CategoryTier(double requiredAmount, double multiplier) {
}

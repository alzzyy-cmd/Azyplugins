package com.azy.sell;

import com.azy.sell.gui.SellGui;
import com.azy.sell.gui.SellGuiListener;
import com.azy.sell.history.SellHistoryGui;
import com.azy.sell.history.SellHistoryGuiListener;
import com.azy.sell.history.SellHistoryManager;
import com.azy.sell.history.TopHistoryGui;
import com.azy.sell.history.TopHistoryGuiListener;
import com.azy.sell.items.SellAxeItem;
import com.azy.sell.items.SellAxeListener;
import com.azy.sell.multiplier.PriceCalculator;
import com.azy.sell.multiplier.SellMultiplierManager;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AzySell extends JavaPlugin {

    private static final Pattern HEX_PATTERN = Pattern.compile("#([A-Fa-f0-9]{6})");

    private EconomyManager economyManager;
    private PriceCalculator priceCalculator;
    private SellMultiplierManager multiplierManager;
    private SellHistoryManager historyManager;
    private SellService sellService;
    private SellAxeItem sellAxeItem;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // AzyWorth zorunlu bağımlılık (plugin.yml -> depend). Yüklü değilse Bukkit
        // bu plugin'i zaten hiç enable etmez, ama savunmacı programlama için kontrol ediyoruz.
        this.priceCalculator = new PriceCalculator(this);
        if (!priceCalculator.linkAzyWorth()) {
            getLogger().severe("AzyWorth bulunamadı! AzySell çalışamaz, devre dışı bırakılıyor.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.economyManager = new EconomyManager(this);
        if (!economyManager.setup()) {
            getLogger().warning("Vault veya bir ekonomi plugin'i (EssentialsX vb.) bulunamadı! Satış kazançları eklenemeyecek.");
        }

        this.multiplierManager = new SellMultiplierManager(this);
        multiplierManager.load();

        this.historyManager = new SellHistoryManager(this);
        historyManager.setup();

        this.sellService = new SellService(this);
        this.sellAxeItem = new SellAxeItem(this);

        getServer().getPluginManager().registerEvents(new SellGuiListener(this), this);
        getServer().getPluginManager().registerEvents(new SellAxeListener(this, sellAxeItem), this);
        getServer().getPluginManager().registerEvents(new TopHistoryGuiListener(this), this);
        getServer().getPluginManager().registerEvents(new SellHistoryGuiListener(this), this);

        getLogger().info("AzySell aktif edildi.");
    }

    @Override
    public void onDisable() {
        if (historyManager != null) {
            historyManager.close();
        }
        getLogger().info("AzySell devre dışı bırakıldı.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase()) {
            case "sat" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                    return true;
                }
                if (!player.hasPermission("azysell.use")) {
                    player.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                if (args.length > 0 && args[0].equalsIgnoreCase("axe") && player.hasPermission("azysell.axe.get")) {
                    sellAxeItem.give(player);
                    player.sendMessage(msg("&aSatış baltası envanterine eklendi."));
                    return true;
                }
                new SellGui(this).open(player);
                return true;
            }
            case "satisgecmisi" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                    return true;
                }
                new SellHistoryGui(this, player.getUniqueId()).open(player);
                return true;
            }
            case "tophistory" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                    return true;
                }
                if (!player.hasPermission("azysell.admin")) {
                    player.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                new TopHistoryGui(this).open(player);
                return true;
            }
            case "azysellreload" -> {
                if (!sender.hasPermission("azysell.reload")) {
                    sender.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                reloadConfig();
                multiplierManager.load();
                sender.sendMessage(msg("&aAzySell configleri yeniden yüklendi."));
                return true;
            }
            case "azysellcarpan" -> {
                Player target;
                if (args.length > 0) {
                    target = getServer().getPlayer(args[0]);
                    if (target == null) {
                        sender.sendMessage(msg("&cOyuncu bulunamadı veya çevrimdışı."));
                        return true;
                    }
                } else if (sender instanceof Player p) {
                    target = p;
                } else {
                    sender.sendMessage(msg("&cKonsoldan kullanırken bir oyuncu adı belirtmelisin."));
                    return true;
                }
                double extra = multiplierManager.getExtraMultiplier(target);
                double global = priceCalculator.getGlobalMultiplier();
                sender.sendMessage(msg("&7" + target.getName() + " &7için:"));
                sender.sendMessage(msg("&7- Global çarpan: &f" + global + "x"));
                sender.sendMessage(msg("&7- VIP ekstra çarpan: &f+" + (extra * 100) + "%"));
                sender.sendMessage(msg("&7- Toplam etkin çarpan: &a" + (global * (1 + extra)) + "x"));
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    public String msg(String raw) {
        Matcher matcher = HEX_PATTERN.matcher(raw);
        StringBuilder buffer = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.toCharArray()) {
                replacement.append('§').append(c);
            }
            matcher.appendReplacement(buffer, replacement.toString());
        }
        matcher.appendTail(buffer);
        return ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public PriceCalculator getPriceCalculator() {
        return priceCalculator;
    }

    public SellMultiplierManager getMultiplierManager() {
        return multiplierManager;
    }

    public SellHistoryManager getHistoryManager() {
        return historyManager;
    }

    public SellService getSellService() {
        return sellService;
    }

    public SellAxeItem getSellAxeItem() {
        return sellAxeItem;
    }
}

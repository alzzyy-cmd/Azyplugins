package com.azy.sell.category;

import com.azy.sell.AzySell;
import com.azy.sell.gui.SellGui;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * MultiplierSummaryGui salt-okunur bir özet ekrandır: hiçbir eşya
 * alınamaz/bırakılamaz/sürüklenemez.
 *  - Kategori slotlarından (9-17) birine tıklanınca, o kategorinin
 *    CategoryProgressGui (54 slot, snake-path) ekranı açılır.
 *  - Kırmızı "Geri Dön" butonuna (slot 18) tıklanınca ana Sell GUI'sine döner.
 */
public class MultiplierSummaryGuiListener implements Listener {

    private final AzySell plugin;

    public MultiplierSummaryGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (!(holder instanceof MultiplierSummaryGui)) {
            return;
        }
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }

        int slot = event.getRawSlot();

        if (slot == MultiplierSummaryGui.BACK_BUTTON_SLOT) {
            player.closeInventory();
            new SellGui(plugin).open(player);
            return;
        }

        CategoryDefinition category = MultiplierSummaryGui.getCategoryForSlot(plugin, slot);
        if (category != null) {
            player.closeInventory();
            new CategoryProgressGui(plugin, category).open(player);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof MultiplierSummaryGui) {
            event.setCancelled(true);
        }
    }
}

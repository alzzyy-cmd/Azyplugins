package com.azy.sell.items;

import com.azy.sell.AzySell;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.List;

/**
 * Sell Axe: sandığı kırınca içindeki tüm satılabilir eşyaları anında satar.
 * Item'ı PersistentDataContainer'da bir işaretleyici (marker) ile "gerçek" olarak
 * damgalıyoruz, böylece adı/görünümü aynı olan sıradan bir balta ile karıştırılmaz.
 */
public class SellAxeItem {

    private static final String KEY_NAME = "azysell_axe";

    private final AzySell plugin;
    private final NamespacedKey markerKey;

    public SellAxeItem(AzySell plugin) {
        this.plugin = plugin;
        this.markerKey = new NamespacedKey(plugin, KEY_NAME);
    }

    public ItemStack create() {
        Material material = Material.matchMaterial(
                plugin.getConfig().getString("sell-axe.material", "GOLDEN_AXE"));
        if (material == null) material = Material.GOLDEN_AXE;

        ItemStack axe = new ItemStack(material);
        ItemMeta meta = axe.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(plugin.getConfig().getString("sell-axe.name", "&6SATIŞ BALTASI")));
            List<String> lore = plugin.getConfig().getStringList("sell-axe.lore");
            meta.setLore(lore.stream().map(plugin::msg).toList());
            meta.getPersistentDataContainer().set(markerKey, PersistentDataType.BYTE, (byte) 1);
            axe.setItemMeta(meta);
        }
        return axe;
    }

    public boolean isSellAxe(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(markerKey, PersistentDataType.BYTE);
    }

    public void give(Player player) {
        player.getInventory().addItem(create());
    }
}

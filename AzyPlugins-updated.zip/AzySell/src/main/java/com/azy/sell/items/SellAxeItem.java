package com.azy.sell.items;

import com.azy.sell.AzySell;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/**
 * Sell Axe: sandığı kırınca içindeki tüm satılabilir eşyaları anında satar.
 * Item'ı PersistentDataContainer'da bir işaretleyici (marker) ile "gerçek" olarak
 * damgalıyoruz, böylece adı/görünümü aynı olan sıradan bir balta ile karıştırılmaz.
 *
 * KULLANIM LİMİTİ: config'teki "sell-axe.max-uses" değeri kadar kullanılabilir
 * (varsayılan 2500). Kalan kullanım sayısı, item'ın PersistentDataContainer'ında
 * (KEY_USES_LEFT) kalıcı olarak tutulur - lore'da "&7Kalan kullanım: &fX" satırı
 * olarak gösterilir ve her kullanımda (SellAxeListener) 1 azaltılıp lore yeniden
 * çizilir. 0'a inince item envanterden kaldırılır (kırılır/yok olur).
 * max-uses config'te 0 ya da negatifse SINIRSIZ kullanım (eski davranış) korunur -
 * bu durumda ne sayaç tutulur ne de lore'a kullanım satırı eklenir.
 */
public class SellAxeItem {

    private static final String KEY_NAME = "azysell_axe";
    private static final String KEY_USES_LEFT_NAME = "azysell_axe_uses_left";

    private final AzySell plugin;
    private final NamespacedKey markerKey;
    private final NamespacedKey usesLeftKey;

    public SellAxeItem(AzySell plugin) {
        this.plugin = plugin;
        this.markerKey = new NamespacedKey(plugin, KEY_NAME);
        this.usesLeftKey = new NamespacedKey(plugin, KEY_USES_LEFT_NAME);
    }

    public ItemStack create() {
        Material material = Material.matchMaterial(
                plugin.getConfig().getString("sell-axe.material", "GOLDEN_AXE"));
        if (material == null) material = Material.GOLDEN_AXE;

        ItemStack axe = new ItemStack(material);
        ItemMeta meta = axe.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(markerKey, PersistentDataType.BYTE, (byte) 1);

            int maxUses = getMaxUses();
            if (maxUses > 0) {
                meta.getPersistentDataContainer().set(usesLeftKey, PersistentDataType.INTEGER, maxUses);
            }
            axe.setItemMeta(meta);
        }
        // Lore/isim, kullanım sayısı da dahil olacak şekilde tek bir yerden (refreshLore) çizilir.
        refreshLore(axe);
        return axe;
    }

    public boolean isSellAxe(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(markerKey, PersistentDataType.BYTE);
    }

    /** Config'teki sell-axe.max-uses değerini döner. 0 ya da altı ise sınırsız kullanım demektir. */
    public int getMaxUses() {
        return plugin.getConfig().getInt("sell-axe.max-uses", 2500);
    }

    /**
     * Baltanın şu anki kalan kullanım sayısını döner. Sınırsız kullanımlı bir
     * baltada (ya da sayaç hiç set edilmemişse) -1 döner.
     */
    public int getUsesLeft(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) return -1;
        ItemMeta meta = stack.getItemMeta();
        if (!meta.getPersistentDataContainer().has(usesLeftKey, PersistentDataType.INTEGER)) return -1;
        Integer value = meta.getPersistentDataContainer().get(usesLeftKey, PersistentDataType.INTEGER);
        return value == null ? -1 : value;
    }

    /**
     * Baltanın kullanım sayacını 1 azaltır ve lore'u günceller.
     * @return azaltma sonrası kalan kullanım sayısı; sınırsız kullanımlıysa -1 döner
     *         (bu durumda hiçbir şey azaltılmaz).
     */
    public int decrementUses(ItemStack stack) {
        int current = getUsesLeft(stack);
        if (current < 0) return -1; // sınırsız kullanım, sayaç yok

        int updated = Math.max(0, current - 1);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(usesLeftKey, PersistentDataType.INTEGER, updated);
            stack.setItemMeta(meta);
        }
        refreshLore(stack);
        return updated;
    }

    /**
     * Item'ın görünen ismini ve lore'unu, config'teki şablona göre yeniden çizer.
     * Kullanım sayacı varsa (sınırsız değilse), lore'un en altına
     * "Kalan kullanım: X" satırı eklenir.
     */
    public void refreshLore(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return;

        meta.setDisplayName(plugin.msg(plugin.getConfig().getString("sell-axe.name", "&6SATIŞ BALTASI")));

        List<String> lore = new ArrayList<>(plugin.getConfig().getStringList("sell-axe.lore").stream()
                .map(plugin::msg).toList());

        int usesLeft = getUsesLeft(stack);
        if (usesLeft >= 0) {
            lore.add("");
            lore.add(plugin.msg("&7Kalan kullanım: &f" + usesLeft));
        }

        meta.setLore(lore);
        stack.setItemMeta(meta);
    }

    public void give(Player player) {
        player.getInventory().addItem(create());
    }
}

package com.azy.sell.history;

/**
 * /tophistory ve /sellhistory GUI'lerinde kullanılabilecek sıralama modları.
 * Sıradaki moda geçmek için {@link #next()} kullanılır (GUI'deki sıralama
 * butonuna her tıklandığında bir sonraki moda geçilir).
 */
public enum SortMode {

    HIGHEST_PRICE("&aEn Pahalı"),
    LOWEST_PRICE("&aEn Ucuz"),
    NAME_A_Z("&aA-Z"),
    NAME_Z_A("&aZ-A");

    private final String displayName;

    SortMode(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public SortMode next() {
        SortMode[] values = values();
        return values[(this.ordinal() + 1) % values.length];
    }
}

package com.azy.sell;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.block.ShulkerBox;

import java.util.HashMap;
import java.util.Map;

/**
 * Satışın gerçekleştiği TEK merkezi yer. Hem Sell GUI (envanter kapanınca)
 * hem Sell Axe (sandık kırılınca) burayı çağırır.
 *
 * ÖNEMLİ DÜZELTME (shulker box bug'ı):
 * Önceki sürüm, bir ShulkerBox ItemStack'ini sadece Material.SHULKER_BOX olarak
 * görüp worth.yml'deki shulker fiyatını (örn. 150) veriyordu; kutunun İÇİNDEKİ
 * eşyaların (örn. toplam 1.000.000 değerinde eşya) worth'ü HİÇ HESABA KATILMIYORDU
 * ve o eşyalar kutuyla birlikte kalıcı olarak siliniyordu (para karşılığı verilmeden).
 *
 * Şimdi: bir slotta shulker box (veya renkli varyantları) tespit edilirse,
 * ÖNCE BlockStateMeta üzerinden içindeki envantere bakılır, içindeki her item
 * ayrı ayrı fiyatlandırılıp toplama eklenir, SONRA kutunun kendi worth'ü eklenir.
 * Böylece "1m değerinde eşya + 150 değerinde kutu" = 1.000.150 olarak satılır,
 * hiçbir değer kaybolmaz.
 */
public class SellService {

    private final AzySell plugin;

    public SellService(AzySell plugin) {
        this.plugin = plugin;
    }

    /**
     * Verilen envanterdeki tüm satılabilir eşyaları satar (shulker box içerikleri dahil).
     * Satılamayan (fiyatı olmayan) eşyalara dokunmaz, olduğu gibi bırakır.
     *
     * ÖNEMLİ: Vault/EssentialsX para yatırma işlemi BAŞARISIZ olursa (ekonomi eklentisi
     * işlemi reddederse), satılan eşyalar SLOT'LARINA GERİ KONUR ve satış hiç
     * gerçekleşmemiş gibi ele alınır. Önceki sürüm bunu kontrol etmiyordu; yani para
     * yatma başarısız olsa bile eşyalar zaten silinmiş oluyordu - oyuncu hem eşyasını
     * hem parasını kaybedebiliyordu. Artık böyle bir kayıp mümkün değil.
     */
    public SellResult sellInventory(Player player, Inventory inventory) {
        Map<Material, Integer> soldCounts = new HashMap<>();
        Map<Integer, ItemStack> removedSlots = new HashMap<>();
        double totalEarned = 0;

        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack stack = inventory.getItem(slot);
            if (stack == null || stack.getType().isAir()) continue;

            SellLine line = priceStack(player, stack, soldCounts);
            if (line.total() <= 0 && !line.hadShulkerContents()) {
                continue;
            }

            totalEarned += line.total();
            removedSlots.put(slot, stack.clone());
            inventory.setItem(slot, null);
        }

        if (totalEarned <= 0) {
            return new SellResult(0, 0);
        }

        boolean depositSuccess = plugin.getEconomyManager().deposit(player, totalEarned);
        if (!depositSuccess) {
            // Para yatırılamadı - satışı GERİ AL, eşyaları slotlarına koy.
            for (Map.Entry<Integer, ItemStack> entry : removedSlots.entrySet()) {
                inventory.setItem(entry.getKey(), entry.getValue());
            }
            player.sendMessage(plugin.msg("&cSatış işlemi tamamlanamadı (ekonomi sistemi para yatırmayı reddetti). "
                    + "Eşyaların iade edildi, tekrar dene."));
            return new SellResult(0, 0);
        }

        int totalItems = soldCounts.values().stream().mapToInt(Integer::intValue).sum();

        // ÖNEMLİ SIRALAMA: önce TÜM materyallerin fiyatı (şu anki, satıştan ÖNCEKİ
        // çarpanla) hesaplanır ve history'ye kaydedilir; kategori ilerlemesi
        // güncellemeleri SADECE bundan SONRA, ayrı bir döngüde yapılır. Aksi
        // halde aynı satışta iki farklı materyal aynı kategoriye aitse, ikinci
        // materyalin fiyatı ilk materyalin az önce tetiklediği kategori
        // güncellemesinden etkilenebilirdi - bu asla olmamalı.
        Map<Material, Double> baseValueAddedPerMaterial = new HashMap<>();
        for (Map.Entry<Material, Integer> entry : soldCounts.entrySet()) {
            double unitPrice = plugin.getPriceCalculator().getUnitSellPrice(player, entry.getKey());
            double lineTotal = unitPrice * entry.getValue();
            plugin.getHistoryManager().recordSale(player.getUniqueId(), entry.getKey(), entry.getValue(), lineTotal);

            double baseUnitValue = plugin.getPriceCalculator().getBaseValue(entry.getKey());
            baseValueAddedPerMaterial.put(entry.getKey(), baseUnitValue * entry.getValue());
        }

        // Şimdi kategori ilerlemelerini güncelle - bu satışın fiyatı zaten yukarıda
        // sabitlendi, buradan sonraki hiçbir güncelleme geriye dönük etki yapamaz.
        for (Map.Entry<Material, Double> entry : baseValueAddedPerMaterial.entrySet()) {
            plugin.getCategoryProgressManager().addProgress(player.getUniqueId(), entry.getKey(), entry.getValue());
        }

        announceSale(player, totalItems, totalEarned);

        return new SellResult(totalItems, totalEarned);
    }

    /**
     * Tek bir ItemStack'i fiyatlandırır. Eğer bu bir shulker box ise (ve içi doluysa),
     * önce içindeki HER eşyayı ayrı ayrı fiyatlandırıp soldCounts'a ekler, sonra
     * kutunun kendi worth'ünü (varsa) toplam üstüne ekler.
     */
    private SellLine priceStack(Player player, ItemStack stack, Map<Material, Integer> soldCounts) {
        double total = 0;
        boolean hadShulkerContents = false;

        if (isShulkerBox(stack.getType()) && stack.getItemMeta() instanceof BlockStateMeta blockStateMeta
                && blockStateMeta.getBlockState() instanceof ShulkerBox shulkerBox) {

            ItemStack[] contents = shulkerBox.getInventory().getContents();
            for (ItemStack inner : contents) {
                if (inner == null || inner.getType().isAir()) continue;

                // İçindeki eşya da başka bir shulker box olabilir (nested) - recursive fiyatlandırma.
                SellLine innerLine = priceStack(player, inner, soldCounts);
                total += innerLine.total();
                if (innerLine.total() > 0 || innerLine.hadShulkerContents()) {
                    hadShulkerContents = true;
                }
            }

            // İçini boşalt ki kutu satıldığında oyuncu için karışıklık olmasın (kozmetik/güvenlik).
            shulkerBox.getInventory().clear();
        }

        if (plugin.getPriceCalculator().hasPrice(stack)) {
            double unitPrice = plugin.getPriceCalculator().getUnitSellPrice(player, stack);
            if (unitPrice > 0) {
                int amount = stack.getAmount();
                total += unitPrice * amount;
                soldCounts.merge(stack.getType(), amount, Integer::sum);
            }
        }

        return new SellLine(total, hadShulkerContents);
    }

    private boolean isShulkerBox(Material material) {
        return material.name().endsWith("SHULKER_BOX");
    }

    /**
     * Kalıcı satış duyurusu: hem action bar (anlık) hem CHAT (kalıcı, scroll edilebilir).
     */
    private void announceSale(Player player, int totalItems, double totalEarned) {
        String template = plugin.getConfig().getString("messages.sold",
                "&a{amount} eşya sattın, kazanç: &f${total}&a!");
        String formatted = template
                .replace("{amount}", String.valueOf(totalItems))
                .replace("{total}", plugin.getEconomyManager().format(totalEarned));

        player.sendMessage(plugin.msg(formatted));
    }

    private record SellLine(double total, boolean hadShulkerContents) {
    }

    public record SellResult(int totalItems, double totalEarned) {
        public boolean isEmpty() {
            return totalItems <= 0;
        }
    }
}

package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/**
 * Kategori bazlı satış çarpanı sisteminin kalbi.
 *
 * ÖNEMLİ (satış sırası kuralı): Bir oyuncu eşya sattığında, o satışın fiyatı
 * ÖNCE hesaplanır (mevcut çarpanla), SONRA bu ilerleme kaydına eklenir.
 * Yani az önce ulaşılan yeni bir tier, O ANKİ satışı ETKİLEMEZ - bir sonraki
 * satıştan itibaren geçerli olur. Bu sıralama SellService tarafından
 * garanti edilir (fiyat hesabı bitip para yatırıldıktan SONRA
 * recordProgress çağrılır).
 *
 * Kategori ilerlemesi, materyalin TABAN worth'ü (kategori çarpanı uygulanmadan
 * önceki, ama global multiplier ve VIP çarpanı dahil değil - yani "kaç para
 * kazandın" değil "ne kadarlık eşya sattın") üzerinden sayılır. Böylece
 * çarpan kendi kendini beslemez.
 */
public class CategoryProgressManager {

    private final AzySell plugin;
    private final Map<String, CategoryDefinition> categories = new LinkedHashMap<>();
    /** Hızlı erişim için: bir materyalin hangi kategoriye ait olduğu (en fazla bir kategori). */
    private final Map<Material, String> materialToCategory = new java.util.HashMap<>();
    private Connection connection;

    public CategoryProgressManager(AzySell plugin) {
        this.plugin = plugin;
    }

    // ---------------------------------------------------------------
    // Config yükleme
    // ---------------------------------------------------------------

    public void loadCategories() {
        categories.clear();
        materialToCategory.clear();

        File file = new File(plugin.getDataFolder(), "sell-categories.yml");
        if (!file.exists()) {
            plugin.saveResource("sell-categories.yml", false);
        }

        FileConfiguration config;
        try (InputStream defaultStream = plugin.getResource("sell-categories.yml")) {
            config = YamlConfiguration.loadConfiguration(file);
            if (defaultStream != null) {
                YamlConfiguration defaults = YamlConfiguration.loadConfiguration(
                        new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
                config.setDefaults(defaults);
            }
        } catch (Exception ex) {
            plugin.getLogger().log(Level.WARNING, "sell-categories.yml okunamadı, kategori çarpanı devre dışı.", ex);
            return;
        }

        ConfigurationSection categoriesSection = config.getConfigurationSection("categories");
        if (categoriesSection == null) {
            plugin.getLogger().warning("sell-categories.yml içinde 'categories' bölümü bulunamadı.");
            return;
        }

        for (String categoryId : categoriesSection.getKeys(false)) {
            ConfigurationSection section = categoriesSection.getConfigurationSection(categoryId);
            if (section == null) continue;

            String displayName = plugin.msg(section.getString("display-name", categoryId));
            String description = plugin.msg(section.getString("description", ""));
            Material icon = parseMaterial(section.getString("icon", "STONE"), categoryId);

            java.util.Set<Material> materials = new java.util.LinkedHashSet<>();
            for (String materialName : section.getStringList("materials")) {
                Material material = parseMaterial(materialName, categoryId);
                if (material != null) {
                    materials.add(material);
                    // Bir materyal zaten başka bir kategoriye atanmışsa (config hatası),
                    // ilk tanımlandığı kategoriye ait kalır - çakışma sessizce yok sayılır
                    // ama loglanır, böylece hangi eşyayı sattığında hangi kategorinin
                    // ilerleyeceği HER ZAMAN net ve tutarlıdır.
                    String existing = materialToCategory.get(material);
                    if (existing != null && !existing.equals(categoryId)) {
                        plugin.getLogger().warning("'" + material + "' hem '" + existing + "' hem '" + categoryId
                                + "' kategorisinde tanımlı. İlk tanım ('" + existing + "') geçerli olacak.");
                    } else {
                        materialToCategory.put(material, categoryId);
                    }
                }
            }

            List<CategoryTier> tiers = new ArrayList<>();
            List<Map<?, ?>> tierMaps = section.getMapList("tiers");
            for (Map<?, ?> tierMap : tierMaps) {
                Object amountObj = tierMap.get("amount");
                Object multiplierObj = tierMap.get("multiplier");
                if (amountObj == null || multiplierObj == null) continue;
                double amount = ((Number) amountObj).doubleValue();
                double multiplier = ((Number) multiplierObj).doubleValue();
                tiers.add(new CategoryTier(amount, multiplier));
            }
            tiers.sort((a, b) -> Double.compare(a.requiredAmount(), b.requiredAmount()));

            categories.put(categoryId, new CategoryDefinition(categoryId, displayName, icon, description, materials, tiers));
        }

        plugin.getLogger().info(categories.size() + " satış kategorisi yüklendi.");
    }

    private Material parseMaterial(String name, String context) {
        if (name == null) return null;
        Material material = Material.matchMaterial(name);
        if (material == null) {
            plugin.getLogger().warning("Bilinmeyen materyal '" + name + "' (kategori: " + context + ")");
        }
        return material;
    }

    // ---------------------------------------------------------------
    // Veritabanı (oyuncu bazlı birikimli ilerleme)
    // ---------------------------------------------------------------

    public void setup() {
        try {
            File dbFile = new File(plugin.getDataFolder(), "categoryprogress.db");
            plugin.getDataFolder().mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());

            try (Statement st = connection.createStatement()) {
                st.execute("""
                        CREATE TABLE IF NOT EXISTS category_progress (
                            player_uuid TEXT NOT NULL,
                            category_id TEXT NOT NULL,
                            progress REAL NOT NULL DEFAULT 0,
                            PRIMARY KEY (player_uuid, category_id)
                        )
                        """);
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Kategori ilerleme veritabanı kurulamadı.", ex);
        }
    }

    public void close() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ignored) {
            }
        }
    }

    /**
     * Verilen materyalin ait olduğu kategoriyi döner (yoksa null).
     */
    public CategoryDefinition getCategoryForMaterial(Material material) {
        String id = materialToCategory.get(material);
        return id == null ? null : categories.get(id);
    }

    /**
     * Oyuncunun bir kategorideki BİRİKİMLİ ilerlemesini döner (SQLite'tan okunur).
     * Kayıt yoksa 0.0 döner.
     */
    public double getProgress(UUID playerUuid, String categoryId) {
        if (connection == null) return 0.0;
        String sql = "SELECT progress FROM category_progress WHERE player_uuid = ? AND category_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, playerUuid.toString());
            ps.setString(2, categoryId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("progress");
                }
            }
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Kategori ilerlemesi okunamadı.", ex);
        }
        return 0.0;
    }

    /**
     * Oyuncunun şu anki etkin çarpanını döner (kategorinin ilerlemesine göre).
     * Kategori bulunamazsa (materyal hiçbir kategoriye ait değilse) 1.0 döner.
     */
    public double getMultiplier(UUID playerUuid, Material material) {
        CategoryDefinition category = getCategoryForMaterial(material);
        if (category == null) return 1.0;
        double progress = getProgress(playerUuid, category.getId());
        return category.getMultiplierForProgress(progress);
    }

    /**
     * Bir satış tamamlandıktan SONRA çağrılır: verilen materyalin taban worth
     * toplamını (unitPrice * amount, kategori/VIP çarpanları OLMADAN) ilgili
     * kategorinin ilerlemesine ekler. Materyal hiçbir kategoriye ait değilse
     * hiçbir şey yapmaz.
     */
    public void addProgress(UUID playerUuid, Material material, double baseValueAdded) {
        CategoryDefinition category = getCategoryForMaterial(material);
        if (category == null || connection == null || baseValueAdded <= 0) return;

        String sql = """
                INSERT INTO category_progress (player_uuid, category_id, progress)
                VALUES (?, ?, ?)
                ON CONFLICT(player_uuid, category_id)
                DO UPDATE SET progress = progress + excluded.progress
                """;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, playerUuid.toString());
            ps.setString(2, category.getId());
            ps.setDouble(3, baseValueAdded);
            ps.executeUpdate();
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.WARNING, "Kategori ilerlemesi kaydedilemedi.", ex);
        }
    }

    public List<CategoryDefinition> getCategories() {
        return new ArrayList<>(categories.values());
    }

    public CategoryDefinition getCategory(String id) {
        return categories.get(id);
    }
}

package com.azy.sell.category;

import org.bukkit.Material;

import java.util.List;
import java.util.Set;

/**
 * config'ten (sell-categories.yml) yüklenen tek bir kategorinin tanımı.
 * Örn: "ores" kategorisi -> DIAMOND, IRON_INGOT vb. materyaller + tier listesi.
 */
public class CategoryDefinition {

    private final String id;
    private final String displayName;
    private final Material icon;
    private final String description;
    private final Set<Material> materials;
    private final List<CategoryTier> tiers;

    public CategoryDefinition(String id, String displayName, Material icon, String description,
                               Set<Material> materials, List<CategoryTier> tiers) {
        this.id = id;
        this.displayName = displayName;
        this.icon = icon;
        this.description = description;
        this.materials = materials;
        this.tiers = tiers;
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Material getIcon() {
        return icon;
    }

    public String getDescription() {
        return description;
    }

    public boolean containsMaterial(Material material) {
        return materials.contains(material);
    }

    public Set<Material> getMaterials() {
        return materials;
    }

    public List<CategoryTier> getTiers() {
        return tiers;
    }

    /**
     * Verilen birikimli ilerlemeye göre şu anki aktif çarpanı döner.
     * Hiçbir tier'e ulaşılmamışsa 1.0 (çarpansız) döner.
     */
    public double getMultiplierForProgress(double progress) {
        double best = 1.0;
        for (CategoryTier tier : tiers) {
            if (progress >= tier.requiredAmount()) {
                best = tier.multiplier();
            } else {
                break; // tiers küçükten büyüğe sıralı, ilk ulaşılamayan noktada dur
            }
        }
        return best;
    }

    /**
     * Şu anki ilerlemeye göre BİR SONRAKİ tier'i döner (henüz ulaşılmamış).
     * Tüm tier'lar tamamlanmışsa null döner (maksimum seviye).
     */
    public CategoryTier getNextTier(double progress) {
        for (CategoryTier tier : tiers) {
            if (progress < tier.requiredAmount()) {
                return tier;
            }
        }
        return null;
    }
}

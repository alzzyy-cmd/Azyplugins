package com.azy.sell;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.util.logging.Level;

public class EconomyManager {

    private final AzySell plugin;
    private Economy economy;

    public EconomyManager(AzySell plugin) {
        this.plugin = plugin;
    }

    public boolean setup() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        this.economy = rsp.getProvider();
        return economy != null;
    }

    public boolean isReady() {
        return economy != null;
    }

    /**
     * Oyuncunun hesabına para yatırır ve VAULT'UN GERÇEK DÖNÜŞ DEĞERİNİ kontrol eder.
     * ÖNCEKİ SÜRÜM bu dönüş değerini hiç kontrol etmiyordu; yani EssentialsX (veya başka
     * bir ekonomi eklentisi) işlemi reddetse bile (örn. hesap kilitli, bakiye limiti aşıldı,
     * banka/oyuncu senkron hatası) AzySell "para yatırıldı" varsayıp satışı başarılı
     * sayıyordu - oyuncunun eşyası siliniyor ama parası GERÇEKTEN yatmıyor olabiliyordu.
     *
     * @return true ise EssentialsX/Vault işlemi GERÇEKTEN başarılı olduğunu onayladı.
     *         false ise işlem reddedildi - bu durumda ÇAĞIRAN TARAF satışı geri almalı
     *         (satılan eşyaları iade etmeli), aksi halde oyuncu parasız eşyasız kalır.
     */
    public boolean deposit(Player player, double amount) {
        if (!isReady()) {
            plugin.getLogger().warning("Ekonomi hazır değil, " + player.getName() + " için " + amount + " yatırılamadı.");
            return false;
        }
        EconomyResponse response = economy.depositPlayer(player, amount);
        if (!response.transactionSuccess()) {
            plugin.getLogger().log(Level.WARNING, "Vault para yatırma BAŞARISIZ oldu! Oyuncu: "
                    + player.getName() + ", Miktar: " + amount + ", Sebep: " + response.errorMessage);
            return false;
        }
        return true;
    }

    public String format(double amount) {
        if (isReady()) {
            return economy.format(amount);
        }
        return String.format("%.2f", amount);
    }
}

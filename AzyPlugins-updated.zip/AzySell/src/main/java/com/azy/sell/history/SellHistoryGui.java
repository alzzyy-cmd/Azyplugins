package com.azy.sell.history;

import com.azy.sell.AzySell;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

/**
 * /satisgecmisi (alias: /sellhistory) komutuyla açılan ekran.
 * Oyuncunun eşya bazlı toplam sattığı miktar ve toplam kazancını gösterir.
 * TopHistoryGui ile aynı sayfalama düzenini kullanır (45'lik sayfa +
 * önceki/sonraki/toplam butonları), böylece çok sayıda eşya satmış oyuncularda
 * ilk 54 eşyanın ardından liste sessizce kesilmez.
 */
public class SellHistoryGui implements InventoryHolder {

    private static final int PAGE_SIZE = 44;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_SORT = 48;
    private static final int SLOT_SUMMARY = 49;
    private static final int SLOT_NEXT = 53;

    private final AzySell plugin;
    private final UUID targetPlayer;
    private final int page;
    private final SortMode sortMode;
    private Inventory inventory;

    public SellHistoryGui(AzySell plugin, UUID targetPlayer) {
        this(plugin, targetPlayer, 0, SortMode.HIGHEST_PRICE);
    }

    public SellHistoryGui(AzySell plugin, UUID targetPlayer, int page) {
        this(plugin, targetPlayer, page, SortMode.HIGHEST_PRICE);
    }

    public SellHistoryGui(AzySell plugin, UUID targetPlayer, int page, SortMode sortMode) {
        this.plugin = plugin;
        this.targetPlayer = targetPlayer;
        this.page = page;
        this.sortMode = sortMode;
    }

    public void open(Player viewer) {
        int totalDistinct = plugin.getHistoryManager().getPlayerDistinctItemCount(targetPlayer);
        int maxPages = Math.max(1, (int) Math.ceil(totalDistinct / (double) PAGE_SIZE));
        int clampedPage = Math.max(0, Math.min(page, maxPages - 1));

        List<SellHistoryManager.HistoryEntry> entries =
                plugin.getHistoryManager().getSummary(targetPlayer, PAGE_SIZE, clampedPage * PAGE_SIZE, sortMode);

        String title = plugin.msg("&8Satış Geçmişi &7(Sayfa " + (clampedPage + 1) + "/" + maxPages + ")");
        inventory = Bukkit.createInventory(this, 54, title);

        for (int i = 0; i < entries.size() && i < PAGE_SIZE; i++) {
            inventory.setItem(i, buildEntryItem(entries.get(i)));
        }

        if (clampedPage > 0) {
            inventory.setItem(SLOT_PREV, navButton("&aÖnceki Sayfa"));
        }
        if (clampedPage < maxPages - 1) {
            inventory.setItem(SLOT_NEXT, navButton("&aSonraki Sayfa"));
        }
        inventory.setItem(SLOT_SORT, sortButton());

        ItemStack summary = new ItemStack(Material.PAPER);
        ItemMeta meta = summary.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&e&lToplam"));
            meta.setLore(List.of(plugin.msg("&7Farklı eşya çeşidi: &f" + totalDistinct)));
            summary.setItemMeta(meta);
        }
        inventory.setItem(SLOT_SUMMARY, summary);

        viewer.openInventory(inventory);
    }

    private ItemStack buildEntryItem(SellHistoryManager.HistoryEntry entry) {
        ItemStack stack = new ItemStack(entry.material());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.translatable(entry.material().translationKey())
                    .color(NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false));
            meta.setLore(List.of(
                    plugin.msg("&7Toplam miktar: &f" + entry.totalAmount()),
                    plugin.msg("&7Toplam kazanç: &a$" + format(entry.totalPrice()))
            ));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack navButton(String name) {
        ItemStack stack = new ItemStack(Material.ARROW);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack sortButton() {
        ItemStack stack = new ItemStack(Material.HOPPER);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&eSıralama: " + sortMode.getDisplayName()));
            meta.setLore(List.of(plugin.msg("&7Değiştirmek için tıkla")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String format(double price) {
        if (price == Math.floor(price)) return String.valueOf((long) price);
        return String.format("%.2f", price);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public UUID getTargetPlayer() {
        return targetPlayer;
    }

    public int getPage() {
        return page;
    }

    public SortMode getSortMode() {
        return sortMode;
    }

    public static int getSlotPrev() { return SLOT_PREV; }
    public static int getSlotNext() { return SLOT_NEXT; }
    public static int getSlotSort() { return SLOT_SORT; }
}

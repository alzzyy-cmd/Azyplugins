package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

/**
 * Bir kategoriye (örn. Cevherler) tıklandığında açılan ilerleme ekranı.
 *
 * "Yılan yolu" (snake path) düzeni: kategorinin 20 tier'ı, referans
 * görsellerdeki gibi DAR, DİKEY bir S şeklinde kıvrılan bir yol üzerinde
 * dizilir - tüm ızgarayı dolduran geniş bir zigzag DEĞİL. 5 kolon kullanılır
 * (her kolonda 4 tier): 1. kolon YUKARIDAN AŞAĞI iner, 2. kolon AŞAĞIDAN
 * YUKARI çıkar, 3. kolon tekrar YUKARIDAN AŞAĞI iner, ... - böylece yol
 * organik bir "S" çizer. Her tier bir cam panel:
 *  - YEŞİL: bu tier'a zaten ulaşılmış (TAMAMLANDI).
 *  - SARI: şu anki aktif hedef (WORKING) - lore'da "ÇARPANx YÜZDE%" ve
 *    "$mevcut/$hedef" bilgisi gösterilir.
 *  - GRİ: henüz sırası gelmemiş (BEKLEMEDE).
 * Kategori ikonu sol üstte (ICON_SLOT) durur, kalan slotlar sınır/dekor
 * panelidir. Sol alt köşedeki KIRMIZI panel (BACK_BUTTON_SLOT) tıklanınca
 * oyuncuyu MultiplierSummaryGui (kategori özet) ekranına geri döndürür.
 */
public class CategoryProgressGui implements InventoryHolder {

    private static final int SIZE = 54;
    private static final int ICON_SLOT = 0;
    private static final int ROWS = 6;
    private static final int COLS = 9;
    public static final int BACK_BUTTON_SLOT = (ROWS - 1) * COLS; // sol alt köşe (45)

    /** Yılan yolunun kullandığı dikey satır aralığı: üst satır (ikon) ve alt satır (geri buton) hariç, kalan 4 satır. */
    private static final int PATH_ROW_START = 1;
    private static final int PATH_ROW_COUNT = 4; // satır 1,2,3,4 (satır 0 = ikon, satır 5 = geri buton)
    /** Yolun kullandığı kolon sayısı: 20 tier / 4 satır = 5 kolon gerekir. */
    private static final int PATH_COL_START = 2; // ortaya yakın, dar bir görünüm için 2. sütundan başlar
    private static final int PATH_COL_COUNT = 5;

    private final AzySell plugin;
    private final CategoryDefinition category;
    private Inventory inventory;

    public CategoryProgressGui(AzySell plugin, CategoryDefinition category) {
        this.plugin = plugin;
        this.category = category;
    }

    public void open(Player player) {
        String title = plugin.msg(category.getDisplayName() + " &7İlerlemesi");
        inventory = Bukkit.createInventory(this, SIZE, title);

        UUID uuid = player.getUniqueId();
        double progress = plugin.getCategoryProgressManager().getProgress(uuid, category.getId());
        double currentMultiplier = category.getMultiplierForProgress(progress);
        CategoryTier nextTier = category.getNextTier(progress);

        // Sınır/dekor: tüm slotları önce koyu cam panel ile doldur.
        for (int slot = 0; slot < SIZE; slot++) {
            inventory.setItem(slot, buildFillerPane());
        }

        inventory.setItem(ICON_SLOT, buildInfoIcon(progress, currentMultiplier, nextTier));

        // Tier'ları snake-path (zigzag) düzeninde yerleştir.
        List<CategoryTier> tiers = category.getTiers();
        int[] slots = buildSnakeSlots(tiers.size());
        for (int i = 0; i < tiers.size(); i++) {
            inventory.setItem(slots[i], buildTierItem(tiers.get(i), progress, nextTier));
        }

        // Geri dönüş butonu: sol alt köşe, kırmızı panel.
        inventory.setItem(BACK_BUTTON_SLOT, buildBackButton());

        player.openInventory(inventory);
    }

    /**
     * 20 tier'ı, referans görsellerdeki gibi DAR ve DİKEY kıvrılan bir "S" yolu
     * üzerine dizecek slot indekslerini üretir. PATH_COL_COUNT (5) kolon,
     * PATH_ROW_COUNT (4) satır kullanılır (5*4=20). Tek kolon önce YUKARIDAN
     * AŞAĞI, bir sonraki kolon AŞAĞIDAN YUKARI dolar - böylece yol her kolon
     * geçişinde yön değiştirip organik bir S/yılan görünümü kazanır.
     */
    private int[] buildSnakeSlots(int tierCount) {
        int[] result = new int[tierCount];
        int filled = 0;
        boolean topToBottom = true;

        for (int colOffset = 0; colOffset < PATH_COL_COUNT && filled < tierCount; colOffset++) {
            int col = PATH_COL_START + colOffset;
            for (int r = 0; r < PATH_ROW_COUNT && filled < tierCount; r++) {
                int row = topToBottom ? (PATH_ROW_START + r) : (PATH_ROW_START + PATH_ROW_COUNT - 1 - r);
                int slot = row * COLS + col;
                result[filled++] = slot;
            }
            topToBottom = !topToBottom;
        }
        return result;
    }

    private ItemStack buildFillerPane() {
        ItemStack stack = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildBackButton() {
        ItemStack stack = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&cGeri Dön"));
            meta.setLore(List.of(plugin.msg("&7Satış menüsüne geri dön")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildInfoIcon(double progress, double currentMultiplier, CategoryTier nextTier) {
        ItemStack stack = new ItemStack(category.getIcon());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(category.getDisplayName()));
            java.util.List<String> lore = new java.util.ArrayList<>();
            lore.add(plugin.msg(category.getDescription()));
            lore.add("");
            lore.add(plugin.msg("&eŞu anki çarpan: &a" + formatMultiplier(currentMultiplier) + "x"));
            if (nextTier != null) {
                double percent = Math.min(100.0, (progress / nextTier.requiredAmount()) * 100.0);
                lore.add(plugin.msg("&7Sonraki hedef: &a" + formatMultiplier(nextTier.multiplier()) + "x"));
                lore.add(plugin.msg("&7İlerleme: &f$" + formatAmount(progress) + " &7/ &f$" + formatAmount(nextTier.requiredAmount())
                        + " &7(&a%" + String.format("%.1f", percent) + "&7)"));
            } else {
                lore.add(plugin.msg("&6En yüksek seviyeye ulaştın!"));
            }
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildTierItem(CategoryTier tier, double progress, CategoryTier nextTier) {
        boolean reached = progress >= tier.requiredAmount();
        boolean isCurrent = tier.equals(nextTier);

        Material glassColor = reached ? Material.LIME_STAINED_GLASS_PANE
                : isCurrent ? Material.YELLOW_STAINED_GLASS_PANE
                : Material.GRAY_STAINED_GLASS_PANE;

        ItemStack stack = new ItemStack(glassColor);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            String status = reached ? "&aTAMAMLANDI" : isCurrent ? "&eÇALIŞIYOR" : "&7BEKLEMEDE";
            meta.setDisplayName(plugin.msg(status + " &7- &f" + formatMultiplier(tier.multiplier()) + "x"));

            java.util.List<String> lore = new java.util.ArrayList<>();
            if (isCurrent) {
                double percent = Math.min(100.0, (progress / tier.requiredAmount()) * 100.0);
                lore.add(plugin.msg("&eÇALIŞIYOR"));
                lore.add(plugin.msg(buildProgressBar(percent) + " &f" + formatMultiplier(tier.multiplier())
                        + "x &7" + String.format("%.1f", percent) + "%"));
                lore.add(plugin.msg("&f$$" + formatAmount(progress) + "&7/&f$" + formatAmount(tier.requiredAmount())));
            } else if (reached) {
                lore.add(plugin.msg("&7Gereken: &f$" + formatAmount(tier.requiredAmount())));
            } else {
                lore.add(plugin.msg("&7Gereken: &f$" + formatAmount(tier.requiredAmount())));
            }
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /**
     * Image 1'deki gibi düz bir ilerleme çubuğu üretir: dolu kısım için '-',
     * boş kısım için beyaz '-' kullanır (toplam 10 karakter).
     */
    private String buildProgressBar(double percent) {
        int totalBars = 10;
        int filled = (int) Math.round((percent / 100.0) * totalBars);
        filled = Math.max(0, Math.min(totalBars, filled));
        StringBuilder bar = new StringBuilder();
        bar.append("&6");
        for (int i = 0; i < filled; i++) bar.append('-');
        bar.append("&f");
        for (int i = filled; i < totalBars; i++) bar.append('-');
        return bar.toString();
    }

    private String formatMultiplier(double value) {
        if (value == Math.floor(value)) {
            return String.format("%.1f", value);
        }
        return String.valueOf(value);
    }

    private String formatAmount(double amount) {
        if (amount >= 1_000_000_000) {
            return String.format("%.2fB", amount / 1_000_000_000.0);
        }
        if (amount >= 1_000_000) {
            return String.format("%.2fM", amount / 1_000_000.0);
        }
        if (amount >= 1_000) {
            return String.format("%.2fK", amount / 1_000.0);
        }
        return String.format("%.0f", amount);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public CategoryDefinition getCategory() {
        return category;
    }
}

package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

/**
 * Bir kategoriye (örn. Cevherler) tıklandığında açılan ilerleme ekranı.
 *
 * Üst satırda kategorinin ikonu + genel bilgi (isim, açıklama, şu anki çarpan,
 * bir sonraki tier'a olan ilerleme yüzdesi) yer alır.
 * Alt kısımda kategoriye ait HER TIER bir slot olarak gösterilir:
 *  - YEŞİL cam panel: bu tier'a zaten ulaşılmış.
 *  - SARI cam panel: şu anki aktif hedef (bir sonraki ulaşılacak tier).
 *  - GRİ cam panel: henüz sırası gelmemiş, uzak tier.
 * Tier slotlarından birine tıklanınca, o kategoriye dahil olan materyallerin
 * listesi (WORKING durumu, gereken miktar, mevcut ilerleme) tıklanan itemin
 * lore'unda gösterilir - ayrıca kategori ikonuna (üst satır) tekrar tıklanırsa
 * kategoriye dahil TÜM materyaller tek seferde listelenir.
 */
public class CategoryProgressGui implements InventoryHolder {

    private static final int SIZE = 54;
    private static final int ICON_SLOT = 4;

    private final AzySell plugin;
    private final CategoryDefinition category;
    private Inventory inventory;

    public CategoryProgressGui(AzySell plugin, CategoryDefinition category) {
        this.plugin = plugin;
        this.category = category;
    }

    public void open(Player player) {
        String title = plugin.msg(category.getDisplayName() + " &7İlerlemesi");
        inventory = Bukkit.createInventory(this, SIZE, title);

        UUID uuid = player.getUniqueId();
        double progress = plugin.getCategoryProgressManager().getProgress(uuid, category.getId());
        double currentMultiplier = category.getMultiplierForProgress(progress);
        CategoryTier nextTier = category.getNextTier(progress);

        inventory.setItem(ICON_SLOT, buildInfoIcon(progress, currentMultiplier, nextTier));

        List<CategoryTier> tiers = category.getTiers();
        int startSlot = 9;
        for (int i = 0; i < tiers.size() && startSlot + i < SIZE; i++) {
            inventory.setItem(startSlot + i, buildTierItem(tiers.get(i), progress, nextTier));
        }

        // Kategoriye dahil materyallerin tam listesi, son satırlarda gösterilir.
        int materialStart = 27;
        int i = 0;
        for (Material material : category.getMaterials()) {
            if (materialStart + i >= SIZE) break;
            inventory.setItem(materialStart + i, buildMaterialItem(material));
            i++;
        }

        player.openInventory(inventory);
    }

    private ItemStack buildInfoIcon(double progress, double currentMultiplier, CategoryTier nextTier) {
        ItemStack stack = new ItemStack(category.getIcon());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(category.getDisplayName()));
            java.util.List<String> lore = new java.util.ArrayList<>();
            lore.add(plugin.msg(category.getDescription()));
            lore.add("");
            lore.add(plugin.msg("&eŞu anki çarpan: &a" + formatMultiplier(currentMultiplier) + "x"));
            if (nextTier != null) {
                double percent = Math.min(100.0, (progress / nextTier.requiredAmount()) * 100.0);
                lore.add(plugin.msg("&7Sonraki hedef: &a" + formatMultiplier(nextTier.multiplier()) + "x"));
                lore.add(plugin.msg("&7İlerleme: &f$" + formatAmount(progress) + " &7/ &f$" + formatAmount(nextTier.requiredAmount())
                        + " &7(&a%" + String.format("%.1f", percent) + "&7)"));
            } else {
                lore.add(plugin.msg("&6En yüksek seviyeye ulaştın!"));
            }
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildTierItem(CategoryTier tier, double progress, CategoryTier nextTier) {
        boolean reached = progress >= tier.requiredAmount();
        boolean isCurrent = tier.equals(nextTier);

        Material glassColor = reached ? Material.LIME_STAINED_GLASS_PANE
                : isCurrent ? Material.YELLOW_STAINED_GLASS_PANE
                : Material.GRAY_STAINED_GLASS_PANE;

        ItemStack stack = new ItemStack(glassColor);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            String status = reached ? "&aTAMAMLANDI" : isCurrent ? "&eÇALIŞIYOR" : "&7BEKLEMEDE";
            meta.setDisplayName(plugin.msg(status + " &7- &f" + formatMultiplier(tier.multiplier()) + "x"));

            java.util.List<String> lore = new java.util.ArrayList<>();
            if (isCurrent) {
                double percent = Math.min(100.0, (progress / tier.requiredAmount()) * 100.0);
                lore.add(plugin.msg("&f$" + formatAmount(progress) + " &7/ &f$" + formatAmount(tier.requiredAmount())));
                lore.add(plugin.msg("&7İlerleme: &a%" + String.format("%.1f", percent)));
            } else {
                lore.add(plugin.msg("&7Gereken: &f$" + formatAmount(tier.requiredAmount())));
            }
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildMaterialItem(Material material) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setLore(List.of(plugin.msg("&7Bu kategoriye dahil")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String formatMultiplier(double value) {
        if (value == Math.floor(value)) {
            return String.format("%.1f", value);
        }
        return String.valueOf(value);
    }

    private String formatAmount(double amount) {
        if (amount >= 1_000_000) {
            return String.format("%.2fM", amount / 1_000_000.0);
        }
        if (amount >= 1_000) {
            return String.format("%.2fK", amount / 1_000.0);
        }
        return String.format("%.0f", amount);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public CategoryDefinition getCategory() {
        return category;
    }
}

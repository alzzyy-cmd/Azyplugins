package com.azy.sell.multiplier;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * VIP'lere özel EK satış çarpanı sistemi.
 *
 * Nasıl çalışır:
 *  - config.yml'de "vip-multipliers" altında bir izin listesi tanımlanır, örn:
 *      vip-multipliers:
 *        - "sellcarpan.1.0"
 *        - "sellcarpan.0.5"
 *        - "sellcarpan.0.25"
 *        - "sellcarpan.0.1"
 *  - İzin node'unun SON PARÇASI (nokta ile ayrılmış) doğrudan ekstra çarpan oranıdır.
 *    "sellcarpan.0.5" iznine sahip oyuncu %50 FAZLA para kazanır (çarpan +0.5).
 *  - Oyuncunun sahip olduğu TÜM izinlerden EN YÜKSEK olanı kullanılır (üst üste binmez).
 *  - Bu çarpan, AzyWorth'teki global multiplier'ın ÜSTÜNE eklenir, onu SİLMEZ/DEĞİŞTİRMEZ:
 *      nihai fiyat = taban_fiyat * global_multiplier * (1 + vip_ekstra_carpan)
 *
 * Yeni bir VIP grubu eklemek istediğinde:
 *  1) LuckPerms (veya kullandığın izin plugin'i) üzerinden gruba "sellcarpan.<oran>" iznini ver.
 *     Örnek: yeni bir "efsane" grubu için %75 fazla istiyorsan "sellcarpan.0.75" izni ver.
 *  2) config.yml'deki vip-multipliers listesine "sellcarpan.0.75" satırını ekle.
 *  3) /azysellreload çalıştır. Kod değişikliği YAPMANA gerek yok, tamamen config'den yönetilir.
 */
public class SellMultiplierManager {

    private final AzySell plugin;
    private List<Double> knownRatios = new ArrayList<>();

    public SellMultiplierManager(AzySell plugin) {
        this.plugin = plugin;
    }

    public void load() {
        knownRatios.clear();
        List<String> nodes = plugin.getConfig().getStringList("vip-multipliers");
        for (String node : nodes) {
            Double ratio = parseRatioFromNode(node);
            if (ratio != null) {
                knownRatios.add(ratio);
            } else {
                plugin.getLogger().warning("Geçersiz vip-multiplier izin formatı (sayı bulunamadı): " + node);
            }
        }
        knownRatios.sort((a, b) -> Double.compare(b, a)); // büyükten küçüğe
    }

    /**
     * İzin node'unun son bölümünü (nokta ile ayrılmış) sayıya çevirir.
     * "sellcarpan.0.5" -> 0.5   |   "sellcarpan.1.0" -> 1.0
     */
    private Double parseRatioFromNode(String node) {
        // Node "sellcarpan.0.5" gibi görünüyor; "sellcarpan." önekini atıp kalanı parse ederiz.
        String prefix = "sellcarpan.";
        if (!node.toLowerCase().startsWith(prefix)) return null;
        String numberPart = node.substring(prefix.length());
        try {
            return Double.parseDouble(numberPart);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    /**
     * Oyuncunun sahip olduğu EN YÜKSEK vip ekstra çarpanını döner.
     * Hiçbir izni yoksa 0.0 döner (yani ekstra çarpan yok, sadece taban fiyat geçerli).
     */
    public double getExtraMultiplier(Player player) {
        double best = 0.0;
        for (double ratio : knownRatios) {
            String node = "sellcarpan." + formatRatioForNode(ratio);
            if (player.hasPermission(node)) {
                best = Math.max(best, ratio);
            }
        }
        return best;
    }

    private String formatRatioForNode(double ratio) {
        // 0.5 -> "0.5", 1.0 -> "1.0" şeklinde, config'deki yazımla birebir eşleşmesi için
        if (ratio == Math.floor(ratio)) {
            return String.format("%.1f", ratio);
        }
        String raw = String.valueOf(ratio);
        return raw;
    }

    public List<Double> getKnownRatios() {
        return knownRatios;
    }
}

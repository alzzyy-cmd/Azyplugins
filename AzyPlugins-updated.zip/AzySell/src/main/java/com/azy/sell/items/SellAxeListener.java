package com.azy.sell.items;

import com.azy.sell.AzySell;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

/**
 * Oyuncu elinde Sell Axe varken bir konteyner blok (sandık, tuzaklı sandık, varil,
 * yerde duran shulker box vb.) kırdığında, içindeki tüm satılabilir eşyalar anında satılır.
 *
 * DÜZELTME: Önceki sürüm sadece org.bukkit.block.Chest tipini kontrol ediyordu, bu yüzden
 * VARİL (Barrel) kırıldığında hiçbir şey satılmıyordu. Şimdi Bukkit'in ortak
 * org.bukkit.block.Container arayüzü kullanılıyor - Chest, TrappedChest, Barrel,
 * ShulkerBox (blok formunda), Dispenser, Dropper, Hopper dahil TÜM konteyner blokları kapsar.
 */
public class SellAxeListener implements Listener {

    private final AzySell plugin;
    private final SellAxeItem sellAxeItem;

    public SellAxeListener(AzySell plugin, SellAxeItem sellAxeItem) {
        this.plugin = plugin;
        this.sellAxeItem = sellAxeItem;
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack handItem = player.getInventory().getItemInMainHand();
        if (!sellAxeItem.isSellAxe(handItem)) return;

        Block block = event.getBlock();
        BlockState state = block.getState();
        if (!(state instanceof Container container)) return;

        Inventory containerInventory = container.getInventory();
        plugin.getSellService().sellInventory(player, containerInventory);
        // Satılamayan (fiyatsız) eşyalar sellInventory tarafından dokunulmadan bırakılır;
        // blok normal şekilde kırılınca Bukkit'in varsayılan davranışıyla zemine düşer.
    }
}

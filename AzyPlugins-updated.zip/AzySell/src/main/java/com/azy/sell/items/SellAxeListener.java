package com.azy.sell.items;

import com.azy.sell.AzySell;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

/**
 * Oyuncu elinde Sell Axe varken bir konteyner blok (sandık, tuzaklı sandık, varil,
 * yerde duran shulker box vb.) kırdığında, içindeki tüm satılabilir eşyalar anında satılır.
 *
 * KULLANIM LİMİTİ: her başarılı satıştan sonra (yani her sandık kırma işleminden
 * sonra) baltanın kalan kullanım sayısı 1 azaltılır (SellAxeItem.decrementUses).
 * Sayaç 0'a inince balta oyuncunun elinden tamamen kaldırılır (kırılır/yok olur) -
 * baltanın kırılma anını normal Minecraft "durability kırılması" gibi hissettirmek
 * için oyuncuya ayrıca bir mesaj gönderilir. max-uses config'te sınırsız (0 veya
 * altı) ise decrementUses hiçbir şey yapmaz (-1 döner), bu durumda balta hiç kırılmaz.
 *
 * DÜZELTME: Önceki sürüm sadece org.bukkit.block.Chest tipini kontrol ediyordu, bu yüzden
 * VARİL (Barrel) kırıldığında hiçbir şey satılmıyordu. Şimdi Bukkit'in ortak
 * org.bukkit.block.Container arayüzü kullanılıyor - Chest, TrappedChest, Barrel,
 * ShulkerBox (blok formunda), Dispenser, Dropper, Hopper dahil TÜM konteyner blokları kapsar.
 */
public class SellAxeListener implements Listener {

    private final AzySell plugin;
    private final SellAxeItem sellAxeItem;

    public SellAxeListener(AzySell plugin, SellAxeItem sellAxeItem) {
        this.plugin = plugin;
        this.sellAxeItem = sellAxeItem;
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack handItem = player.getInventory().getItemInMainHand();
        if (!sellAxeItem.isSellAxe(handItem)) return;

        Block block = event.getBlock();
        BlockState state = block.getState();
        if (!(state instanceof Container container)) return;

        Inventory containerInventory = container.getInventory();
        plugin.getSellService().sellInventory(player, containerInventory);
        // Satılamayan (fiyatsız) eşyalar sellInventory tarafından dokunulmadan bırakılır;
        // blok normal şekilde kırılınca Bukkit'in varsayılan davranışıyla zemine düşer.

        int usesLeft = sellAxeItem.decrementUses(handItem);
        if (usesLeft == 0) {
            // Sayaç tam sıfıra indi: balta anında elden kaldırılır (kırılır).
            player.getInventory().setItem(player.getInventory().getHeldItemSlot(), null);
            player.sendMessage(plugin.msg("&cSatış baltan kullanım ömrünü tamamladı ve kırıldı!"));
        }
    }
}

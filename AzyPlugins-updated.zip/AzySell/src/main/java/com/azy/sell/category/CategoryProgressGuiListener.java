package com.azy.sell.category;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * CategoryProgressGui salt-okunur bir bilgi ekranıdır: hiçbir eşya
 * alınamaz/bırakılamaz/sürüklenemez.
 */
public class CategoryProgressGuiListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof CategoryProgressGui) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof CategoryProgressGui) {
            event.setCancelled(true);
        }
    }
}

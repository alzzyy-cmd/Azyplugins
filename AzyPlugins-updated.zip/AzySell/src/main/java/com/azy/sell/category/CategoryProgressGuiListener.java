package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryHolder;

/**
 * CategoryProgressGui salt-okunur bir bilgi ekranıdır: hiçbir eşya
 * alınamaz/bırakılamaz/sürüklenemez. Tek istisna: sol alt köşedeki kırmızı
 * "Geri Dön" butonu, oyuncuyu MultiplierSummaryGui (kategori özet) ekranına
 * geri döndürür.
 */
public class CategoryProgressGuiListener implements Listener {

    private final AzySell plugin;

    public CategoryProgressGuiListener(AzySell plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof CategoryProgressGui) {
            event.setCancelled(true);

            if (event.getRawSlot() == CategoryProgressGui.BACK_BUTTON_SLOT
                    && event.getWhoClicked() instanceof Player player) {
                player.closeInventory();
                new MultiplierSummaryGui(plugin).open(player);
            }
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof CategoryProgressGui) {
            event.setCancelled(true);
        }
    }
}

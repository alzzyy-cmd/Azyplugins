package com.azy.sell.category;

import com.azy.sell.AzySell;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * /sellmultiplier (ve /satcarpan gibi Türkçe alias) komutuyla açılan özet ekran.
 *
 * 3 satır (27 slot):
 *  - Satır 1 (0-8): sınır - koyu cam panel.
 *  - Satır 2 (9-17): 9 kategori butonu, her biri o kategorinin ikonu + şu anki
 *    çarpanını gösterir. Tıklanınca CategoryProgressGui (54 slot, snake-path)
 *    açılır.
 *  - Satır 3 (18-26): sınır - koyu cam panel, ilk slotu (18) KIRMIZI panel:
 *    tıklanınca ana Sell GUI'sine geri döner.
 */
public class MultiplierSummaryGui implements InventoryHolder {

    private static final int SIZE = 27;
    private static final int CATEGORY_ROW_START = 9;
    public static final int BACK_BUTTON_SLOT = 18;

    private final AzySell plugin;
    private Inventory inventory;

    public MultiplierSummaryGui(AzySell plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        String title = plugin.msg("&8Satış Çarpanların");
        inventory = Bukkit.createInventory(this, SIZE, title);

        // Sınır: tüm slotları koyu cam panel ile doldur.
        ItemStack filler = buildFillerPane();
        for (int slot = 0; slot < SIZE; slot++) {
            inventory.setItem(slot, filler.clone());
        }

        List<CategoryDefinition> categories = plugin.getCategoryProgressManager().getCategories();
        UUID uuid = player.getUniqueId();
        for (int i = 0; i < categories.size() && i < 9; i++) {
            inventory.setItem(CATEGORY_ROW_START + i, buildCategoryButton(uuid, categories.get(i)));
        }

        inventory.setItem(BACK_BUTTON_SLOT, buildBackButton());

        player.openInventory(inventory);
    }

    private ItemStack buildCategoryButton(UUID uuid, CategoryDefinition category) {
        double progress = plugin.getCategoryProgressManager().getProgress(uuid, category.getId());
        double currentMultiplier = category.getMultiplierForProgress(progress);
        CategoryTier nextTier = category.getNextTier(progress);

        ItemStack stack = new ItemStack(category.getIcon());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(category.getDisplayName() + " &7(&a" + formatMultiplier(currentMultiplier) + "x&7)"));

            List<String> lore = new ArrayList<>();
            if (nextTier != null) {
                double percent = Math.min(100.0, (progress / nextTier.requiredAmount()) * 100.0);
                lore.add(plugin.msg("&7Sonraki hedef: &a" + formatMultiplier(nextTier.multiplier()) + "x"));
                lore.add(plugin.msg("&7İlerleme: &f%" + String.format("%.1f", percent)));
            } else {
                lore.add(plugin.msg("&6En yüksek seviyeye ulaştın!"));
            }
            lore.add("");
            lore.add(plugin.msg("&eTıkla ve detayları gör"));
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildFillerPane() {
        ItemStack stack = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildBackButton() {
        ItemStack stack = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&cGeri Dön"));
            meta.setLore(List.of(plugin.msg("&7Satış menüsüne geri dön")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String formatMultiplier(double value) {
        if (value == Math.floor(value)) {
            return String.format("%.1f", value);
        }
        return String.valueOf(value);
    }

    /**
     * Bu ekrandaki bir kategori slotuna tıklamayı, kategori listesindeki
     * ilgili CategoryDefinition'a eşler.
     */
    public static CategoryDefinition getCategoryForSlot(AzySell plugin, int slot) {
        int relative = slot - CATEGORY_ROW_START;
        List<CategoryDefinition> categories = plugin.getCategoryProgressManager().getCategories();
        if (relative < 0 || relative >= categories.size()) return null;
        return categories.get(relative);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}

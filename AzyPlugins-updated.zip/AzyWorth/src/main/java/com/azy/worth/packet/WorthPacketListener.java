package com.azy.worth.packet;

import com.azy.worth.AzyWorth;
import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.github.retrooper.packetevents.event.PacketSendEvent;
import com.github.retrooper.packetevents.protocol.item.ItemStack;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSetSlot;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowItems;
import org.bukkit.block.ShulkerBox;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * PACKET SEVİYESİNDE FİYAT GÖSTERİMİ (NBT'ye hiç dokunmadan).
 *
 * Neden bu yaklaşım gerekiyordu: item'ın GERÇEK lore'una "Fiyat: $X" yazmak
 * (adete göre değişen toplam fiyatla) Minecraft'ın stack birleştirme
 * mekanizmasını bozuyordu (farklı adette aynı item'lar farklı meta'ya sahip
 * olduğu için asla aynı slotta birleşmiyordu).
 *
 * Bu sınıf, oyuncuya GİDEN paketleri (WrapperPlayServerWindowItems - envanterin
 * tamamı; WrapperPlayServerSetSlot - tek bir slot güncellemesi) yakalar, paket
 * içindeki item'ları KLONLAYIP klonun lore'una "Fiyat: $X" satırını ekler, asıl
 * gönderilen paketi bu klonlarla değiştirir. SUNUCUDAKİ gerçek item verisi
 * (envanterdeki asıl ItemStack, disk'e kaydedilen veri) HİÇ DEĞİŞMEZ - sadece
 * o oyuncunun ekranına giden görüntü değişir. Böylece:
 *  - Item'lar sunucu tarafında her zaman normal şekilde stackler.
 *  - Ekranda görünen fiyat, adete göre (toplam) güncel kalır.
 *  - Shulker box'ların lore'unda da içerik dahil toplam değer gösterilir.
 *
 * NOT: SpigotConversionUtil sınıfı PacketEvents'in kendi Bukkit köprüsüdür
 * (com.github.retrooper.packetevents.util.SpigotConversionUtil) - packetevents-spigot
 * modülünde bulunur ve toBukkitItemStack/fromBukkitItemStack metodlarını sağlar.
 */
public class WorthPacketListener extends PacketListenerAbstract {

    private static final String FIYAT_PREFIX = "Fiyat: ";

    private static final Set<String> SHULKER_BOX_TYPES = Set.of(
            "SHULKER_BOX", "WHITE_SHULKER_BOX", "ORANGE_SHULKER_BOX", "MAGENTA_SHULKER_BOX",
            "LIGHT_BLUE_SHULKER_BOX", "YELLOW_SHULKER_BOX", "LIME_SHULKER_BOX", "PINK_SHULKER_BOX",
            "GRAY_SHULKER_BOX", "LIGHT_GRAY_SHULKER_BOX", "CYAN_SHULKER_BOX", "PURPLE_SHULKER_BOX",
            "BLUE_SHULKER_BOX", "BROWN_SHULKER_BOX", "GREEN_SHULKER_BOX", "RED_SHULKER_BOX",
            "BLACK_SHULKER_BOX"
    );

    private final AzyWorth plugin;

    public WorthPacketListener(AzyWorth plugin) {
        super(PacketListenerPriority.NORMAL);
        this.plugin = plugin;
    }

    @Override
    public void onPacketSend(PacketSendEvent event) {
        if (event.getPacketType() == PacketType.Play.Server.WINDOW_ITEMS) {
            handleWindowItems(event);
        } else if (event.getPacketType() == PacketType.Play.Server.SET_SLOT) {
            handleSetSlot(event);
        }
    }

    private void handleWindowItems(PacketSendEvent event) {
        WrapperPlayServerWindowItems wrapper = new WrapperPlayServerWindowItems(event);
        List<ItemStack> items = wrapper.getItems();
        List<ItemStack> modified = new ArrayList<>(items.size());
        for (ItemStack item : items) {
            modified.add(applyPriceLoreToPacketItem(item));
        }
        wrapper.setItems(modified);

        ItemStack carried = wrapper.getCarriedItem();
        if (carried != null) {
            wrapper.setCarriedItem(applyPriceLoreToPacketItem(carried));
        }
    }

    private void handleSetSlot(PacketSendEvent event) {
        WrapperPlayServerSetSlot wrapper = new WrapperPlayServerSetSlot(event);
        ItemStack item = wrapper.getItem();
        if (item != null) {
            wrapper.setItem(applyPriceLoreToPacketItem(item));
        }
    }

    /**
     * PacketEvents'in kendi ItemStack tipini (protokol seviyesi, NBT temelli)
     * alır, Bukkit ItemStack'e çevirip fiyat hesabını yapar, sonucu tekrar
     * PacketEvents ItemStack'ine çevirip döner. Orijinal packet item'ı KLONLANIR,
     * asıl obje mutasyona uğratılmaz.
     */
    private ItemStack applyPriceLoreToPacketItem(ItemStack packetItem) {
        if (packetItem == null || packetItem.isEmpty()) return packetItem;

        org.bukkit.inventory.ItemStack bukkitItem = com.github.retrooper.packetevents.util.SpigotConversionUtil
                .toBukkitItemStack(packetItem);
        if (bukkitItem == null || bukkitItem.getType().isAir()) return packetItem;

        org.bukkit.inventory.ItemStack withPrice = bukkitItem.clone();
        ItemMeta meta = withPrice.getItemMeta();
        if (meta == null) return packetItem;

        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.removeIf(line -> stripColor(line).startsWith(FIYAT_PREFIX));

        boolean isShulker = SHULKER_BOX_TYPES.contains(withPrice.getType().name());
        boolean hasOwnPrice = plugin.getWorthManager().hasPriceForItem(withPrice);
        double contentsValue = isShulker ? getShulkerContentsValue(meta) : 0.0;

        if (hasOwnPrice || contentsValue > 0.0) {
            double unitPrice = hasOwnPrice ? plugin.getWorthManager().getUnitPriceForItem(withPrice) : 0.0;
            double totalPrice = (unitPrice * withPrice.getAmount()) + contentsValue;
            String suffix = (isShulker && contentsValue > 0.0) ? " &7(içerik dahil)" : "";
            lore.add(plugin.msg("&7" + FIYAT_PREFIX + "&a$" + formatPrice(totalPrice) + suffix));
            meta.setLore(lore);
            withPrice.setItemMeta(meta);
            return com.github.retrooper.packetevents.util.SpigotConversionUtil.fromBukkitItemStack(withPrice);
        }

        // Fiyatı yoksa orijinal paket item'ını (klonlamadan) olduğu gibi döneriz.
        return packetItem;
    }

    private double getShulkerContentsValue(ItemMeta meta) {
        if (!(meta instanceof BlockStateMeta blockStateMeta)) return 0.0;
        if (!(blockStateMeta.getBlockState() instanceof ShulkerBox shulkerBox)) return 0.0;

        double total = 0.0;
        for (org.bukkit.inventory.ItemStack content : shulkerBox.getInventory().getContents()) {
            if (content == null || content.getType().isAir()) continue;
            if (!plugin.getWorthManager().hasPriceForItem(content)) continue;
            double unitPrice = plugin.getWorthManager().getUnitPriceForItem(content);
            total += unitPrice * content.getAmount();
        }
        return total;
    }

    private String stripColor(String text) {
        if (text == null) return "";
        return text.replaceAll("(?i)[&§][0-9A-FK-ORX]", "");
    }

    private String formatPrice(double price) {
        double abs = Math.abs(price);
        if (abs >= 1_000_000_000.0) {
            return String.format("%.1fB", price / 1_000_000_000.0);
        }
        if (abs >= 1_000_000.0) {
            return String.format("%.1fM", price / 1_000_000.0);
        }
        if (abs >= 1_000.0) {
            return String.format("%.1fK", price / 1_000.0);
        }
        if (price == Math.floor(price)) {
            return String.valueOf((long) price);
        }
        return String.format("%.2f", price);
    }
}

package com.azy.worth;

import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tüm fiyat (worth) verisinin TEK doğruluk kaynağı burasıdır.
 *
 * ÖNEMLİ: worth.yml formatı DonutWorth2'nin worth.yml'siyle birebir uyumludur:
 *   multiplier: 1
 *   items:
 *     STONE: 1.0
 *     ...
 * Sunucudaki mevcut worth.yml dosyasını bu plugin'in data-folder'ına kopyalayıp
 * kullanabilirsin — hiçbir fiyat/çarpan kaybolmaz, aynen okunur.
 *
 * ÖZEL İSİMLİ EŞYA FİYATLARI (custom-prices.yml):
 * Materyal bazlı fiyatın YANI SIRA, özel görünen isimli item'lar (örn. bir NPC/quest
 * ödülü, özel isimli bir kılıç) için AYRI bir fiyat tanımlanabilir. Anahtar olarak
 * item'ın "temiz" (renk kodları temizlenmiş) display name'i kullanılır. Bir item'ın
 * hem materyal fiyatı hem özel isim fiyatı varsa, ÖZEL İSİM FİYATI ÖNCELİKLİDİR.
 */
public class WorthManager {

    private final AzyWorth plugin;
    private final Map<Material, Double> prices = new ConcurrentHashMap<>();
    /** Özel isimli eşya fiyatları: temizlenmiş display name -> taban fiyat. */
    private final Map<String, Double> customNamePrices = new ConcurrentHashMap<>();
    /** Global çarpan (worth.yml -> multiplier). Tüm satışlara uygulanan TEMEL çarpan. */
    private double globalMultiplier = 1.0;

    public WorthManager(AzyWorth plugin) {
        this.plugin = plugin;
    }

    public void load() {
        prices.clear();
        customNamePrices.clear();

        File file = new File(plugin.getDataFolder(), "worth.yml");
        if (!file.exists()) {
            plugin.saveResource("worth.yml", false);
        }

        FileConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        this.globalMultiplier = yaml.getDouble("multiplier", 1.0);

        if (yaml.isConfigurationSection("items")) {
            for (String key : yaml.getConfigurationSection("items").getKeys(false)) {
                Material material = Material.matchMaterial(key.toUpperCase());
                if (material == null) {
                    plugin.getLogger().warning("Bilinmeyen materyal, worth.yml'de atlandı: " + key);
                    continue;
                }
                double price = yaml.getDouble("items." + key, 0);
                prices.put(material, price);
            }
        }

        File customFile = new File(plugin.getDataFolder(), "custom-prices.yml");
        if (!customFile.exists()) {
            try {
                customFile.getParentFile().mkdirs();
                customFile.createNewFile();
            } catch (Exception ignored) {
            }
        }
        FileConfiguration customYaml = YamlConfiguration.loadConfiguration(customFile);
        if (customYaml.isConfigurationSection("custom-items")) {
            for (String key : customYaml.getConfigurationSection("custom-items").getKeys(false)) {
                double price = customYaml.getDouble("custom-items." + key, 0);
                customNamePrices.put(key, price);
            }
        }

        plugin.getLogger().info("AzyWorth: " + prices.size() + " materyal fiyatı, "
                + customNamePrices.size() + " özel isimli eşya fiyatı yüklendi. Global çarpan: " + globalMultiplier + "x");
    }

    /**
     * Bir materyalin BİR ADEDİNİN taban fiyatı (global multiplier dahil, VIP çarpanları HARİÇ).
     * VIP/kişisel çarpanlar AzySell tarafında ayrıca uygulanır.
     */
    public double getUnitPrice(Material material) {
        Double base = prices.get(material);
        if (base == null) return 0;
        return base * globalMultiplier;
    }

    public boolean hasPrice(Material material) {
        Double base = prices.get(material);
        return base != null && base > 0;
    }

    /**
     * Bir ItemStack'in nihai birim fiyatını hesaplar: önce özel isim fiyatına bakar
     * (item'ın display name'i customNamePrices'ta tanımlıysa o kullanılır),
     * yoksa materyal bazlı fiyata düşer. Shulker box içeriği burada HESAPLANMAZ,
     * onu SellService kendi recursive mantığıyla ayrıca yapar.
     */
    public double getUnitPriceForItem(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) return 0;

        String cleanName = extractCleanName(stack);
        if (cleanName != null) {
            Double customBase = customNamePrices.get(cleanName);
            if (customBase != null) {
                return customBase * globalMultiplier;
            }
        }
        return getUnitPrice(stack.getType());
    }

    public boolean hasPriceForItem(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) return false;
        String cleanName = extractCleanName(stack);
        if (cleanName != null && customNamePrices.containsKey(cleanName)) {
            return true;
        }
        return hasPrice(stack.getType());
    }

    /**
     * Item'ın display name'ini renk kodlarından (& ve § ile başlayan her şeyden) temizler.
     * Item'ın custom display name'i yoksa null döner (yani sadece materyal fiyatı geçerli olur).
     */
    private String extractCleanName(ItemStack stack) {
        if (stack.getItemMeta() == null || !stack.getItemMeta().hasDisplayName()) {
            return null;
        }
        String raw = stack.getItemMeta().getDisplayName();
        return raw.replaceAll("(?i)[&§][0-9A-FK-ORX]", "").trim();
    }

    public double getGlobalMultiplier() {
        return globalMultiplier;
    }

    public void setGlobalMultiplier(double multiplier) {
        this.globalMultiplier = multiplier;
        saveMultiplier();
    }

    public void setPrice(Material material, double basePrice) {
        prices.put(material, basePrice);
        savePrice(material, basePrice);
    }

    /**
     * Özel isimli bir item için AYRI fiyat tanımlar/günceller.
     * Bu, /setworth komutunun "elindeki eşya özel isimliyse" durumunda kullanılır.
     */
    public void setCustomNamePrice(String cleanName, double basePrice) {
        customNamePrices.put(cleanName, basePrice);
        File customFile = new File(plugin.getDataFolder(), "custom-prices.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(customFile);
        yaml.set("custom-items." + cleanName, basePrice);
        try {
            yaml.save(customFile);
        } catch (Exception ex) {
            plugin.getLogger().warning("custom-prices.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    /** Bir ItemStack'in (varsa) temizlenmiş özel adını dışa açar - AzyWorth komutları için. */
    public String cleanNameOf(ItemStack stack) {
        return extractCleanName(stack);
    }

    /** Salt-okunur kopya: AzySell'in kategori/filtre GUI'lerinde tüm listeyi göstermesi için. */
    public Map<Material, Double> getAllBasePrices() {
        return new LinkedHashMap<>(prices);
    }

    public Map<String, Double> getAllCustomNamePrices() {
        return new LinkedHashMap<>(customNamePrices);
    }

    private void savePrice(Material material, double basePrice) {
        File file = new File(plugin.getDataFolder(), "worth.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        yaml.set("items." + material.name(), basePrice);
        try {
            yaml.save(file);
        } catch (Exception ex) {
            plugin.getLogger().warning("worth.yml kaydedilemedi: " + ex.getMessage());
        }
    }

    private void saveMultiplier() {
        File file = new File(plugin.getDataFolder(), "worth.yml");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        yaml.set("multiplier", globalMultiplier);
        try {
            yaml.save(file);
        } catch (Exception ex) {
            plugin.getLogger().warning("worth.yml kaydedilemedi: " + ex.getMessage());
        }
    }
}

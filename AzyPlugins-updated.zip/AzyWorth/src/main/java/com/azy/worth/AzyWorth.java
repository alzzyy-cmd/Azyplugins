package com.azy.worth;

import com.azy.worth.gui.WorthGui;
import com.azy.worth.gui.WorthGuiListener;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AzyWorth extends JavaPlugin {

    private static final Pattern HEX_PATTERN = Pattern.compile("#([A-Fa-f0-9]{6})");

    private WorthManager worthManager;

    @Override
    public void onEnable() {
        this.worthManager = new WorthManager(this);
        worthManager.load();

        getServer().getPluginManager().registerEvents(new WorthDisplayListener(this), this);
        getServer().getPluginManager().registerEvents(new WorthGuiListener(this), this);

        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new PlaceholderExpansionAzyWorth(this).register();
            getLogger().info("PlaceholderAPI bulundu, %azyworth_...% placeholder'ları kaydedildi.");
        } else {
            getLogger().info("PlaceholderAPI bulunamadı, %azyworth_...% placeholder'ları devre dışı.");
        }

        getLogger().info("AzyWorth aktif edildi.");
    }

    @Override
    public void onDisable() {
        getLogger().info("AzyWorth devre dışı bırakıldı.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase()) {
            case "fiyatlar" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                    return true;
                }
                if (!player.hasPermission("azyworth.use")) {
                    player.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                new WorthGui(this, 0).open(player);
                return true;
            }
            case "azyworthreload" -> {
                if (!sender.hasPermission("azyworth.reload")) {
                    sender.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                worthManager.load();
                sender.sendMessage(msg("&aAzyWorth fiyat listesi yeniden yüklendi."));
                return true;
            }
            case "azyworthset" -> {
                if (!sender.hasPermission("azyworth.admin")) {
                    sender.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage(msg("&cKullanım: /azyworthset <material> <fiyat>"));
                    return true;
                }
                Material material = Material.matchMaterial(args[0].toUpperCase());
                if (material == null) {
                    sender.sendMessage(msg("&cGeçersiz materyal: " + args[0]));
                    return true;
                }
                double price;
                try {
                    price = Double.parseDouble(args[1]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage(msg("&cGeçersiz fiyat: " + args[1]));
                    return true;
                }
                worthManager.setPrice(material, price);
                sender.sendMessage(msg("&a" + material.name() + " &7fiyatı &a$" + price + " &7olarak ayarlandı."));
                return true;
            }
            case "setworth" -> {
                // /setworth <fiyat>
                //   -> elindeki eşyanın fiyatını değiştirir.
                //      Eşyanın ÖZEL BİR İSMİ (custom display name) varsa, fiyat SADECE
                //      o isme özel olarak kaydedilir (materyal bazlı fiyata dokunulmaz).
                //      Özel ismi yoksa materyal bazlı fiyat değişir.
                // /setworth <material> <fiyat>
                //   -> materyal bazlı fiyatı doğrudan değiştirir (elindeki item'a bakılmaz).
                if (!sender.hasPermission("azyworth.admin")) {
                    sender.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                    return true;
                }

                if (args.length == 1) {
                    if (!(sender instanceof Player player)) {
                        sender.sendMessage(msg("&cKonsoldan kullanırken materyal adını da belirtmelisin: /setworth <material> <fiyat>"));
                        return true;
                    }
                    ItemStack handItem = player.getInventory().getItemInMainHand();
                    if (handItem.getType().isAir()) {
                        player.sendMessage(msg("&cElinde bir eşya tutmuyorsun."));
                        return true;
                    }

                    double newPrice;
                    try {
                        newPrice = Double.parseDouble(args[0]);
                    } catch (NumberFormatException ex) {
                        player.sendMessage(msg("&cGeçersiz fiyat: " + args[0]));
                        return true;
                    }
                    if (newPrice < 0) {
                        player.sendMessage(msg("&cFiyat negatif olamaz."));
                        return true;
                    }

                    String cleanName = worthManager.cleanNameOf(handItem);
                    if (cleanName != null && !cleanName.isBlank()) {
                        // Özel isimli eşya: fiyat SADECE bu isme özel kaydedilir.
                        worthManager.setCustomNamePrice(cleanName, newPrice);
                        player.sendMessage(msg("&a\"" + cleanName + "\" &7(özel isimli eşya) fiyatı &a$" + newPrice + " &7olarak ayarlandı."));
                        player.sendMessage(msg("&7Not: bu, aynı materyalin (&f" + handItem.getType().name() + "&7) genel fiyatını ETKİLEMEZ."));
                    } else {
                        worthManager.setPrice(handItem.getType(), newPrice);
                        player.sendMessage(msg("&a" + handItem.getType().name() + " &7fiyatı &a$" + newPrice + " &7olarak ayarlandı."));
                    }
                    return true;
                }

                if (args.length >= 2) {
                    Material parsed = Material.matchMaterial(args[0].toUpperCase());
                    if (parsed == null) {
                        sender.sendMessage(msg("&cGeçersiz materyal: " + args[0]));
                        return true;
                    }
                    double newPrice;
                    try {
                        newPrice = Double.parseDouble(args[1]);
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(msg("&cGeçersiz fiyat: " + args[1]));
                        return true;
                    }
                    if (newPrice < 0) {
                        sender.sendMessage(msg("&cFiyat negatif olamaz."));
                        return true;
                    }
                    worthManager.setPrice(parsed, newPrice);
                    sender.sendMessage(msg("&a" + parsed.name() + " &7fiyatı &a$" + newPrice + " &7olarak ayarlandı."));
                    return true;
                }

                sender.sendMessage(msg("&cKullanım: /setworth <fiyat> &7(elindeki eşya için) &7veya /setworth <material> <fiyat>"));
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    public String msg(String raw) {
        Matcher matcher = HEX_PATTERN.matcher(raw);
        StringBuilder buffer = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.toCharArray()) {
                replacement.append('§').append(c);
            }
            matcher.appendReplacement(buffer, replacement.toString());
        }
        matcher.appendTail(buffer);
        return ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }

    public WorthManager getWorthManager() {
        return worthManager;
    }
}

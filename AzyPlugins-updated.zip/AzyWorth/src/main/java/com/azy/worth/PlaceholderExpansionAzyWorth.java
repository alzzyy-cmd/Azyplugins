package com.azy.worth;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;

/**
 * AzyWorth'ün fiyat verisini diğer pluginlere (hologramlar, scoreboard, GUI'ler vb.)
 * PlaceholderAPI üzerinden açar.
 *
 * Desteklenen placeholder'lar:
 *   %azyworth_multiplier%              -> global çarpan (örn. "1.5")
 *   %azyworth_price_<MATERIAL>%        -> materyalin birim fiyatı, çarpan dahil (örn. %azyworth_price_diamond%)
 *   %azyworth_hasprice_<MATERIAL>%     -> materyalin satılabilir fiyatı var mı ("true"/"false")
 *   %azyworth_heldprice%               -> oyuncunun elindeki eşyanın birim fiyatı (özel isim fiyatı varsa o, yoksa materyal fiyatı)
 *   %azyworth_heldname%                -> oyuncunun elindeki eşyanın özel (temizlenmiş) ismi, yoksa boş string
 *
 * NOT: <MATERIAL> kısmı büyük/küçük harf duyarsız verilebilir (örn. "Diamond" veya "DIAMOND").
 */
public class PlaceholderExpansionAzyWorth extends PlaceholderExpansion {

    private final AzyWorth plugin;

    public PlaceholderExpansionAzyWorth(AzyWorth plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "azyworth";
    }

    @Override
    public @NotNull String getAuthor() {
        return "AzyPlugins";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    /**
     * PlaceholderAPI plugin'i devre dışı kalıp yeniden etkinleştirilse bile
     * bu expansion'ın kayıtlı kalması için true. AzyWorth reload edildiğinde
     * (worth.yml yeniden yüklendiğinde) tekrar register etmeye gerek kalmaz,
     * çünkü fiyatlar WorthManager üzerinden CANLI okunuyor, expansion içinde
     * hiçbir şey cache'lenmiyor.
     */
    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public @Nullable String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        WorthManager worthManager = plugin.getWorthManager();

        if (params.equalsIgnoreCase("multiplier")) {
            return String.valueOf(worthManager.getGlobalMultiplier());
        }

        if (params.equalsIgnoreCase("heldprice") || params.equalsIgnoreCase("heldname")) {
            // Bu ikisi elindeki eşyaya bakar, dolayısıyla oyuncu ONLINE olmalı.
            if (!(offlinePlayer instanceof Player player) || !player.isOnline()) {
                return "0";
            }
            ItemStack handItem = player.getInventory().getItemInMainHand();
            if (params.equalsIgnoreCase("heldname")) {
                String cleanName = worthManager.cleanNameOf(handItem);
                return cleanName == null ? "" : cleanName;
            }
            return String.valueOf(worthManager.getUnitPriceForItem(handItem));
        }

        if (params.toLowerCase(Locale.ROOT).startsWith("price_")) {
            Material material = parseMaterial(params.substring("price_".length()));
            if (material == null) return "0";
            return String.valueOf(worthManager.getUnitPrice(material));
        }

        if (params.toLowerCase(Locale.ROOT).startsWith("hasprice_")) {
            Material material = parseMaterial(params.substring("hasprice_".length()));
            if (material == null) return "false";
            return String.valueOf(worthManager.hasPrice(material));
        }

        return null; // Tanınmayan placeholder -> PlaceholderAPI ham metni değiştirmeden bırakır.
    }

    private Material parseMaterial(String raw) {
        return Material.matchMaterial(raw.toUpperCase(Locale.ROOT));
    }
}

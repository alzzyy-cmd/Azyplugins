package com.azy.worth.gui;

import com.azy.worth.AzyWorth;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * /fiyatlar (alias: /worth) komutuyla açılan sayfalı eşya fiyat listesi.
 * Her sayfada 44 item gösterilir (54 slottan biri sıralama butonu, ikisi
 * gezinme butonları için ayrılır).
 */
public class WorthGui implements InventoryHolder {

    private static final int PAGE_SIZE = 44;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_SORT = 49;
    private static final int SLOT_NEXT = 53;

    private final AzyWorth plugin;
    private final int page;
    private final SortMode sortMode;
    private Inventory inventory;

    public WorthGui(AzyWorth plugin, int page) {
        this(plugin, page, SortMode.HIGHEST_PRICE);
    }

    public WorthGui(AzyWorth plugin, int page, SortMode sortMode) {
        this.plugin = plugin;
        this.page = page;
        this.sortMode = sortMode;
    }

    public void open(Player player) {
        List<Map.Entry<Material, Double>> entries = new ArrayList<>(
                plugin.getWorthManager().getAllBasePrices().entrySet());
        // Not: değeri 0 olan eşyalar artık listeden çıkarılmıyor — bunlar da
        // listede "$0" olarak görünür (önceden tamamen gizleniyordu).
        sortEntries(entries);

        int maxPages = Math.max(1, (int) Math.ceil(entries.size() / (double) PAGE_SIZE));
        int clampedPage = Math.max(0, Math.min(page, maxPages - 1));

        String title = plugin.msg("&8Eşya Fiyatları &7(Sayfa " + (clampedPage + 1) + "/" + maxPages + ")");
        inventory = Bukkit.createInventory(this, 54, title);

        int start = clampedPage * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, entries.size());
        for (int i = start; i < end; i++) {
            Map.Entry<Material, Double> entry = entries.get(i);
            double unitPrice = entry.getValue() * plugin.getWorthManager().getGlobalMultiplier();
            inventory.setItem(i - start, buildEntryItem(entry.getKey(), unitPrice));
        }

        if (clampedPage > 0) {
            inventory.setItem(SLOT_PREV, navButton("&aÖnceki Sayfa"));
        }
        if (clampedPage < maxPages - 1) {
            inventory.setItem(SLOT_NEXT, navButton("&aSonraki Sayfa"));
        }
        inventory.setItem(SLOT_SORT, sortButton());

        player.openInventory(inventory);
    }

    private void sortEntries(List<Map.Entry<Material, Double>> entries) {
        switch (sortMode) {
            case LOWEST_PRICE -> entries.sort((a, b) -> Double.compare(a.getValue(), b.getValue()));
            case NAME_A_Z -> entries.sort((a, b) -> a.getKey().name().compareTo(b.getKey().name()));
            case NAME_Z_A -> entries.sort((a, b) -> b.getKey().name().compareTo(a.getKey().name()));
            case HIGHEST_PRICE -> entries.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        }
    }

    private ItemStack buildEntryItem(Material material, double unitPrice) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(Component.translatable(material.translationKey())
                    .color(NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false));
            meta.setLore(List.of(plugin.msg("&7Değer: &a$" + format(unitPrice))));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack navButton(String name) {
        ItemStack stack = new ItemStack(Material.ARROW);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack sortButton() {
        ItemStack stack = new ItemStack(Material.HOPPER);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&eSıralama: " + sortMode.getDisplayName()));
            meta.setLore(List.of(plugin.msg("&7Değiştirmek için tıkla")));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String format(double price) {
        if (price == Math.floor(price)) return String.valueOf((long) price);
        return String.format("%.2f", price);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public int getPage() {
        return page;
    }

    public SortMode getSortMode() {
        return sortMode;
    }

    public static int getSlotPrev() { return SLOT_PREV; }
    public static int getSlotNext() { return SLOT_NEXT; }
    public static int getSlotSort() { return SLOT_SORT; }
}

package com.azy.worth.gui;

import com.azy.worth.AzyWorth;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * /fiyatlar (alias: /worth) komutuyla açılan sayfalı eşya fiyat listesi.
 * Her sayfada 45 item gösterilir (54 slottan 9'u alt gezinme çubuğu için ayrılır).
 */
public class WorthGui implements InventoryHolder {

    private static final int PAGE_SIZE = 45;
    private static final int SLOT_PREV = 45;
    private static final int SLOT_NEXT = 53;

    private final AzyWorth plugin;
    private final int page;
    private Inventory inventory;

    public WorthGui(AzyWorth plugin, int page) {
        this.plugin = plugin;
        this.page = page;
    }

    public void open(Player player) {
        List<Map.Entry<Material, Double>> entries = new ArrayList<>(
                plugin.getWorthManager().getAllBasePrices().entrySet());
        entries.removeIf(e -> e.getValue() <= 0);
        entries.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));

        int maxPages = Math.max(1, (int) Math.ceil(entries.size() / (double) PAGE_SIZE));
        int clampedPage = Math.max(0, Math.min(page, maxPages - 1));

        String title = plugin.msg("&8Eşya Fiyatları &7(Sayfa " + (clampedPage + 1) + "/" + maxPages + ")");
        inventory = Bukkit.createInventory(this, 54, title);

        int start = clampedPage * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, entries.size());
        for (int i = start; i < end; i++) {
            Map.Entry<Material, Double> entry = entries.get(i);
            double unitPrice = entry.getValue() * plugin.getWorthManager().getGlobalMultiplier();
            inventory.addItem(buildEntryItem(entry.getKey(), unitPrice));
        }

        if (clampedPage > 0) {
            inventory.setItem(SLOT_PREV, navButton("&aÖnceki Sayfa"));
        }
        if (clampedPage < maxPages - 1) {
            inventory.setItem(SLOT_NEXT, navButton("&aSonraki Sayfa"));
        }

        player.openInventory(inventory);
    }

    private ItemStack buildEntryItem(Material material, double unitPrice) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg("&f" + prettify(material.name())));
            meta.setLore(List.of(plugin.msg("&7Worth: &a$" + format(unitPrice))));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack navButton(String name) {
        ItemStack stack = new ItemStack(Material.ARROW);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(plugin.msg(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private String prettify(String materialName) {
        String[] parts = materialName.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }

    private String format(double price) {
        if (price == Math.floor(price)) return String.valueOf((long) price);
        return String.format("%.2f", price);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public int getPage() {
        return page;
    }

    public static int getSlotPrev() { return SLOT_PREV; }
    public static int getSlotNext() { return SLOT_NEXT; }
}

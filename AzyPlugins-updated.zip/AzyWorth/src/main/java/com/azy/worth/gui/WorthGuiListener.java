package com.azy.worth.gui;

import com.azy.worth.AzyWorth;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

public class WorthGuiListener implements Listener {

    private final AzyWorth plugin;

    public WorthGuiListener(AzyWorth plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof WorthGui gui)) return;

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) {
            return;
        }

        Player player = (Player) event.getWhoClicked();
        int slot = event.getSlot();

        if (slot == WorthGui.getSlotPrev()) {
            new WorthGui(plugin, gui.getPage() - 1, gui.getSortMode(), gui.getCategoryFilter()).open(player);
        } else if (slot == WorthGui.getSlotNext()) {
            new WorthGui(plugin, gui.getPage() + 1, gui.getSortMode(), gui.getCategoryFilter()).open(player);
        } else if (slot == WorthGui.getSlotSort()) {
            // Sıralama değişince ilk sayfaya dönülür: eski sayfa numarası yeni
            // sıralamada anlamsız olabilir.
            new WorthGui(plugin, 0, gui.getSortMode().next(), gui.getCategoryFilter()).open(player);
        } else if (slot == WorthGui.getSlotCategory()) {
            // Kategori değişince de ilk sayfaya dönülür (farklı kategoride
            // toplam sayfa sayısı değişir). Sıra: Tümü -> ilk kategori -> ... -> son -> Tümü.
            String nextCategory = nextCategory(gui.getCategoryFilter());
            new WorthGui(plugin, 0, gui.getSortMode(), nextCategory).open(player);
        }
    }

    /**
     * Kategori filtresinde bir sonraki adıma geçer: null (Tümü) -> ilk kategori
     * -> ikinci kategori -> ... -> son kategori -> null (Tümü) - baştan başlar.
     */
    private String nextCategory(String current) {
        java.util.List<String> ids = plugin.getCategoryManager().getCategoryIds();
        if (ids.isEmpty()) return null;
        if (current == null) return ids.get(0);
        int index = ids.indexOf(current);
        if (index < 0 || index == ids.size() - 1) return null; // son kategoriden sonra "Tümü"ye dön
        return ids.get(index + 1);
    }
}

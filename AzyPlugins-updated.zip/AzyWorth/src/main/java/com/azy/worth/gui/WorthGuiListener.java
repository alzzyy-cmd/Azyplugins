package com.azy.worth.gui;

import com.azy.worth.AzyWorth;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

public class WorthGuiListener implements Listener {

    private final AzyWorth plugin;

    public WorthGuiListener(AzyWorth plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof WorthGui gui)) return;

        event.setCancelled(true);
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) {
            return;
        }

        Player player = (Player) event.getWhoClicked();
        int slot = event.getSlot();

        if (slot == WorthGui.getSlotPrev()) {
            new WorthGui(plugin, gui.getPage() - 1).open(player);
        } else if (slot == WorthGui.getSlotNext()) {
            new WorthGui(plugin, gui.getPage() + 1).open(player);
        }
    }
}

package com.azy.worth;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * worth-categories.yml dosyasını okur: AzySell'in sell-categories.yml
 * dosyasından build-time'da kopyalanmış kategori -> materyal eşlemesini
 * /worth (/fiyatlar) GUI'sindeki kategori filtresi için sağlar.
 *
 * AzySell'e RUNTIME bağımlılığı YOKTUR — bu bilinçli bir tasarım: AzyWorth,
 * AzySell yüklü olmasa bile çalışmaya devam etmelidir. Bu yüzden materyal
 * listesi statik bir kopyadır (AzySell'deki kategoriler değişirse bu dosyanın
 * da elle güncellenmesi/yeniden kopyalanması gerekir).
 */
public class WorthCategoryManager {

    /** Kategori id -> görünen isim (örn. "mining" -> "Cevherler"). Sıra, YAML'daki sırayla aynıdır. */
    private final Map<String, String> categoryDisplayNames = new LinkedHashMap<>();
    /** Kategori id -> ikon materyali (filtre butonunda gösterilecek). */
    private final Map<String, Material> categoryIcons = new LinkedHashMap<>();
    /** Materyal -> ait olduğu kategori id (hızlı ters bakış için). Bir materyal en fazla bir kategoriye aittir. */
    private final Map<Material, String> materialToCategory = new EnumMap<>(Material.class);
    /** Kategori id -> o kategoriye ait materyaller kümesi. */
    private final Map<String, Set<Material>> categoryMaterials = new LinkedHashMap<>();

    private final AzyWorth plugin;

    public WorthCategoryManager(AzyWorth plugin) {
        this.plugin = plugin;
    }

    public void load() {
        categoryDisplayNames.clear();
        categoryIcons.clear();
        materialToCategory.clear();
        categoryMaterials.clear();

        try (InputStream stream = plugin.getResource("worth-categories.yml")) {
            if (stream == null) {
                plugin.getLogger().warning("worth-categories.yml bulunamadı, kategori filtresi devre dışı kalacak.");
                return;
            }
            YamlConfiguration config = YamlConfiguration.loadConfiguration(
                    new InputStreamReader(stream, StandardCharsets.UTF_8));

            ConfigurationSection categoriesSection = config.getConfigurationSection("categories");
            if (categoriesSection == null) return;

            for (String categoryId : categoriesSection.getKeys(false)) {
                ConfigurationSection catSection = categoriesSection.getConfigurationSection(categoryId);
                if (catSection == null) continue;

                String displayName = catSection.getString("display-name", categoryId);
                String iconName = catSection.getString("icon", "STONE");
                Material icon = Material.matchMaterial(iconName);
                if (icon == null) icon = Material.STONE;

                categoryDisplayNames.put(categoryId, displayName);
                categoryIcons.put(categoryId, icon);

                Set<Material> materials = java.util.EnumSet.noneOf(Material.class);
                for (String matName : catSection.getStringList("materials")) {
                    Material material = Material.matchMaterial(matName);
                    if (material == null) continue;
                    materials.add(material);
                    materialToCategory.put(material, categoryId);
                }
                categoryMaterials.put(categoryId, materials);
            }
        } catch (IOException ex) {
            plugin.getLogger().warning("worth-categories.yml okunamadı: " + ex.getMessage());
        }
    }

    /** Kategori id'lerini, YAML dosyasındaki sırayla döner (örn. farm, mining, ...). */
    public List<String> getCategoryIds() {
        return new ArrayList<>(categoryDisplayNames.keySet());
    }

    public String getDisplayName(String categoryId) {
        return categoryDisplayNames.getOrDefault(categoryId, categoryId);
    }

    public Material getIcon(String categoryId) {
        return categoryIcons.getOrDefault(categoryId, Material.STONE);
    }

    /** Bir materyalin ait olduğu kategori id'sini döner; hiçbir kategoriye ait değilse null. */
    public String getCategoryOf(Material material) {
        return materialToCategory.get(material);
    }

    public boolean isInCategory(Material material, String categoryId) {
        Set<Material> materials = categoryMaterials.get(categoryId);
        return materials != null && materials.contains(material);
    }
}

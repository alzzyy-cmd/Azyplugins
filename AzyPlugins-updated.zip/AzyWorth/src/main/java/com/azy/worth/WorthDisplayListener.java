package com.azy.worth;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.block.ShulkerBox;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BlockStateMeta;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Eşya Değeri Gösterimi: iki ayrı mekanizma birlikte çalışır.
 *
 * 1) ACTION BAR (anlık, kalıcı olmayan): oyuncu elindeki eşyayı değiştirdiğinde
 *    action bar'da elindeki STACK'İN TOPLAM DEĞERİNİ gösterir.
 *
 * 2) KALICI LORE (item'ın gerçek verisine yazılır): item'ın lore'unun EN ALTINA
 *    "Fiyat: $X" satırı eklenir - X, birim fiyat çarpı o anki stack adedi
 *    (TOPLAM fiyat), K/M/B (bin/milyon/milyar) formatında kısaltılmış olarak
 *    (örn. 1.5K, 2.3M). Item, ENVANTERE GİRDİĞİ AN (item alma/toplama/craft/
 *    envanter tıklama) fiyatı hemen yazılır - elde tutulmasını ya da envanterin
 *    tekrar açılmasını beklemeye gerek yoktur. Fiyat değişirse (adet ya da
 *    config güncellemesi) eski satır silinip yenisi yazılır.
 *    Başka pluginlerin GUI'lerine (üst envantere) KESİNLİKLE dokunulmaz.
 *    Bu satır özel bir prefix (FIYAT_PREFIX) ile işaretlenir ki yanlışlıkla
 *    başka bir lore satırı silinmesin/karıştırılmasın.
 *
 * 3) SHULKER BOX ÖZEL DURUMU: shulker box'ların (ve renkli varyantlarının)
 *    fiyatı, kendi materyal değeri + İÇİNDEKİ TÜM ITEM'LARIN TOPLAM DEĞERİ
 *    olarak hesaplanır ("içerik dahil" notuyla). Shulker satılırken AzySell
 *    zaten içeriği ayrı ayrı satıyor olabilir - burada gösterilen sadece bir
 *    ÖNİZLEME değeridir, satış mantığına karışmaz.
 */
public class WorthDisplayListener implements Listener {

    /** Kalıcı lore'daki fiyat satırının tanınması için sabit prefix (renksiz, ham metin). */
    private static final String FIYAT_PREFIX = "Fiyat: ";

    private final AzyWorth plugin;

    public WorthDisplayListener(AzyWorth plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onHeldItemChange(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack newItem = player.getInventory().getItem(event.getNewSlot());
        showWorth(player, newItem);
        applyPriceLore(newItem);
    }

    /**
     * Yerden item aldığında (kırılan blok, düşen item vb.) - item envantere
     * girdiği AN fiyatı yazılsın diye bu event de dinleniyor.
     */
    @EventHandler
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        // Item henüz envantere işlenmemiş olabilir; bir sonraki tick'te işlensin.
        plugin.getServer().getScheduler().runTask(plugin, () -> refreshInventory(player.getInventory()));
    }

    /**
     * Crafting masasında/envanterinde bir şey ürettiğinde, üretilen item anında
     * fiyat lore'unu alsın.
     */
    @EventHandler
    public void onCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        plugin.getServer().getScheduler().runTask(plugin, () -> refreshInventory(player.getInventory()));
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        // Envanterinde bir item'a tıkladığında da (kendi envanteri, GUI değil) fiyatı göster.
        if (event.getClickedInventory() == null) return;
        if (event.getClickedInventory().getHolder() != null) return; // sadece oyuncu envanteri
        ItemStack current = event.getCurrentItem();
        if (current != null && !current.getType().isAir()) {
            showWorth(player, current);
        }
        // Tıklama sonrası (shift-click, swap, drag, sayı bölme vb.) envanterin
        // tamamı bir tick sonra tazelenir - böylece hangi slota ne gittiği fark
        // etmeksizin her item anında doğru fiyatla görünür.
        plugin.getServer().getScheduler().runTask(plugin, () -> refreshInventory(player.getInventory()));
    }

    /**
     * Herhangi bir envanter (kendi envanteri veya başka bir plugin'in GUI'si) açıldığında
     * tetiklenir. SADECE oyuncunun KENDİ gerçek envanterini (alt envanter, 36 slot + zırh +
     * offhand) tarar - üstte açılan GUI'ye (AzySell'in sell ekranı, AzyShop'un dükkan
     * ekranı vb.) ASLA dokunulmaz, çünkü oradaki item'lar genelde gerçek eşya değil,
     * dekor/buton amaçlı kullanılan materyal ikonlarıdır.
     */
    @EventHandler
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        refreshInventory(player.getInventory());
    }

    private void refreshInventory(Inventory inventory) {
        ItemStack[] contents = inventory.getContents();
        for (ItemStack item : contents) {
            applyPriceLore(item);
        }
    }

    private void showWorth(Player player, ItemStack item) {
        if (item == null || item.getType().isAir()) return;
        if (!plugin.getWorthManager().hasPriceForItem(item)) return;

        double unitPrice = plugin.getWorthManager().getUnitPriceForItem(item);
        // Senin isteğin: eşya ismi YAZILMASIN, elindeki stack'te kaç tane varsa
        // TOPLAM değeri (birim fiyat * adet) gösterilsin.
        double totalPrice = unitPrice * item.getAmount();

        String text = plugin.msg("&7Toplam Değer: &a$" + formatPrice(totalPrice));
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(text));
    }

    /** Shulker box ve renkli varyantlarının materyal isimleri. */
    private static final Set<String> SHULKER_BOX_TYPES = Set.of(
            "SHULKER_BOX", "WHITE_SHULKER_BOX", "ORANGE_SHULKER_BOX", "MAGENTA_SHULKER_BOX",
            "LIGHT_BLUE_SHULKER_BOX", "YELLOW_SHULKER_BOX", "LIME_SHULKER_BOX", "PINK_SHULKER_BOX",
            "GRAY_SHULKER_BOX", "LIGHT_GRAY_SHULKER_BOX", "CYAN_SHULKER_BOX", "PURPLE_SHULKER_BOX",
            "BLUE_SHULKER_BOX", "BROWN_SHULKER_BOX", "GREEN_SHULKER_BOX", "RED_SHULKER_BOX",
            "BLACK_SHULKER_BOX"
    );

    /**
     * item'ın gerçek lore'una kalıcı "Fiyat: $X" satırını ekler/günceller.
     * X = birim fiyat * mevcut stack adedi (TOPLAM fiyat), K/M/B kısaltmalı.
     * Shulker box ise, kendi değerine ek olarak İÇİNDEKİ tüm item'ların toplam
     * değeri de eklenir ve "(içerik dahil)" notu düşülür.
     * Fiyatı olmayan item'larda varsa eski fiyat satırı temizlenir (silinir).
     */
    private void applyPriceLore(ItemStack item) {
        if (item == null || item.getType().isAir()) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        // Önceki "Fiyat: $..." satırını (varsa) kaldır - ham metne göre eşleştiriyoruz
        // ki renk kodu farkı yüzünden kaçırılmasın.
        lore.removeIf(line -> stripColor(line).startsWith(FIYAT_PREFIX));

        boolean isShulker = SHULKER_BOX_TYPES.contains(item.getType().name());
        boolean hasOwnPrice = plugin.getWorthManager().hasPriceForItem(item);
        double contentsValue = isShulker ? getShulkerContentsValue(meta) : 0.0;

        if (hasOwnPrice || contentsValue > 0.0) {
            double unitPrice = hasOwnPrice ? plugin.getWorthManager().getUnitPriceForItem(item) : 0.0;
            double totalPrice = (unitPrice * item.getAmount()) + contentsValue;
            String suffix = (isShulker && contentsValue > 0.0) ? " &7(içerik dahil)" : "";
            lore.add(plugin.msg("&7" + FIYAT_PREFIX + "&a$" + formatPrice(totalPrice) + suffix));
        }

        meta.setLore(lore.isEmpty() ? null : lore);
        item.setItemMeta(meta);
    }

    /**
     * Shulker box'ın içindeki tüm item'ların TOPLAM değerini hesaplar
     * (her item için birim fiyat * o item'ın adedi, toplanır).
     */
    private double getShulkerContentsValue(ItemMeta meta) {
        if (!(meta instanceof BlockStateMeta blockStateMeta)) return 0.0;
        if (!(blockStateMeta.getBlockState() instanceof ShulkerBox shulkerBox)) return 0.0;

        double total = 0.0;
        for (ItemStack content : shulkerBox.getInventory().getContents()) {
            if (content == null || content.getType().isAir()) continue;
            if (!plugin.getWorthManager().hasPriceForItem(content)) continue;
            double unitPrice = plugin.getWorthManager().getUnitPriceForItem(content);
            total += unitPrice * content.getAmount();
        }
        return total;
    }

    private String stripColor(String text) {
        if (text == null) return "";
        return text.replaceAll("(?i)[&§][0-9A-FK-ORX]", "");
    }

    /**
     * Fiyatı K/M/B (bin/milyon/milyar) formatında, bir ondalık basamakla
     * kısaltarak döner (örn. 1500 -> "1.5K", 2300000 -> "2.3M", 4200000000 -> "4.2B").
     * 1000'in altındaki değerler kısaltılmadan, tam sayı olarak gösterilir.
     */
    private String formatPrice(double price) {
        double abs = Math.abs(price);
        if (abs >= 1_000_000_000.0) {
            return String.format("%.1fB", price / 1_000_000_000.0);
        }
        if (abs >= 1_000_000.0) {
            return String.format("%.1fM", price / 1_000_000.0);
        }
        if (abs >= 1_000.0) {
            return String.format("%.1fK", price / 1_000.0);
        }
        if (price == Math.floor(price)) {
            return String.valueOf((long) price);
        }
        return String.format("%.2f", price);
    }
}

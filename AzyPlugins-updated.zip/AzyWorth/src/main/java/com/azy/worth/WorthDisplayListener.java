package com.azy.worth;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Eşya Değeri Gösterimi: ProtocolLib gibi ağır bir paket kütüphanesine ihtiyaç duymadan,
 * oyuncu elindeki eşyayı değiştirdiğinde (hotbar'da slot değiştirme, envanterde item alma)
 * action bar'da elindeki STACK'İN TOPLAM DEĞERİNİ gösterir (isim yazılmaz, sadece
 * "Toplam Değer: $X" — X, birim fiyat çarpı elindeki adet).
 *
 * Bu yöntem item'ın gerçek lore'una KALICI satır eklemez (yani başka oyuncuya /give ile
 * verilen ya da tekrar satılan item'da fazladan metin birikmez), tamamen görsel ve anlıktır.
 *
 * NOT: Kalıcı tooltip (gerçek lore içinde "Worth: $X" görünmesi, /fiyatlar ekranındaki gibi)
 * için ProtocolLib entegrasyonu ayrıca planlanıyor - bu, item'ın gerçek verisini bozmadan
 * sadece görüntülenen paketi değiştirebilen tek güvenli yöntem.
 */
public class WorthDisplayListener implements Listener {

    private final AzyWorth plugin;

    public WorthDisplayListener(AzyWorth plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onHeldItemChange(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack newItem = player.getInventory().getItem(event.getNewSlot());
        showWorth(player, newItem);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        // Envanterinde bir item'a tıkladığında da (kendi envanteri, GUI değil) fiyatı göster.
        if (event.getClickedInventory() == null) return;
        if (event.getClickedInventory().getHolder() != null) return; // sadece oyuncu envanteri
        ItemStack current = event.getCurrentItem();
        if (current != null && !current.getType().isAir()) {
            showWorth(player, current);
        }
    }

    private void showWorth(Player player, ItemStack item) {
        if (item == null || item.getType().isAir()) return;
        if (!plugin.getWorthManager().hasPriceForItem(item)) return;

        double unitPrice = plugin.getWorthManager().getUnitPriceForItem(item);
        // Senin isteğin: eşya ismi YAZILMASIN, elindeki stack'te kaç tane varsa
        // TOPLAM değeri (birim fiyat * adet) gösterilsin.
        double totalPrice = unitPrice * item.getAmount();

        String text = plugin.msg("&7Toplam Değer: &a$" + formatPrice(totalPrice));
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(text));
    }

    private String formatPrice(double price) {
        if (price == Math.floor(price)) {
            return String.valueOf((long) price);
        }
        return String.format("%.2f", price);
    }
}

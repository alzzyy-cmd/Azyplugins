package com.azy.worth;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

/**
 * "Worth Lore" özelliği: ProtocolLib gibi ağır bir paket kütüphanesine ihtiyaç duymadan,
 * oyuncu elindeki eşyayı değiştirdiğinde (hotbar'da slot değiştirme, envanterde item alma)
 * action bar'da o eşyanın birim fiyatını gösterir.
 *
 * Bu yöntem item'ın gerçek lore'una KALICI satır eklemez (yani başka oyuncuya /give ile
 * verilen ya da tekrar satılan item'da fazladan metin birikmez), tamamen görsel ve anlıktır.
 */
public class WorthDisplayListener implements Listener {

    private final AzyWorth plugin;

    public WorthDisplayListener(AzyWorth plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onHeldItemChange(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack newItem = player.getInventory().getItem(event.getNewSlot());
        showWorth(player, newItem);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        // Envanterinde bir item'a tıkladığında da (kendi envanteri, GUI değil) fiyatı göster.
        if (event.getClickedInventory() == null) return;
        if (event.getClickedInventory().getHolder() != null) return; // sadece oyuncu envanteri
        ItemStack current = event.getCurrentItem();
        if (current != null && !current.getType().isAir()) {
            showWorth(player, current);
        }
    }

    private void showWorth(Player player, ItemStack item) {
        if (item == null || item.getType().isAir()) return;
        if (!plugin.getWorthManager().hasPriceForItem(item)) return;

        double unitPrice = plugin.getWorthManager().getUnitPriceForItem(item);
        String itemName = item.getItemMeta() != null && item.getItemMeta().hasDisplayName()
                ? item.getItemMeta().getDisplayName()
                : prettify(item.getType().name());

        String text = plugin.msg("&f" + itemName + " &7Worth: &a$" + formatPrice(unitPrice));
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(text));
    }

    private String prettify(String materialName) {
        String[] parts = materialName.toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) continue;
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }

    private String formatPrice(double price) {
        if (price == Math.floor(price)) {
            return String.valueOf((long) price);
        }
        return String.format("%.2f", price);
    }
}

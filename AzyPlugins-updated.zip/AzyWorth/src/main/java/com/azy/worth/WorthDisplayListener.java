package com.azy.worth;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Eşya Değeri Gösterimi: iki ayrı mekanizma birlikte çalışır.
 *
 * 1) ACTION BAR (anlık, kalıcı olmayan): oyuncu elindeki eşyayı değiştirdiğinde
 *    action bar'da elindeki STACK'İN TOPLAM DEĞERİNİ gösterir.
 *
 * 2) KALICI LORE (item'ın gerçek verisine yazılır): item'ın lore'unun EN ALTINA
 *    "Fiyat: $X" satırı eklenir - X, birim fiyat çarpı o anki stack adedi
 *    (TOPLAM fiyat). Oyuncunun KENDİ envanteri her açıldığında (kendi envanterini
 *    'e' tuşuyla açması ya da herhangi bir GUI açılırken alt envanterin de
 *    görünür olması durumu) içindeki tüm item'lar taranır, eski "Fiyat: $..."
 *    satırı varsa silinip güncel değerle yeniden yazılır - böylece adet
 *    değiştiğinde veya fiyat config'ten güncellendiğinde lore hep doğru kalır.
 *    Başka pluginlerin GUI'lerine (üst envantere) KESİNLİKLE dokunulmaz.
 *    Bu satır özel bir prefix (FIYAT_PREFIX) ile işaretlenir ki yanlışlıkla
 *    başka bir lore satırı silinmesin/karıştırılmasın.
 */
public class WorthDisplayListener implements Listener {

    /** Kalıcı lore'daki fiyat satırının tanınması için sabit prefix (renksiz, ham metin). */
    private static final String FIYAT_PREFIX = "Fiyat: ";

    private final AzyWorth plugin;

    public WorthDisplayListener(AzyWorth plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onHeldItemChange(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack newItem = player.getInventory().getItem(event.getNewSlot());
        showWorth(player, newItem);
        applyPriceLore(newItem);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        // Envanterinde bir item'a tıkladığında da (kendi envanteri, GUI değil) fiyatı göster.
        if (event.getClickedInventory() == null) return;
        if (event.getClickedInventory().getHolder() != null) return; // sadece oyuncu envanteri
        ItemStack current = event.getCurrentItem();
        if (current != null && !current.getType().isAir()) {
            showWorth(player, current);
            applyPriceLore(current);
        }
    }

    /**
     * Herhangi bir envanter (kendi envanteri veya başka bir plugin'in GUI'si) açıldığında
     * tetiklenir. SADECE oyuncunun KENDİ gerçek envanterini (alt envanter, 36 slot + zırh +
     * offhand) tarar - üstte açılan GUI'ye (AzySell'in sell ekranı, AzyShop'un dükkan
     * ekranı vb.) ASLA dokunulmaz, çünkü oradaki item'lar genelde gerçek eşya değil,
     * dekor/buton amaçlı kullanılan materyal ikonlarıdır.
     */
    @EventHandler
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        refreshInventory(player.getInventory());
    }

    private void refreshInventory(Inventory inventory) {
        ItemStack[] contents = inventory.getContents();
        for (ItemStack item : contents) {
            applyPriceLore(item);
        }
    }

    private void showWorth(Player player, ItemStack item) {
        if (item == null || item.getType().isAir()) return;
        if (!plugin.getWorthManager().hasPriceForItem(item)) return;

        double unitPrice = plugin.getWorthManager().getUnitPriceForItem(item);
        // Senin isteğin: eşya ismi YAZILMASIN, elindeki stack'te kaç tane varsa
        // TOPLAM değeri (birim fiyat * adet) gösterilsin.
        double totalPrice = unitPrice * item.getAmount();

        String text = plugin.msg("&7Toplam Değer: &a$" + formatPrice(totalPrice));
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(text));
    }

    /**
     * item'ın gerçek lore'una kalıcı "Fiyat: $X" satırını ekler/günceller.
     * X = birim fiyat * mevcut stack adedi (TOPLAM fiyat).
     * Fiyatı olmayan item'larda varsa eski fiyat satırı temizlenir (silinir).
     */
    private void applyPriceLore(ItemStack item) {
        if (item == null || item.getType().isAir()) return;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        // Önceki "Fiyat: $..." satırını (varsa) kaldır - ham metne göre eşleştiriyoruz
        // ki renk kodu farkı yüzünden kaçırılmasın.
        lore.removeIf(line -> stripColor(line).startsWith(FIYAT_PREFIX));

        if (plugin.getWorthManager().hasPriceForItem(item)) {
            double unitPrice = plugin.getWorthManager().getUnitPriceForItem(item);
            double totalPrice = unitPrice * item.getAmount();
            lore.add(plugin.msg("&7" + FIYAT_PREFIX + "&a$" + formatPrice(totalPrice)));
        }

        meta.setLore(lore.isEmpty() ? null : lore);
        item.setItemMeta(meta);
    }

    private String stripColor(String text) {
        if (text == null) return "";
        return text.replaceAll("(?i)[&§][0-9A-FK-ORX]", "");
    }

    private String formatPrice(double price) {
        if (price == Math.floor(price)) {
            return String.valueOf((long) price);
        }
        return String.format("%.2f", price);
    }
}

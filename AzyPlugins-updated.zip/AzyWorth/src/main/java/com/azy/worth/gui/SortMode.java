package com.azy.worth.gui;

/**
 * /fiyatlar (/worth) GUI'sinde kullanılabilecek fiyat sıralama modları.
 * Sıradaki moda geçmek için {@link #next()} kullanılır (GUI'deki sıralama
 * butonuna her tıklandığında bir sonraki moda geçilir).
 * NOT: İsme göre A-Z/Z-A sıralama kaldırıldı (Material enum ismi ile
 * ekranda gösterilen yerelleştirilmiş isim uyuşmadığı için karışık
 * görünüyordu) - yerine kategori filtresi eklendi, bkz. WorthGui.
 */
public enum SortMode {

    HIGHEST_PRICE("&aEn Pahalı"),
    LOWEST_PRICE("&aEn Ucuz");

    private final String displayName;

    SortMode(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public SortMode next() {
        SortMode[] values = values();
        return values[(this.ordinal() + 1) % values.length];
    }
}

package com.azy.shop.gui;

import com.azy.shop.AzyShop;
import com.azy.shop.model.ShopCategory;
import com.azy.shop.model.ShopItem;
import com.azy.shop.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Miktar seçimi + onay ekranı.
 *
 * BUG KORUMASI (senin bahsettiğin "1 totem alınca 2 oluyor" sorunu için):
 * Bu ekranda gösterilen "seçili miktar" tamamen GuiHolder.selectedAmount içinde,
 * yani BİZİM tuttuğumuz tek bir int değişkeninde saklanır. Envanterdeki gösterge
 * item'ının stack sayısına ASLA güvenilmez — Bukkit'in setAmount'u miras
 * davranışlarla (örn. ItemStack birleşmesi, event sırası) yanlışlıkla iki kere
 * artabilir. Biz miktarı sadece holder'daki int'ten okur, item veya para/shard
 * bu sayı üzerinden TEK SEFERDE (add/setAmount ile üstüne eklemeden, doğrudan
 * amount * item.getAmount() hesaplayıp) veririz.
 */
public class PurchaseGui {

    private static final int SLOT_REMOVE_MAX = 9;
    private static final int SLOT_REMOVE_TEN = 10;
    private static final int SLOT_REMOVE_ONE = 11;
    private static final int SLOT_DISPLAY = 13;
    private static final int SLOT_ADD_ONE = 15;
    private static final int SLOT_ADD_TEN = 16;
    private static final int SLOT_ADD_MAX = 17;
    private static final int SLOT_CANCEL = 21;
    private static final int SLOT_CONFIRM = 23;

    private final AzyShop plugin;

    public PurchaseGui(AzyShop plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, ShopCategory category, ShopItem item) {
        String titleTemplate = ColorUtil.color(plugin.getConfigManager().getMainConfig()
                .getString("inventory.titles.confirm", "Satın Alınıyor {currentItem}"));
        String title = titleTemplate.replace("{currentItem}", ColorUtil.color(item.getDisplayName()));

        GuiHolder holder = new GuiHolder(GuiHolder.Type.PURCHASE_CONFIRM, category.getId(), item.getId());
        holder.setSelectedAmount(1);
        if (item.isShard()) {
            // Bakiye burada TEK SEFER okunur ve holder'a önbelleklenir. +1/+10/Maksimum
            // butonlarının hepsi bu önbellekten okuyacak, PlaceholderAPI'ye her tıklamada
            // yeniden gidilmeyecek. Gerçek satın alma anında ShardService taze bakiye okur.
            holder.setCachedShardBalance(plugin.getShardService().getShardBalance(player, item));
        }
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        renderControls(inv);
        renderDisplay(inv, item, holder.getSelectedAmount(), holder.getCachedShardBalance());

        player.openInventory(inv);
    }

    private void renderControls(Inventory inv) {
        inv.setItem(SLOT_REMOVE_MAX, button(Material.RED_STAINED_GLASS_PANE, "&cÇıkar Maksimum"));
        inv.setItem(SLOT_REMOVE_TEN, button(Material.RED_STAINED_GLASS_PANE, "&cÇıkar 10"));
        inv.setItem(SLOT_REMOVE_ONE, button(Material.RED_STAINED_GLASS_PANE, "&cÇıkar 1"));
        inv.setItem(SLOT_ADD_ONE, button(Material.LIME_STAINED_GLASS_PANE, "&aEkle 1"));
        inv.setItem(SLOT_ADD_TEN, button(Material.LIME_STAINED_GLASS_PANE, "&aEkle 10"));
        inv.setItem(SLOT_ADD_MAX, button(Material.LIME_STAINED_GLASS_PANE, "&aEkle Maksimum"));
        inv.setItem(SLOT_CANCEL, button(Material.RED_STAINED_GLASS_PANE, "&cİptal"));
        inv.setItem(SLOT_CONFIRM, button(Material.LIME_STAINED_GLASS_PANE, "&aOnayla"));
    }

    private ItemStack button(Material material, String name) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtil.color(name));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    /**
     * Ortadaki gösterge item'ını yeniden çizer. Miktar HER ZAMAN holder.selectedAmount'tan
     * okunur ve ItemStack sıfırdan (yeni bir ItemStack ile) oluşturulur — mevcut stack'in
     * üzerine setAmount ile "ekleme" yapılmaz, böylece çift sayım riski oluşmaz.
     *
     * @param cachedShardBalance shard ürünlerinde GUI açılışında bir kez okunmuş bakiye
     *                           (-1 ise shard değil ya da bakiye okunamadı — bu durumda
     *                           "afford" göstergesi/uyarısı çizilmez). Bu değer HER
     *                           renderDisplay çağrısında yeniden sorgulanmaz, sadece
     *                           parametre olarak geçirilir.
     */
    public void renderDisplay(Inventory inv, ShopItem item, int selectedAmount, double cachedShardBalance) {
        int clamped = Math.max(1, Math.min(selectedAmount, 64 * (item.getAmount() > 0 ? 1 : 1)));
        int totalGiven = clamped * item.getAmount();
        double totalPrice = item.getPrice() * clamped;

        ItemStack display = new ItemStack(item.getMaterial(), Math.min(clamped, 64));
        ItemMeta meta = display.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ColorUtil.color(item.getDisplayName()));
            String priceText = item.isShard()
                    ? ((long) totalPrice) + " parça"
                    : plugin.getEconomyManager().format(totalPrice);

            List<String> lore = new ArrayList<>(List.of(
                    ColorUtil.color("&7Miktar: &f" + clamped + " &7(&f" + totalGiven + " &7eşya verilecek)"),
                    ColorUtil.color("&7Toplam fiyat: &f" + priceText)
            ));
            if (item.isShard() && cachedShardBalance >= 0) {
                boolean canAfford = cachedShardBalance >= totalPrice;
                lore.add(ColorUtil.color((canAfford ? "&7Bakiyen: &f" : "&cBakiyen yetersiz: &f")
                        + (long) cachedShardBalance + " &7Parça"));
            }
            meta.setLore(lore);
            display.setItemMeta(meta);
        }
        inv.setItem(SLOT_DISPLAY, display);
    }

    /**
     * Shard ürünlerinde "Ekle Maksimum" butonu için, GUI açılışında önbelleklenen
     * bakiyeye göre GERÇEKTEN karşılanabilecek maksimum miktarı hesaplar (64 ile sınırlı).
     * Bakiye okunamıyorsa (-1) ya da item shard değilse her zaman 64 döner.
     */
    public int resolveMaxAffordableAmount(ShopItem item, double cachedShardBalance) {
        if (!item.isShard() || cachedShardBalance < 0 || item.getPrice() <= 0) {
            return 64;
        }
        int affordable = (int) Math.floor(cachedShardBalance / item.getPrice());
        return Math.max(1, Math.min(64, affordable));
    }

    public static int getSlotRemoveMax() { return SLOT_REMOVE_MAX; }
    public static int getSlotRemoveTen() { return SLOT_REMOVE_TEN; }
    public static int getSlotRemoveOne() { return SLOT_REMOVE_ONE; }
    public static int getSlotAddOne() { return SLOT_ADD_ONE; }
    public static int getSlotAddTen() { return SLOT_ADD_TEN; }
    public static int getSlotAddMax() { return SLOT_ADD_MAX; }
    public static int getSlotCancel() { return SLOT_CANCEL; }
    public static int getSlotConfirm() { return SLOT_CONFIRM; }
}

package com.azy.shop.economy;

import com.azy.shop.AzyShop;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

/**
 * Vault üzerinden EssentialsX (veya Vault destekleyen başka bir ekonomi plugin'i) ile konuşur.
 * Bu sınıf sadece PARA (Vault economy) işlemlerinden sorumludur.
 * Shard işlemleri bu sınıfa hiç dokunmaz; shard tarafı tamamen DonutShards'a devredilir
 * (bkz. ShardRedirectService).
 */
public class EconomyManager {

    private final AzyShop plugin;
    private Economy economy;

    public EconomyManager(AzyShop plugin) {
        this.plugin = plugin;
    }

    /**
     * Vault servisini bağlar. Vault veya Vault'a bağlı bir ekonomi plugin'i (EssentialsX vb.)
     * yüklü değilse false döner ve plugin parasal satın almaları devre dışı bırakır.
     */
    public boolean setup() {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        this.economy = rsp.getProvider();
        return economy != null;
    }

    public boolean isReady() {
        return economy != null;
    }

    public double getBalance(Player player) {
        if (!isReady()) return 0;
        return economy.getBalance(player);
    }

    public boolean has(Player player, double amount) {
        if (!isReady()) return false;
        return economy.has(player, amount);
    }

    /**
     * Oyuncunun hesabından para düşer.
     * @return işlem başarılıysa true
     */
    public boolean withdraw(Player player, double amount) {
        if (!isReady()) return false;
        if (!economy.has(player, amount)) return false;
        return economy.withdrawPlayer(player, amount).transactionSuccess();
    }

    public void deposit(Player player, double amount) {
        if (!isReady()) return;
        economy.depositPlayer(player, amount);
    }

    public String format(double amount) {
        if (isReady()) {
            return economy.format(amount);
        }
        return String.format("%.2f", amount);
    }
}

package com.azy.shop;

import com.azy.shop.config.ShopConfigManager;
import com.azy.shop.economy.EconomyManager;
import com.azy.shop.economy.ShardService;
import com.azy.shop.gui.MainMenuGui;
import com.azy.shop.gui.ShopListener;
import com.azy.shop.util.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class AzyShop extends JavaPlugin {

    private ShopConfigManager configManager;
    private EconomyManager economyManager;
    private ShardService shardService;
    private MainMenuGui mainMenuGui;

    @Override
    public void onEnable() {
        this.configManager = new ShopConfigManager(this);
        this.configManager.loadAll();

        this.economyManager = new EconomyManager(this);
        boolean economyReady = economyManager.setup();
        if (!economyReady) {
            getLogger().warning("Vault veya bir ekonomi plugin'i (EssentialsX vb.) bulunamadı! "
                    + "Para ile satın alma çalışmayacak.");
        }

        this.shardService = new ShardService(this);
        if (!shardService.isPlaceholderApiPresent()) {
            getLogger().warning("PlaceholderAPI bulunamadı! Shard bakiyesi okunamayacağı için "
                    + "shard ürünleri satın alınamayacak (güvenlik gereği reddedilecek).");
        }
        this.mainMenuGui = new MainMenuGui(this);

        getServer().getPluginManager().registerEvents(new ShopListener(this), this);

        getLogger().info("AzyShop aktif edildi. " + configManager.getCategories().size() + " kategori yüklendi.");
    }

    @Override
    public void onDisable() {
        getLogger().info("AzyShop devre dışı bırakıldı.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("azyshop")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Bu komut sadece oyuncular tarafından kullanılabilir.");
                return true;
            }
            if (!player.hasPermission("azyshop.use")) {
                player.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                return true;
            }
            mainMenuGui.open(player);
            return true;
        }

        if (command.getName().equalsIgnoreCase("azyshopreload")) {
            if (!sender.hasPermission("azyshop.reload")) {
                sender.sendMessage(msg("&cBu komutu kullanma iznin yok."));
                return true;
            }
            configManager.loadAll();
            sender.sendMessage(msg("&aAzyShop configleri yeniden yüklendi. &7(" + configManager.getCategories().size() + " kategori)"));
            return true;
        }

        return false;
    }

    public String msg(String raw) {
        return ColorUtil.color(raw);
    }

    public ShopConfigManager getConfigManager() {
        return configManager;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public ShardService getShardService() {
        return shardService;
    }
}

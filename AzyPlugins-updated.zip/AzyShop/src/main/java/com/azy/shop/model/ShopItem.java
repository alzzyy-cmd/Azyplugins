package com.azy.shop.model;

import org.bukkit.Material;

import java.util.List;

/**
 * Tek bir mağaza ürününü temsil eder.
 * DonutShop'un categories/*.yml formatındaki alanlarla birebir uyumludur:
 * price, isShard, shard_placeholder, material, name, lore, position, commands, amount.
 */
public class ShopItem {

    private final String id;
    private final double price;
    private final boolean isShard;
    private final String shardPlaceholder;
    private final Material material;
    private final String displayName;
    private final List<String> lore;
    private final int position;
    private final List<String> commands;
    private final int amount;

    /**
     * true ise bu item'a tıklandığında GUI kendi satın alma akışını başlatmaz,
     * bunun yerine oyuncu için tetiklenecek bir komut çalıştırılır (örn. /shardsshop).
     * Bu, DonutShards gibi kapalı-kaynak eklentilerin kendi mağazasına yönlendirme
     * yapmak için kullanılır; bakiye bizim tarafımızdan hiç okunmaz/değiştirilmez.
     */
    private final boolean redirect;
    private final String redirectCommand;

    public ShopItem(String id, double price, boolean isShard, String shardPlaceholder,
                     Material material, String displayName, List<String> lore, int position,
                     List<String> commands, int amount, boolean redirect, String redirectCommand) {
        this.id = id;
        this.price = price;
        this.isShard = isShard;
        this.shardPlaceholder = shardPlaceholder;
        this.material = material;
        this.displayName = displayName;
        this.lore = lore;
        this.position = position;
        this.commands = commands;
        this.amount = amount;
        this.redirect = redirect;
        this.redirectCommand = redirectCommand;
    }

    public String getId() {
        return id;
    }

    public double getPrice() {
        return price;
    }

    public boolean isShard() {
        return isShard;
    }

    public String getShardPlaceholder() {
        return shardPlaceholder;
    }

    public Material getMaterial() {
        return material;
    }

    public String getDisplayName() {
        return displayName;
    }

    public List<String> getLore() {
        return lore;
    }

    public int getPosition() {
        return position;
    }

    public List<String> getCommands() {
        return commands;
    }

    public int getAmount() {
        return amount;
    }

    public boolean isRedirect() {
        return redirect;
    }

    public String getRedirectCommand() {
        return redirectCommand;
    }
}

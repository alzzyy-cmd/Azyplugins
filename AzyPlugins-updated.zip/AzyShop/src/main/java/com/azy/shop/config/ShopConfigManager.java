package com.azy.shop.config;

import com.azy.shop.AzyShop;
import com.azy.shop.model.ShopCategory;
import com.azy.shop.model.ShopItem;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

/**
 * config.yml ve categories/*.yml dosyalarını yükler.
 * Dosya formatı DonutShop'un categories/<isim>.yml formatıyla BİREBİR uyumludur,
 * böylece elindeki mevcut dosyaları doğrudan bu klasöre kopyalayıp kullanabilirsin.
 */
public class ShopConfigManager {

    private final AzyShop plugin;
    private FileConfiguration mainConfig;
    /** Kategori id -> ShopCategory, sıralı (LinkedHashMap) ki ana menüde sıralama korunsun */
    private final Map<String, ShopCategory> categories = new LinkedHashMap<>();

    public ShopConfigManager(AzyShop plugin) {
        this.plugin = plugin;
    }

    public void loadAll() {
        categories.clear();
        saveDefaultConfigIfMissing("config.yml");
        this.mainConfig = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "config.yml"));

        File categoriesFolder = new File(plugin.getDataFolder(), "categories");
        if (!categoriesFolder.exists()) {
            categoriesFolder.mkdirs();
            // Örnek kategori dosyalarını jar içinden kopyala (ilk kurulumda)
            copyDefaultCategoryIfMissing("gear.yml");
            copyDefaultCategoryIfMissing("food.yml");
            copyDefaultCategoryIfMissing("nether.yml");
            copyDefaultCategoryIfMissing("end.yml");
            copyDefaultCategoryIfMissing("shards.yml");
        }

        File[] files = categoriesFolder.listFiles((dir, name) -> name.endsWith(".yml"));
        if (files == null) return;

        for (File file : files) {
            try {
                loadCategoryFile(file);
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "Kategori dosyası okunamadı: " + file.getName(), ex);
            }
        }
    }

    private void loadCategoryFile(File file) {
        String categoryId = file.getName().replace(".yml", "");
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);

        ConfigurationSection main = yaml.getConfigurationSection("main");
        String displayName = categoryId;
        List<String> mainLore = List.of();
        Material iconMaterial = Material.CHEST;
        int mainMenuPosition = 0;

        if (main != null) {
            displayName = main.getString("name", categoryId);
            mainLore = main.getStringList("lore");
            iconMaterial = parseMaterial(main.getString("material", "CHEST"));
            mainMenuPosition = main.getInt("position", 0);
        }

        ShopCategory category = new ShopCategory(categoryId, displayName, mainLore, iconMaterial, mainMenuPosition);

        ConfigurationSection itemsSection = yaml.getConfigurationSection("items");
        if (itemsSection != null) {
            for (String itemId : itemsSection.getKeys(false)) {
                ConfigurationSection itemSec = itemsSection.getConfigurationSection(itemId);
                if (itemSec == null) continue;

                double price = itemSec.getDouble("price", 0);
                boolean isShard = itemSec.getBoolean("isShard", false);
                String shardPlaceholder = itemSec.getString("shard_placeholder", "");
                Material material = parseMaterial(itemSec.getString("material", "STONE"));
                String name = itemSec.getString("name", itemId);
                List<String> lore = itemSec.getStringList("lore");
                int position = itemSec.getInt("position", 0);
                List<String> commands = itemSec.getStringList("commands");
                int amount = itemSec.getInt("amount", 1);

                // Yönlendirme (redirect) desteği: item config'inde "redirect-command" tanımlıysa,
                // tıklandığında GUI kapanır ve bu komut oyuncu adına çalıştırılır.
                // Örnek kullanım: DonutShards'ın kendi shard mağazasına yönlendirmek için
                // redirect-command: "shardsshop" yazılabilir.
                String redirectCommand = itemSec.getString("redirect-command", "");
                boolean redirect = redirectCommand != null && !redirectCommand.isBlank();

                ShopItem item = new ShopItem(itemId, price, isShard, shardPlaceholder, material, name, lore,
                        position, commands, amount, redirect, redirectCommand);
                category.addItem(item);
            }
        }

        categories.put(categoryId, category);
    }

    private Material parseMaterial(String name) {
        if (name == null) return Material.STONE;
        Material mat = Material.matchMaterial(name.toUpperCase());
        return mat != null ? mat : Material.STONE;
    }

    private void saveDefaultConfigIfMissing(String fileName) {
        File target = new File(plugin.getDataFolder(), fileName);
        if (!target.exists()) {
            plugin.saveResource(fileName, false);
        }
    }

    private void copyDefaultCategoryIfMissing(String categoryFileName) {
        File target = new File(plugin.getDataFolder(), "categories/" + categoryFileName);
        if (target.exists()) return;
        try (InputStream in = plugin.getResource("categories/" + categoryFileName)) {
            if (in == null) return;
            target.getParentFile().mkdirs();
            Files.copy(in, target.toPath());
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "Varsayılan kategori kopyalanamadı: " + categoryFileName, ex);
        }
    }

    public FileConfiguration getMainConfig() {
        return mainConfig;
    }

    public Map<String, ShopCategory> getCategories() {
        return categories;
    }
}

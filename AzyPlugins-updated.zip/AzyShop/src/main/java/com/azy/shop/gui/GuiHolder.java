package com.azy.shop.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Her açık GUI penceresine bağlı olan işaretleyici (holder).
 * InventoryClickEvent geldiğinde, tıklanan envanterin holder'ına bakarak
 * "bu hangi GUI, hangi kategori, hangi ürün" bilgisini net şekilde biliriz.
 * Bukkit'in kendi inventory title karşılaştırmasına güvenmek yerine bu daha güvenlidir.
 */
public class GuiHolder implements InventoryHolder {

    public enum Type {
        MAIN_MENU,
        CATEGORY,
        PURCHASE_CONFIRM
    }

    private final Type type;
    private final String categoryId;
    private final String itemId;
    /** Satın alma ekranında oyuncunun şu an seçtiği miktar */
    private int selectedAmount = 1;
    /**
     * Shard bakiyesinin GUI AÇILDIĞINDA okunmuş TEK SEFERLİK önbelleği.
     * +1/+10/Maksimum gibi miktar butonlarına her tıklandığında PlaceholderAPI'ye
     * yeniden gitmemek için burada tutulur; ekranda gösterilen "afford" durumu ve
     * "Ekle Maksimum" hesabı bu değerden yapılır. Gerçek satın alma anında
     * (ShardService.purchaseWithShards) bakiye YİNE DE taze okunur — burası sadece
     * önizleme/UX amaçlıdır, güvenlik kontrolü değildir. Shard ürünü değilse -1 kalır.
     */
    private double cachedShardBalance = -1;
    private Inventory inventory;

    public GuiHolder(Type type, String categoryId, String itemId) {
        this.type = type;
        this.categoryId = categoryId;
        this.itemId = itemId;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public Type getType() {
        return type;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public String getItemId() {
        return itemId;
    }

    public int getSelectedAmount() {
        return selectedAmount;
    }

    public void setSelectedAmount(int selectedAmount) {
        this.selectedAmount = selectedAmount;
    }

    public double getCachedShardBalance() {
        return cachedShardBalance;
    }

    public void setCachedShardBalance(double cachedShardBalance) {
        this.cachedShardBalance = cachedShardBalance;
    }
}

package com.azy.shop.gui;

import com.azy.shop.AzyShop;
import com.azy.shop.model.ShopCategory;
import com.azy.shop.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

/**
 * Ana mağaza menüsü: her kategori bir ikon olarak gösterilir (DonutShop'taki gibi).
 * Kategorinin config'deki "position" alanı, bu menüdeki slot'u belirler.
 */
public class MainMenuGui {

    private final AzyShop plugin;

    public MainMenuGui(AzyShop plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        String title = ColorUtil.color(plugin.getConfigManager().getMainConfig()
                .getString("inventory.titles.category", "Mağaza"));

        GuiHolder holder = new GuiHolder(GuiHolder.Type.MAIN_MENU, null, null);
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        for (ShopCategory category : plugin.getConfigManager().getCategories().values()) {
            ItemStack icon = new ItemStack(category.getIconMaterial());
            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(ColorUtil.color(category.getDisplayName()));
                meta.setLore(ColorUtil.color(category.getLore()));
                icon.setItemMeta(meta);
            }
            int slot = category.getMainMenuPosition();
            if (slot >= 0 && slot < inv.getSize()) {
                inv.setItem(slot, icon);
            }
        }

        player.openInventory(inv);
    }
}

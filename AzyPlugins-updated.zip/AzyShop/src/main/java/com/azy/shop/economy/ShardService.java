package com.azy.shop.economy;

import com.azy.shop.AzyShop;
import com.azy.shop.model.ShopItem;
import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * DonutShards ile ilgili tüm etkileşim BURADA toplanır.
 *
 * GERÇEK VERİDEN ÖĞRENDİĞİMİZ DAVRANIŞ:
 * Senin gerçek DonutShop categories/shards.yml dosyanda, isShard:true olan ürünlerin
 * "commands" listesinde zaten "shardsadmin remove {player} {price}" komutu var.
 * Yani orijinal DonutShop bakiyeyi DOĞRUDAN DÜŞÜRÜYOR (yönlendirme yapmıyor), ve
 * bakiye kontrolü için PlaceholderAPI expansion'ı "%donutshards_balance%" (veya
 * end.yml'deki "%xshards_playershards%") kullanılıyor.
 *
 * Bu yüzden bu servis artık İKİ modu birden destekliyor:
 *  1) DOĞRUDAN DÜŞÜRME (varsayılan, gerçek veriyle uyumlu): PlaceholderAPI üzerinden
 *     bakiye okunur, yetersizse satış iptal edilir, yeterliyse item'ın "commands"
 *     listesindeki komutlar (shardsadmin remove dahil) konsoldan çalıştırılır.
 *  2) YÖNLENDİRME (opsiyonel, eski davranış): item config'inde "redirect-command"
 *     tanımlıysa, GUI kapanır ve o komut (örn. /shardsshop) oyuncu adına çalıştırılır.
 *     Bunu, bakiye hiç okunamıyorsa (PAPI yoksa) güvenli bir yedek olarak kullanabilirsin.
 */
public class ShardService {

    private final AzyShop plugin;

    public ShardService(AzyShop plugin) {
        this.plugin = plugin;
    }

    public boolean isDonutShardsPresent() {
        return plugin.getServer().getPluginManager().getPlugin("DonutShards") != null;
    }

    public boolean isPlaceholderApiPresent() {
        return plugin.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null;
    }

    /**
     * Oyuncunun shard bakiyesini PlaceholderAPI üzerinden okur.
     * item.getShardPlaceholder() içindeki placeholder (örn. "%donutshards_balance%") kullanılır.
     * PlaceholderAPI yüklü değilse veya placeholder çözümlenemiyorsa -1 döner (bilinmiyor demek).
     */
    public double getShardBalance(Player player, ShopItem item) {
        if (!isPlaceholderApiPresent()) return -1;
        String placeholder = item.getShardPlaceholder();
        if (placeholder == null || placeholder.isBlank()) return -1;

        String resolved = PlaceholderAPI.setPlaceholders(player, placeholder);
        try {
            // Bazı placeholder çıktıları "1.234" gibi binlik ayraç içerebilir, temizleyelim.
            String cleaned = resolved.replace(",", "").trim();
            return Double.parseDouble(cleaned);
        } catch (NumberFormatException ex) {
            plugin.getLogger().warning("Shard bakiyesi okunamadı, placeholder çıktısı sayı değil: '" + resolved + "'");
            return -1;
        }
    }

    /**
     * Shard ile satın almayı GERÇEKTEN gerçekleştirir:
     * 1) Bakiyeyi PAPI üzerinden oku
     * 2) Yeterliyse item.getCommands() listesindeki TÜM komutları (shardsadmin remove dahil) çalıştır
     * 3) Yetersizse veya bakiye okunamıyorsa satın almayı reddet
     *
     * @return true ise satın alma başarılı, false ise reddedildi (mesaj zaten oyuncuya gönderildi)
     */
    public boolean purchaseWithShards(Player player, ShopItem item, int selectedAmount) {
        if (!isDonutShardsPresent()) {
            player.sendMessage(plugin.msg("&cShard sistemi şu anda kullanılamıyor. (DonutShards yüklü değil)"));
            return false;
        }

        double totalCost = item.getPrice() * selectedAmount;
        double balance = getShardBalance(player, item);

        if (balance < 0) {
            // Bakiye okunamadı (PAPI yok veya placeholder hatalı).
            // Güvenlik gereği satışı DURDURUYORUZ - bakiyeyi bilmeden düşürmek riskli olur.
            player.sendMessage(plugin.msg("&cParça bakiyen okunamadı, satın alma iptal edildi. "
                    + "(PlaceholderAPI kurulu ve DonutShards expansion'ı aktif mi kontrol et)"));
            return false;
        }

        if (balance < totalCost) {
            player.sendMessage(plugin.msg("&cYeterli parçan yok. Gerekli: &f" + (long) totalCost
                    + " &c| Bakiyen: &f" + (long) balance));
            return false;
        }

        int totalGiven = selectedAmount * item.getAmount();
        for (String cmdTemplate : item.getCommands()) {
            String cmd = cmdTemplate
                    .replace("{player}", player.getName())
                    .replace("{amount}", String.valueOf(totalGiven))
                    .replace("{price}", String.valueOf((long) totalCost));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }

        player.sendMessage(plugin.msg("&7" + totalGiven + " " + item.getDisplayName()
                + " &7satın aldın. Fiyat: &d" + (long) totalCost + " Parça"));
        return true;
    }

    /**
     * ESKİ/OPSİYONEL davranış: item config'inde "redirect-command" tanımlıysa,
     * oyuncu adına bu komutu çalıştırır (örn. /shardsshop). Bakiyeye hiç dokunmaz.
     */
    public void triggerRedirect(Player player, ShopItem item) {
        String command = item.getRedirectCommand();
        if (command == null || command.isBlank()) return;

        if (!isDonutShardsPresent()) {
            player.sendMessage(plugin.msg("&cShard mağazası şu anda kullanılamıyor. (DonutShards yüklü değil)"));
            return;
        }
        player.performCommand(command);
    }
}

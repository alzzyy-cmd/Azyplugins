package com.azy.shop.util;

import org.bukkit.ChatColor;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * DonutShop / DonutWorth2 configlerinde kullanılan iki renk formatını da destekler:
 *  - Klasik '&' kod formatı (&a, &c, &l ...)
 *  - Hex format: '#RRGGBB' (örn. '#00F986Yazı') - config dosyalarında sıkça kullanılıyor.
 */
public final class ColorUtil {

    private static final Pattern HEX_PATTERN = Pattern.compile("#([A-Fa-f0-9]{6})");

    private ColorUtil() {}

    public static String color(String input) {
        if (input == null) return "";

        Matcher matcher = HEX_PATTERN.matcher(input);
        StringBuilder buffer = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.toCharArray()) {
                replacement.append('§').append(c);
            }
            matcher.appendReplacement(buffer, replacement.toString());
        }
        matcher.appendTail(buffer);

        return ChatColor.translateAlternateColorCodes('&', buffer.toString());
    }

    public static List<String> color(List<String> lines) {
        return lines.stream().map(ColorUtil::color).collect(Collectors.toList());
    }
}

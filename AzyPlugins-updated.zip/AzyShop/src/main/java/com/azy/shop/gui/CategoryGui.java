package com.azy.shop.gui;

import com.azy.shop.AzyShop;
import com.azy.shop.model.ShopCategory;
import com.azy.shop.model.ShopItem;
import com.azy.shop.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/**
 * Bir kategori içindeki ürünleri listeler. Her ürünün lore'una fiyat bilgisi eklenir.
 * Shard ürünleri (isShard: true) farklı bir vurgu ile gösterilir ve tıklanınca
 * (eğer redirect tanımlıysa) DonutShards'a yönlendirilir.
 */
public class CategoryGui {

    private final AzyShop plugin;

    public CategoryGui(AzyShop plugin) {
        this.plugin = plugin;
    }

    public void open(Player player, ShopCategory category) {
        String titleTemplate = ColorUtil.color(plugin.getConfigManager().getMainConfig()
                .getString("inventory.titles.shop", "Mağaza - {currentCategory}"));
        String title = titleTemplate.replace("{currentCategory}", ColorUtil.color(category.getDisplayName()));

        GuiHolder holder = new GuiHolder(GuiHolder.Type.CATEGORY, category.getId(), null);
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        for (ShopItem item : category.getItems().values()) {
            ItemStack stack = buildDisplayItem(item);
            int slot = item.getPosition();
            if (slot >= 0 && slot < inv.getSize()) {
                inv.setItem(slot, stack);
            }
        }

        // Geri butonu - son slotun hemen öncesine sabit koyuyoruz
        ItemStack back = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta backMeta = back.getItemMeta();
        if (backMeta != null) {
            backMeta.setDisplayName(ColorUtil.color("&cGeri"));
            backMeta.setLore(List.of(ColorUtil.color("&7Ana menüye dönmek için tıkla")));
            back.setItemMeta(backMeta);
        }
        inv.setItem(inv.getSize() - 1, back);

        player.openInventory(inv);
    }

    private ItemStack buildDisplayItem(ShopItem item) {
        ItemStack stack = new ItemStack(item.getMaterial());
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;

        meta.setDisplayName(ColorUtil.color(item.getDisplayName()));

        List<String> lore = new ArrayList<>();
        for (String line : item.getLore()) {
            lore.add(ColorUtil.color(line.replace("{price}", formatPrice(item))));
        }

        if (item.isShard()) {
            lore.add(ColorUtil.color("&d&lParça (Shard) Ürünü"));
            lore.add(ColorUtil.color("&7Parça bakiyenden düşülerek satın alınır"));
        }

        meta.setLore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    private String formatPrice(ShopItem item) {
        if (item.isShard()) {
            return String.valueOf((long) item.getPrice());
        }
        return plugin.getEconomyManager().format(item.getPrice());
    }
}

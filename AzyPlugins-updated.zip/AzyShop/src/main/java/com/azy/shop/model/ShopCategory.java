package com.azy.shop.model;

import org.bukkit.Material;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Bir mağaza kategorisini (gear, food, nether, end, shards vb.) temsil eder.
 * DonutShop'un categories/<isim>.yml dosyasındaki "main" ve "items" bölümlerine karşılık gelir.
 */
public class ShopCategory {

    private final String id;
    private final String displayName;
    private final List<String> lore;
    private final Material iconMaterial;
    private final int mainMenuPosition;
    /** id -> item, sıralı (LinkedHashMap) ki GUI her zaman aynı sırada dolsun */
    private final Map<String, ShopItem> items = new LinkedHashMap<>();

    public ShopCategory(String id, String displayName, List<String> lore, Material iconMaterial, int mainMenuPosition) {
        this.id = id;
        this.displayName = displayName;
        this.lore = lore;
        this.iconMaterial = iconMaterial;
        this.mainMenuPosition = mainMenuPosition;
    }

    public void addItem(ShopItem item) {
        items.put(item.getId(), item);
    }

    public String getId() {
        return id;
    }

    public String getDisplayName() {
        return displayName;
    }

    public List<String> getLore() {
        return lore;
    }

    public Material getIconMaterial() {
        return iconMaterial;
    }

    public int getMainMenuPosition() {
        return mainMenuPosition;
    }

    public Map<String, ShopItem> getItems() {
        return items;
    }
}

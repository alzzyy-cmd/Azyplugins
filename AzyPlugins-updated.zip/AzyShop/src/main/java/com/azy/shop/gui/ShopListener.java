package com.azy.shop.gui;

import com.azy.shop.AzyShop;
import com.azy.shop.model.ShopCategory;
import com.azy.shop.model.ShopItem;
import com.azy.shop.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class ShopListener implements Listener {

    private final AzyShop plugin;
    private final PurchaseGui purchaseGui;
    private final CategoryGui categoryGui;
    private final MainMenuGui mainMenuGui;

    public ShopListener(AzyShop plugin) {
        this.plugin = plugin;
        this.purchaseGui = new PurchaseGui(plugin);
        this.categoryGui = new CategoryGui(plugin);
        this.mainMenuGui = new MainMenuGui(plugin);
    }

    /**
     * Tüm GUI'lerimizde item taşımayı/hırsızlığı tamamen engeller.
     * Oyuncu shift-click, drag, number-key vs. ile envanterden hiçbir şeyi
     * çekip çıkaramaz veya kendi eşyasını GUI'ye koyamaz — bu da stack
     * karışıklığı ihtimalini kökten keser.
     */
    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof GuiHolder holder)) return;

        // Bizim GUI'lerimizde HER TIKLAMA iptal edilir; sadece kendi buton mantığımızla ilerleriz.
        event.setCancelled(true);

        // Oyuncunun kendi envanterine (alt kısma) tıklaması bizi ilgilendirmez.
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getInventory())) {
            return;
        }

        int slot = event.getSlot();
        Player player = (Player) event.getWhoClicked();

        switch (holder.getType()) {
            case MAIN_MENU -> handleMainMenuClick(player, holder, slot);
            case CATEGORY -> handleCategoryClick(player, holder, slot);
            case PURCHASE_CONFIRM -> handlePurchaseClick(player, holder, slot);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof GuiHolder) {
            event.setCancelled(true);
        }
    }

    private void handleMainMenuClick(Player player, GuiHolder holder, int slot) {
        for (ShopCategory category : plugin.getConfigManager().getCategories().values()) {
            if (category.getMainMenuPosition() == slot) {
                categoryGui.open(player, category);
                return;
            }
        }
    }

    private void handleCategoryClick(Player player, GuiHolder holder, int slot) {
        ShopCategory category = plugin.getConfigManager().getCategories().get(holder.getCategoryId());
        if (category == null) return;

        // Geri butonu son slotta
        if (slot == holder.getInventory().getSize() - 1) {
            mainMenuGui.open(player);
            return;
        }

        for (ShopItem item : category.getItems().values()) {
            if (item.getPosition() == slot) {
                // redirect-command SADECE elle config'e eklenmişse (opsiyonel özellik) kullanılır.
                // Gerçek DonutShop verisi shard itemlerini redirect DEĞİL, doğrudan
                // shard bakiyesinden düşürme olarak tanımladığı için varsayılan akış
                // her zaman PurchaseGui'ye gider (isShard olsa bile).
                if (item.isRedirect()) {
                    player.closeInventory();
                    plugin.getShardService().triggerRedirect(player, item);
                    return;
                }
                purchaseGui.open(player, category, item);
                return;
            }
        }
    }

    private void handlePurchaseClick(Player player, GuiHolder holder, int slot) {
        ShopCategory category = plugin.getConfigManager().getCategories().get(holder.getCategoryId());
        if (category == null) return;
        ShopItem item = category.getItems().get(holder.getItemId());
        if (item == null) return;

        Inventory inv = holder.getInventory();
        int current = holder.getSelectedAmount();
        // Bakiye (shard ürünüyse) GUI açılışında bir kez okunup önbelleklendi;
        // burada YENİDEN sorgulanmıyor — sadece önbellekten okunuyor.
        double cachedBalance = holder.getCachedShardBalance();

        if (slot == PurchaseGui.getSlotAddOne()) {
            holder.setSelectedAmount(Math.min(64, current + 1));
            purchaseGui.renderDisplay(inv, item, holder.getSelectedAmount(), cachedBalance);
        } else if (slot == PurchaseGui.getSlotAddTen()) {
            holder.setSelectedAmount(Math.min(64, current + 10));
            purchaseGui.renderDisplay(inv, item, holder.getSelectedAmount(), cachedBalance);
        } else if (slot == PurchaseGui.getSlotAddMax()) {
            // Shard ürünlerinde "maksimum" artık gerçekten karşılanabilecek miktar;
            // bunun için de önbellekteki bakiye kullanılıyor, yeni bir PAPI sorgusu yok.
            holder.setSelectedAmount(purchaseGui.resolveMaxAffordableAmount(item, cachedBalance));
            purchaseGui.renderDisplay(inv, item, holder.getSelectedAmount(), cachedBalance);
        } else if (slot == PurchaseGui.getSlotRemoveOne()) {
            holder.setSelectedAmount(Math.max(1, current - 1));
            purchaseGui.renderDisplay(inv, item, holder.getSelectedAmount(), cachedBalance);
        } else if (slot == PurchaseGui.getSlotRemoveTen()) {
            holder.setSelectedAmount(Math.max(1, current - 10));
            purchaseGui.renderDisplay(inv, item, holder.getSelectedAmount(), cachedBalance);
        } else if (slot == PurchaseGui.getSlotRemoveMax()) {
            holder.setSelectedAmount(1);
            purchaseGui.renderDisplay(inv, item, holder.getSelectedAmount(), cachedBalance);
        } else if (slot == PurchaseGui.getSlotCancel()) {
            categoryGui.open(player, category);
        } else if (slot == PurchaseGui.getSlotConfirm()) {
            executePurchase(player, item, holder.getSelectedAmount());
        }
    }

    /**
     * Satın almayı TEK SEFERDE, net bir şekilde uygular.
     * Shard ürünleri için ShardService.purchaseWithShards çağrılır (gerçek bakiye
     * kontrolü + shardsadmin remove komutu). Para ürünleri için Vault kullanılır.
     */
    private void executePurchase(Player player, ShopItem item, int selectedAmount) {
        int totalGiven = selectedAmount * item.getAmount();
        double totalPrice = item.getPrice() * selectedAmount;

        if (item.isShard()) {
            boolean success = plugin.getShardService().purchaseWithShards(player, item, selectedAmount);
            if (success) {
                player.closeInventory();
            }
            return;
        }

        if (!player.hasPermission("azyshop.freeprice")) {
            if (!plugin.getEconomyManager().has(player, totalPrice)) {
                player.sendMessage(ColorUtil.color(plugin.getConfigManager().getMainConfig()
                        .getString("messages.purchase.failure.money", "&cYeterli paran yok.")));
                return;
            }
            boolean withdrawn = plugin.getEconomyManager().withdraw(player, totalPrice);
            if (!withdrawn) {
                player.sendMessage(ColorUtil.color("&cİşlem başarısız oldu, tekrar dene."));
                return;
            }
        }

        for (String cmdTemplate : item.getCommands()) {
            String cmd = cmdTemplate
                    .replace("{player}", player.getName())
                    .replace("{amount}", String.valueOf(totalGiven));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }

        String successMsg = ColorUtil.color(plugin.getConfigManager().getMainConfig()
                .getString("messages.purchase.success.money",
                        "&7{amount} {item} &7satın aldın. Fiyat: &a${price}"))
                .replace("{amount}", String.valueOf(totalGiven))
                .replace("{item}", ColorUtil.color(item.getDisplayName()))
                .replace("{price}", plugin.getEconomyManager().format(totalPrice));
        player.sendMessage(successMsg);

        player.closeInventory();
    }
}
